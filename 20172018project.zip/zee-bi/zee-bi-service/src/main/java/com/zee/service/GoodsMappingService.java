package com.zee.service;

/**
 * @author : chenxiang
 * @date : 2018/6/22
 * 商品映射服务
 */
public interface GoodsMappingService {
    /**
     * 同步商品映射
     * @param pageIndex
     */
    void fetchGoodsMapping(int pageIndex,String startDate);
}

package com.zee.serviceImpl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.zee.jushuitanApi.Api.OpenSearch;
import com.zee.jushuitanApi.Models.JobModel;
import com.zee.service.SiteGoodsService;
import com.zee.task.JuShuiTanDataSyncTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author : chenxiang
 * @date : 2018/6/22
 */
@Service
@Transactional(rollbackFor = RuntimeException.class)
public class SiteGoodsServiceImpl implements SiteGoodsService {
    private static final Logger logger = LoggerFactory.getLogger(JuShuiTanDataSyncTask.class);
    @Value("${jushuitan.url}")
    private String url;
    @Value("${jushuitan.partnerId}")
    private String partnerId;
    @Value("${jushuitan.partnerKey}")
    private String partnerKey;
    @Value("${jushuitan.token}")
    private String token;

    @Override
    public void fetchSiteGoods(int pageIndex) {
        //获取平台商品信息
        String method = "sku.source.query";
        OpenSearch os = new OpenSearch(partnerId, partnerKey, token, method, url);
        JobModel jobModel = new JobModel();
        Map<String, Object> queryMap = new HashMap<>();
        queryMap.put("page_index", pageIndex);
        queryMap.put("page_size", 50);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        queryMap.put("modified_end", simpleDateFormat.format(calendar.getTime()));
        queryMap.put("shop_id", 10106836);
        calendar.add(Calendar.DAY_OF_YEAR, -1);
        queryMap.put("modified_begin", simpleDateFormat.format(calendar.getTime()));
        jobModel.setData(JSON.toJSONString(queryMap));
        try {
            System.out.println(">>>>>>>开始同步聚水潭平台商品数据");
            String sData = os.QueryData(jobModel);
            JSONObject jsonObject = JSON.parseObject(sData);
            System.out.println(sData);
            logger.info(sData);
//            if ("0".equals(jsonObject.get("code") + "")) {
//                JSONArray jsonArray = jsonObject.getJSONArray("datas");
//                if (jsonArray != null && !jsonArray.isEmpty()) {
//                    System.out.println(">>>>>>>开始保存平台商品数据");
//                    saveSiteGoods(jsonArray);
//                    boolean has_next = jsonObject.getBoolean("has_next");
//                    if (has_next) {
//                        pageIndex++;
//                        fetchSiteGoods(pageIndex);
//                        logger.info("获取聚水潭平台商品页数:" + pageIndex);
//                    }
//                } else {
//                    logger.info("聚水潭无数据信息" + jsonObject.get("msg"));
//                }
//            } else {
//                logger.error("获取商品信息失败 " + jsonObject.get("msg"));
//            }
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
    }
}

package com.zee.serviceImpl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.zee.dao.OrderDao;
import com.zee.dao.OrderItemsDao;
import com.zee.dao.OrderPaysDao;
import com.zee.dao.QueryTimeDao;
import com.zee.jushuitanApi.Qimen.Query;
import com.zee.model.Order;
import com.zee.model.OrderItems;
import com.zee.model.OrderPays;
import com.zee.model.QueryTime;
import com.zee.service.OrderService;
import com.zee.task.JuShuiTanDataSyncTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author : chenxiang
 * @date : 2018/6/22
 * 订单服务实现类
 */
@Transactional(rollbackFor = RuntimeException.class)
@Service
public class OrderServiceImpl implements OrderService {
    @Autowired
    private OrderDao orderDao;
    @Autowired
    private OrderPaysDao orderPaysDao;
    @Autowired
    private OrderItemsDao orderItemsDao;
    @Autowired
    private QueryTimeDao queryTimeDao;

    private static final Logger logger = LoggerFactory.getLogger(JuShuiTanDataSyncTask.class);
    private static final String queryType = "orders";
    @Value("${qimen.url}")
    private String url;
    @Value("${jushuitan.partnerId}")
    private String partnerId;
    @Value("${jushuitan.partnerKey}")
    private String partnerKey;
    @Value("${jushuitan.token}")
    private String token;
    @Value("${qimen.appKey}")
    private String sTaobaoAPPKEYString;
    @Value("${qimen.appSecret}")
    private String sTaobaoAPPSECRET;

    @Override
    public void fetchOrder(int pageIndex, String startDate) {
        String beginTime;
        String endTime;
        //获取订单信息
        String method = "jst.orders.query";
        Query api = new Query(sTaobaoAPPKEYString, sTaobaoAPPSECRET, partnerId, partnerKey, token, method, url);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //每次查询以上次结束时间作为此次开始时间;上次结束为空时,开始时间为当前时间小时数-1
        if (StringUtils.isEmpty(startDate)) {
            startDate = queryTimeDao.selectLastTime(queryType);
        }
        Calendar calendar = Calendar.getInstance();
        if (StringUtils.isEmpty(startDate)) {
            calendar.setTime(new Date());
            endTime = simpleDateFormat.format(calendar.getTime());
            calendar.add(Calendar.DAY_OF_YEAR, -1);
            beginTime = simpleDateFormat.format(calendar.getTime());
        } else {
            try {
                calendar.setTime(simpleDateFormat.parse(startDate));
            } catch (ParseException e) {
                logger.error(e.getMessage(), e);
            }
            beginTime = simpleDateFormat.format(calendar.getTime());
            endTime = simpleDateFormat.format(new Date());
        }
        api.AddArg("modified_end", endTime);
        api.AddArg("modified_begin", beginTime);
        api.AddArg("page_index", String.valueOf(pageIndex));
        api.AddArg("page_size", String.valueOf(50));
        try {
            System.out.println(">>>>>>>开始同步聚水潭订单数据");
            String sData = api.QueryData();
            JSONObject jsonObject = JSON.parseObject(sData);
            JSONObject response = jsonObject.getJSONObject("response");
            if (!StringUtils.isEmpty(response.get("orders"))) {
                JSONArray jsonArray = response.getJSONArray("orders");
                if (jsonArray != null && !jsonArray.isEmpty()) {
                    System.out.println(">>>>" + response.toJSONString());
                    System.out.println(">>>>>>>开始保存订单数据");
                    saveOrder(jsonArray, beginTime, endTime);
                    boolean has_next = response.getBoolean("has_next");
                    if (has_next) {
                        pageIndex++;
                        fetchOrder(pageIndex, startDate);
                        logger.info("获取聚水潭订单页数:" + pageIndex);
                    }
                } else {
                    logger.info("聚水潭无数据信息" + jsonObject.get("msg"));
                }
            } else {
                logger.error("获取订单信息失败 " + jsonObject.get("msg"));
            }
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
        QueryTime queryTime = new QueryTime();
        queryTime.setEndTime(endTime);
        queryTime.setQueryType(queryType);
        queryTimeDao.insert(queryTime);

    }


    /**
     * 保存订单信息
     */
    private void saveOrder(JSONArray jsonArray, String beginTime, String endTime) {
        EntityWrapper<Order> ew = new EntityWrapper<Order>();
        ew.le("modified", endTime).ge("modified ", beginTime);
        List<Order> returnGoodsList = orderDao.selectList(ew);
        List<Order> filter = new ArrayList<Order>(100);
        List<Order> result = new ArrayList<>(16);
        List<OrderItems> itemsList = new ArrayList<>(100);
        List<OrderPays> paysList = new ArrayList<>(100);
        for (int i = 0; jsonArray != null && i < jsonArray.size(); i++) {
            JSONObject storageObject = jsonArray.getJSONObject(i);
            JSONArray items = storageObject.getJSONArray("items");
            JSONArray pays = storageObject.getJSONArray("pays");
            storageObject.remove("items");
            storageObject.remove("pays");
            Order order = storageObject.toJavaObject(Order.class);
            //只保存状态为已确定的订单
            if (("Confirmed").equals(order.getStatus())) {
                continue;
            }
            order.setId(UUID.randomUUID().toString().replace("-", ""));
            result.add(order);
            if (items != null && !items.isEmpty()) {
                List<OrderItems> rgiList = JSON.parseArray(items.toJSONString(), OrderItems.class);
                if (rgiList != null && !rgiList.isEmpty()) {
                    for (OrderItems rgi : rgiList) {
                        rgi.setId(UUID.randomUUID().toString().replace("-", ""));
                        rgi.setOId(order.getOId());
                    }
                    itemsList.addAll(rgiList);
                }

            }
            if (pays != null && !pays.isEmpty()) {
                List<OrderPays> orderPaysList = JSON.parseArray(pays.toJSONString(), OrderPays.class);
                if (paysList != null && !paysList.isEmpty()) {
                    for (OrderPays op : orderPaysList) {
                        op.setId(UUID.randomUUID().toString().replace("-", ""));
                        op.setOId(order.getOId());
                    }
                    paysList.addAll(orderPaysList);
                }
            }
        }
        //批量插入order
        if (result != null && !result.isEmpty()) {
            orderDao.batchInsert(result);
        }
        //批量插入orderItems
        if (itemsList != null && !itemsList.isEmpty()) {
            orderItemsDao.batchInsert(itemsList);
        }
        //批量插入orderPayss
        if (paysList != null && !paysList.isEmpty()) {
            orderPaysDao.batchInsert(paysList);
        }
    }
}

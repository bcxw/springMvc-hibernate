package com.zee.service;

import java.util.Map;

/**
 * @author : chenxiang
 * @date : 2018/6/22
 */
public interface InventoryService {
    /**
     * 同步库存
     *
     * @param index
     */
    void fetchInventory(int index,String startDate);

    /**
     * 库存预警信息
     *
     * @param paramMap
     * @return
     */
    Map<String, Object> list(Map<String, String> paramMap);
}

package com.zee.service;

import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.Map;

/**
 * @author : chenxiang
 * @date : 2018/6/29
 */
public interface ShopDataService {
    /**
     * 查询分页
     *
     * @param paramMap
     * @return
     */
    Map<String, Object> list(Map<String, String> paramMap);

    /**
     * 数据导入
     *
     * @param files
     * @param paramMap
     * @return
     * @throws IOException
     */
    Map<String, Object> importData(MultipartFile[] files, Map<String, String> paramMap) throws IOException, ParseException;

    /**
     * 店铺销售额图表
     *
     * @param paramMap
     * @return
     */
    Map<String, Object> shopSalesChart(Map<String, Object> paramMap);

    /**
     * 获取新老访客数量
     *
     * @param shopId
     * @param dataDate
     * @return
     */
    Map<String, Object> getNewOldCustomers(String shopId, String dataDate);
}

package com.zee.service;

import java.util.Map;

/**
 * 用户权限
 */
public interface UserService {
    /**
     * 登录
     * @param userName
     * @param password
     * @return
     */
    Map<String, Object> login(String userName, String password);

    /**
     * 获取用户菜单
     * @param id
     * @return
     */
    Map<String, Object> getMenu(String id);

    /**
     * 获取所有部门
     * @return
     */
    Map<String, Object> getAllDepartment();

    /**
     * 根据部门获取人员列表
     * @param departmentId
     * @return
     */
    Map<String, Object> getUserByDepartmentId(String departmentId);

}

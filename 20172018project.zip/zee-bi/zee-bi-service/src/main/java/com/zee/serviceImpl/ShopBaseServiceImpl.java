package com.zee.serviceImpl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.zee.common.ResultUtil;
import com.zee.dao.*;
import com.zee.jushuitanApi.Api.OpenSearch;
import com.zee.jushuitanApi.Models.JobModel;
import com.zee.model.*;
import com.zee.service.AgpService;
import com.zee.service.ShopBaseService;
import com.zee.task.JuShuiTanDataSyncTask;
import groovyjarjarantlr.collections.impl.LList;
import org.apache.poi.ss.formula.functions.T;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.io.IOException;
import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author : chenxiang
 * @date : 2018/6/21
 */
@Transactional(rollbackFor = RuntimeException.class)
@Service
public class ShopBaseServiceImpl implements ShopBaseService {
    private static final Logger logger = LoggerFactory.getLogger(JuShuiTanDataSyncTask.class);
    @Autowired
    private ShopBaseDao shopBaseDao;
    @Autowired
    private AGPDao agpDao;
    @Autowired
    private AgpService agpService;
    @Autowired
    private ShopAgpDao shopAgpDao;
    @Autowired
    private ShopBasePeopleDao shopBasePeopleDao;
    @Value("${jushuitan.url}")
    private String url;
    @Value("${jushuitan.partnerId}")
    private String partnerId;
    @Value("${jushuitan.partnerKey}")
    private String partnerKey;
    @Value("${jushuitan.token}")
    private String token;

    @Resource
    private ShopAuthDao shopAuthDao;

    @Override
    public Map<String, Object> list(Map<String, String> paramMap) {
        int total = shopBaseDao.count();
        int start = Integer.valueOf(paramMap.get("start"));
        int limit = Integer.valueOf(paramMap.get("limit"));
        List<Map<String, String>> list = total > 0 ? shopBaseDao.list(start, limit) : null;
        return ResultUtil.success(list, total);
    }

    /**
     * 同步店铺数据
     */
    @Override
    public void fetchShop() {
        //获取店铺信息
        String method = "shops.query";
        OpenSearch os = new OpenSearch(partnerId, partnerKey, token, method, url);
        JobModel jobModel = new JobModel();
        Map<String, Object> queryMap = new HashMap<>();
        try {
            System.out.println(">>>>>>>开始同步聚水潭店铺数据");
            String sData = os.QueryData(jobModel);
            JSONObject jsonObject = JSON.parseObject(sData);
            if ("0".equals(jsonObject.get("code") + "")) {
                JSONArray jsonArray = jsonObject.getJSONArray("shops");
                if (jsonArray != null && !jsonArray.isEmpty()) {
                    System.out.println(">>>>>>>开始保存店铺数据");
                    saveJuShuiTanShop(jsonArray);
                } else {
                    logger.info("聚水潭无数据信息" + jsonObject.get("msg"));
                }
            } else {
                logger.error("获取店铺信息失败 " + jsonObject.get("msg"));
            }
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
    }

    /**
     * 获取有权限的店铺
     *
     * @param userId
     * @return
     */
    @Override
    public Map<String, Object> getAllShops(String userId) {
        Wrapper wrapper = new EntityWrapper<ShopAuth>();
        wrapper.eq("user_id", userId);
        return ResultUtil.success(shopAuthDao.selectMaps(wrapper));
    }

    /**
     * 保存店铺信息
     *
     * @param jsonArray
     */
    private void saveJuShuiTanShop(JSONArray jsonArray) {
        EntityWrapper<ShopBase> ew = new EntityWrapper<ShopBase>();
        //获取已存过的店铺集合
        List<ShopBase> shopBaseList = shopBaseDao.selectList(ew);
        List<ShopBase> filter = new ArrayList<ShopBase>(16);
        List<ShopBase> result = new ArrayList<>(16);
        for (int i = 0; jsonArray != null && i < jsonArray.size(); i++) {
            ShopBase shopBase = jsonArray.getObject(i, ShopBase.class);
            //查询是是否已存在该店铺id,有表示已存过
            if (shopBaseList != null) {
                filter = shopBaseList.stream()
                        .filter((ShopBase shopbase) -> (shopbase.getShopId().equals(shopBase.getShopId())))
                        .collect(Collectors.toList());
                if (filter != null && !filter.isEmpty()) {
                    continue;
                }
            }
            shopBase.setId(UUID.randomUUID().toString().replace("-", ""));
            result.add(shopBase);
        }
        if (result != null && !result.isEmpty()) {
            shopBaseDao.batchInsert(result);
        }
    }

    /**
     * 保存店铺授权人员
     *
     * @param shopId
     * @param employeesJson
     * @return
     */
    @Override
    public Map<String, Object> saveEmployees(String shopId, String employeesJson) {
        Wrapper wrapper = new EntityWrapper<ShopAuth>();
        wrapper.eq("shop_id", shopId);
        shopAuthDao.delete(wrapper);
        List<ShopAuth> shopAuths = JSON.parseArray(employeesJson, ShopAuth.class);
        shopAuthDao.batchInsert(shopAuths);
        return ResultUtil.success();
    }

    /**
     * 保存AGP设置
     *
     * @param paramMap
     * @return
     */
    @Override
    public Map<String, Object> saveSetting(Map<String, String> paramMap) throws ParseException {
        ShopAgp shopAgp = JSON.parseObject(JSON.toJSONString(paramMap), ShopAgp.class);
        EntityWrapper<ShopAgp> ew = new EntityWrapper<>();
        ew.eq("shop_id", shopAgp.getShopId())
                .eq("agp_month", shopAgp.getAgpMonth());
        List<ShopAgp> list = shopAgpDao.selectList(ew);
        if (list == null || list.isEmpty()) {
            shopAgp.setId(UUID.randomUUID().toString().replace("-", ""));
            shopAgpDao.insert(shopAgp);
        } else {
            shopAgpDao.updateById(shopAgp);
        }

        agpService.createAgp(shopAgp.getShopName(), null, shopAgp.getAgpMonth());
        return ResultUtil.success("设置成功!");
    }

    /**
     * agp设置详情
     *
     * @param paramMap
     * @return
     */
    @Override
    public Map<String, Object> detail(Map<String, String> paramMap) {
        String shopId = paramMap.get("shopId");
        return ResultUtil.success(shopAgpDao.detail(shopId));
    }

    /**
     * 根据店铺id获取负责人
     *
     * @param paramMap
     * @return
     */
    @Override
    public Map<String, Object> getPeoplesByBranId(Map<String, String> paramMap) {
        String shopId = paramMap.get("shopId");
        String type = paramMap.get("type");
        EntityWrapper<ShopBasePeople> ew = new EntityWrapper<>();
        ew.eq("shop_id", shopId)
                .eq("type", type);
        return ResultUtil.success(shopBasePeopleDao.selectList(ew));
    }

    /**
     * 保存店铺人员
     *
     * @param paramMap
     * @return
     */
    @Override
    public Map<String, Object> saveShopPeoples(Map<String, String> paramMap) {
        String type = paramMap.get("type");
        shopBasePeopleDao.delete(new EntityWrapper<ShopBasePeople>().where("shop_id={0}", paramMap.get("shopId"))
                .eq("type", type));
        List<ShopBasePeople> peopleList = JSON.parseArray(paramMap.get("peoples"), ShopBasePeople.class);
        for (int i = 0; i < peopleList.size(); i++) {
            shopBasePeopleDao.insert(peopleList.get(i));
        }
        return ResultUtil.success();
    }
}

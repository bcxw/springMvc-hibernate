package com.zee.service;

import java.text.ParseException;
import java.util.Map;

/**
 * @author : chenxiang
 * @date : 2018/6/21
 * 店铺基础维护模块
 */
public interface ShopBaseService {
    /**
     * 条件查询及分页
     *
     * @param paramMap
     * @return
     */
    Map<String, Object> list(Map<String, String> paramMap);

    /**
     * 获取聚水潭店铺数据
     */
    void fetchShop();

    Map<String, Object> getAllShops(String userId);

    /**
     * 保存店铺授权人员
     *
     * @param shopId
     * @param employeesJson
     * @return
     */
    Map<String, Object> saveEmployees(String shopId, String employeesJson);

    /**
     * 保存AGP设置
     *
     * @param paramMap
     * @return
     */
    Map<String, Object> saveSetting(Map<String, String> paramMap) throws ParseException;

    /**
     * 店铺设置详情
     *
     * @param paramMap
     * @return
     */
    Map<String, Object> detail(Map<String, String> paramMap);

    /**
     * 根据店铺获取负责人
     *
     * @param paramMap
     * @return
     */
    Map<String, Object> getPeoplesByBranId(Map<String, String> paramMap);

    /**
     * 保存店铺负责人,参与人
     * @param paramMap
     * @return
     */
    Map<String,Object> saveShopPeoples(Map<String, String> paramMap);
}










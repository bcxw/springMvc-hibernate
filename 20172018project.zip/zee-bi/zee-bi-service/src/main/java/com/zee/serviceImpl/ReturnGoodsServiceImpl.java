package com.zee.serviceImpl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.zee.common.ResultUtil;
import com.zee.dao.GoodsDataDao;
import com.zee.dao.QueryTimeDao;
import com.zee.dao.ReturnGoodsDao;
import com.zee.dao.ReturnGoodsItemsDao;
import com.zee.jushuitanApi.Qimen.Query;
import com.zee.model.GoodsData;
import com.zee.model.QueryTime;
import com.zee.model.ReturnGoods;
import com.zee.model.ReturnGoodsItems;
import com.zee.service.ReturnGoodsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author : chenxiang
 * @date : 2018/6/22
 * 退换货服务实现类
 */
@Transactional(rollbackFor = RuntimeException.class)
@Service
public class ReturnGoodsServiceImpl implements ReturnGoodsService {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private static final String queryType = "returnGoods";
    @Autowired
    private QueryTimeDao queryTimeDao;
    @Autowired
    private ReturnGoodsDao returnGoodsDao;
    @Autowired
    private ReturnGoodsItemsDao returnGoodsItemsDao;

    @Autowired
    private GoodsDataDao goodsDataDao;

    @Value("${qimen.url}")
    private String url;
    @Value("${jushuitan.partnerId}")
    private String partnerId;
    @Value("${jushuitan.partnerKey}")
    private String partnerKey;
    @Value("${jushuitan.token}")
    private String token;
    @Value("${qimen.appKey}")
    private String sTaobaoAPPKEYString;
    @Value("${qimen.appSecret}")
    private String sTaobaoAPPSECRET;

    @Override
    public void fetchReturnGoods(int pageIndex,String startDate) {
        String beginTime;
        String endTime;
        //获取退换货信息
        String method = "jst.refund.query";
        Query api = new Query(sTaobaoAPPKEYString, sTaobaoAPPSECRET, partnerId, partnerKey, token, method, url);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //每次查询以上次结束时间作为此次开始时间;上次结束为空时,开始时间为当前时间小时数-1
        if(StringUtils.isEmpty(startDate)){
             startDate = queryTimeDao.selectLastTime(queryType);
        }
        Calendar calendar = Calendar.getInstance();
        if (StringUtils.isEmpty(startDate)) {
            calendar.setTime(new Date());
            endTime = simpleDateFormat.format(calendar.getTime());
            calendar.add(Calendar.DAY_OF_YEAR, -1);
            beginTime = simpleDateFormat.format(calendar.getTime());
        } else {
            try {
                calendar.setTime(simpleDateFormat.parse(startDate));

            } catch (ParseException e) {
                logger.error(e.getMessage(), e);
            }
            beginTime = simpleDateFormat.format(calendar.getTime());
            endTime = simpleDateFormat.format(new Date());
        }
        api.AddArg("modified_end", endTime);
        api.AddArg("modified_begin", beginTime);
        api.AddArg("page_index", String.valueOf(pageIndex));
        api.AddArg("page_size", String.valueOf(50));
        try {
            System.out.println(">>>>>>>开始同步聚水潭退换货数据:");
            String sData = api.QueryData();
            JSONObject jsonObject = JSON.parseObject(sData);
            JSONObject response = jsonObject.getJSONObject("response");
            if (!StringUtils.isEmpty(response.get("datas"))) {
                JSONArray jsonArray = response.getJSONArray("datas");
                if (jsonArray != null && !jsonArray.isEmpty()) {
                    System.out.println(">>>>>>>开始保存退换货数据:");
                    saveReturnGoods(jsonArray, beginTime, endTime);
                    boolean has_next = response.getBoolean("has_next");
                    if (has_next) {
                        pageIndex++;
                        fetchReturnGoods(pageIndex,startDate);
                        logger.info("获取聚水潭采购单页数:" + pageIndex);
                    }
                } else {
                    logger.info("聚水潭无数据信息" + jsonObject.get("msg"));
                }
            } else {
                logger.error("获取退换货信息失败 " + jsonObject.get("msg"));
            }
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
        QueryTime queryTime = new QueryTime();
        queryTime.setEndTime(endTime);
        queryTime.setQueryType(queryType);
        queryTimeDao.insert(queryTime);
    }


    /**
     * 保存退换货数据
     *
     * @param jsonArray
     */
    private void saveReturnGoods(JSONArray jsonArray, String beginTime, String endTime) {
        //获取已存过的店铺集合
        List<ReturnGoods> returnGoodsList = new ArrayList<>(100);
        List<ReturnGoodsItems> returnGoodsItemsList = new ArrayList<>(100);
        for (int i = 0; jsonArray != null && i < jsonArray.size(); i++) {
            JSONObject storageObject = jsonArray.getJSONObject(i);
            JSONArray items = storageObject.getJSONArray("items");
            storageObject.remove("items");
            ReturnGoods returnGoods = storageObject.toJavaObject(ReturnGoods.class);
            returnGoods.setId(UUID.randomUUID().toString().replace("-", ""));
            returnGoodsList.add(returnGoods);
            if (items != null && !items.isEmpty()) {
                List<ReturnGoodsItems> rgiList = JSON.parseArray(items.toJSONString(), ReturnGoodsItems.class);
                if (rgiList != null && !rgiList.isEmpty()) {
                    for (ReturnGoodsItems rgi : rgiList) {
                        rgi.setId(UUID.randomUUID().toString().replace("-", ""));
                        if (!StringUtils.isEmpty(returnGoods.getAsId())) {
                            rgi.setAsId(returnGoods.getAsId());
                        }
                    }
                    returnGoodsItemsList.addAll(rgiList);
                }

            }
        }
        //批量插入returnGoods
        if (returnGoodsList != null && !returnGoodsList.isEmpty()) {
            returnGoodsDao.batchInsert(returnGoodsList);
        }
        //批量插入returnGoodsItems
        if (returnGoodsItemsList != null && !returnGoodsItemsList.isEmpty()) {
            returnGoodsItemsDao.batchInsert(returnGoodsItemsList);
        }

    }

    /**
     * 退换货排行列表
     *
     * @param paramMap
     * @return
     */
    @Override
    public Map<String, Object> list(Map<String, Object> paramMap) {

        try {
            SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date dateStart=sdf.parse(paramMap.get("dateStart")+" 00:00:00");
            Date dateEnd=sdf.parse(paramMap.get("dateEnd")+" 23:59:59");

            int total = returnGoodsItemsDao.count(paramMap);
            List<Map<String, Object>> list = total > 0 ? returnGoodsItemsDao.list(paramMap) : null;

            if(list!=null&&!list.isEmpty()){
                List<String> goodsIds=new ArrayList<>();
                for(Map<String, Object> oneMap:list){
                    goodsIds.add(oneMap.get("goods_id")+"");
                }


                List<GoodsData> goodsDataList=goodsDataDao.amountByDate(String.join(",",goodsIds),dateStart , dateEnd);
                for(Map<String, Object> oneMap:list){
                    for(GoodsData goodsData:goodsDataList){
                        if(goodsData.getShopId().equals(oneMap.get("shop_id"))&&goodsData.getGoodsId().equals(oneMap.get("goods_id"))){
                            oneMap.put("saleGoods", goodsData.getPayGoods());
                            oneMap.put("saleAmount", goodsData.getPayMoney());
                            break;
                        }
                    }
                }

            }

            return ResultUtil.success(list, total);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return ResultUtil.failure(e.getMessage());
        }
    }
}

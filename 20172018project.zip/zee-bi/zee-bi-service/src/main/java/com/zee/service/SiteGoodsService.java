package com.zee.service;

/**
 * @author : chenxiang
 * @date : 2018/6/22
 * 平台商品服务
 */
public interface SiteGoodsService {
    /**
     * 同步平台商品
     * @param pageIndex
     */
    void fetchSiteGoods(int pageIndex);
}

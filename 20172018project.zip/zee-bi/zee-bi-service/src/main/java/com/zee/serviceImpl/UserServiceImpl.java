package com.zee.serviceImpl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.zee.common.ResultUtil;
import com.zee.dto.AclDto;
import com.zee.dto.AclModuleLevelDto;
import com.zee.dto.DeptLevelDto;
import com.zee.model.Response;
import com.zee.model.SysUser;
import com.zee.service.SysTreeExternalService;
import com.zee.service.SysUserExternalService;
import com.zee.service.UserService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class UserServiceImpl implements UserService {

    @Reference(version = "1.0.0")
    private SysUserExternalService sysUserService;

    @Reference(version = "1.0.0")
    private SysTreeExternalService sysTreeService;

    @Value("${application.id}")
    private Integer applicationId;

    /**
     * 调用dubbo验证用户登录
     * @param username
     * @param password
     * @return
     */
    @Override
    public Map<String, Object> login(String username, String password) {
        Response<SysUser> response=sysUserService.login(username,password);
        if(response.isSuccess()){
            Map<String, Object> userMap=new HashMap<String, Object>();
            userMap.put("id",response.getResult().getId());
            userMap.put("username",response.getResult().getUsername());
            return ResultUtil.success(userMap);
        }else{
            return ResultUtil.failure("用户名或密码错误");
        }
    }

    /**
     * 获取用户菜单
     *
     * @param id
     * @return
     */
    @Override
    public Map<String, Object> getMenu(String id) {
        List<AclModuleLevelDto> menuList=sysTreeService.userAclTreeByUserIdAndModuleId(applicationId,Integer.parseInt(id)).getResult();
        AclModuleLevelDto rootMenu=menuList.get(0);
        menuList=rootMenu.getAclModuleList();
        return ResultUtil.success(initMenuTree(menuList));
    }

    /**
     * 将dubbo的数据转换本地需要的格式
     * @param menuList
     * @return
     */
    public List<Map<String,Object>> initMenuTree(List<AclModuleLevelDto> menuList){
        List<Map<String,Object>> returnList=new ArrayList<Map<String, Object>>();
        for(int i=0;i<menuList.size();i++){
            Map<String,Object> returnMap=new HashMap<String, Object>();
            AclModuleLevelDto oneMenu=menuList.get(i);
            returnMap.put("text",oneMenu.getName());
            returnMap.put("sortorder",oneMenu.getSeq());
            returnMap.put("id",oneMenu.getId());
            returnMap.put("iconCls",oneMenu.getRemark());

            List<AclDto> aclList=oneMenu.getAclList();
            if(aclList!=null&&!aclList.isEmpty()){
                Map<String,Object> authMap=new HashMap<String, Object>();
                for(int f=0;f<aclList.size();f++){
                    AclDto aclDto=aclList.get(f);
                    String url=aclDto.getUrl();
                    if(url.contains("app.")||url.contains("Admin.")){
                        returnMap.put("viewType",url);
                    }else{
                        authMap.put(url,true);
                    }
                }
                returnMap.put("authData",authMap);
            }

            List<AclModuleLevelDto> childList=oneMenu.getAclModuleList();
            if(childList!=null&&!childList.isEmpty()){
                returnMap.put("data",initMenuTree(childList));
                returnList.add(returnMap);
            }else{
                returnMap.put("leaf",true);
                if(!StringUtils.isEmpty(returnMap.get("viewType"))){
                    returnList.add(returnMap);
                }
            }


        }
        return returnList;
    }

    /**
     * 获取所有部门
     * @return
     */
    @Override
    public Map<String, Object> getAllDepartment() {
        Response<List<DeptLevelDto>> deptResult=sysTreeService.queryDeptTree();
        Map<String, Object> deptTree=new HashMap<String, Object>();
        deptTree.put("deptList",deptResult.getResult());
        return deptTree;
    }

    /**
     * 根据部门获取人员列表
     *
     * @param departmentId
     * @return
     */
    @Override
    public Map<String, Object> getUserByDepartmentId(String departmentId) {
        Response<List<SysUser>> result=sysUserService.listUsersByDeptId(Integer.parseInt(departmentId));
        return ResultUtil.success(result.getResult());
    }
}

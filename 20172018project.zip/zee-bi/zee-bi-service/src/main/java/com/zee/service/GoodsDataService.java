package com.zee.service;

import com.taobao.api.ApiException;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.Map;

/**
 * @author : chenxiang
 * @date : 2018/7/6
 */
public interface GoodsDataService {
    /**
     * 分页查询
     *
     * @param paramMap
     * @return
     */
    Map<String, Object> list(Map<String, String> paramMap) throws ParseException;

    /**
     * 数据导入
     *
     * @param files
     * @param paramMap
     * @return
     * @throws IOException
     */

    Map<String, Object> importData(MultipartFile[] files, Map<String, String> paramMap) throws IOException, ParseException;

    /**
     * 检查数据导入
     */
    void checkData() throws ApiException;
}

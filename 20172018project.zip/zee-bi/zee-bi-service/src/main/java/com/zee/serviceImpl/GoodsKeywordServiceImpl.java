package com.zee.serviceImpl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.zee.common.IsNumericUtil;
import com.zee.common.DateUtil;
import com.zee.common.ResultUtil;
import com.zee.dao.GoodsKeywordDao;
import com.zee.dao.ShopAgpDao;
import com.zee.model.GoodsKeyword;
import com.zee.model.ShopAgp;
import com.zee.service.GoodsKeywordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @Auther: chenxiang
 * @Date: 2018/7/27/0027 09:47
 * @Description:
 */
@Service
@Transactional(rollbackFor = RuntimeException.class)
public class GoodsKeywordServiceImpl implements GoodsKeywordService {
    @Autowired
    private GoodsKeywordDao goodsKeywordDao;
    @Autowired
    private ShopAgpDao shopAgpDao;
    @Value("${application.id}")
    private String applicationId;


    /**
     * 分页查询
     *
     * @param paramMap
     * @return
     */
    @Override
    public Map<String, Object> list(Map<String, String> paramMap) throws ParseException {
        //获取查询参数
        Integer pageNo = Integer.parseInt(paramMap.get("page"));
        Integer pageSize = Integer.parseInt(paramMap.get("limit"));
        String shopId = paramMap.get("shopId");
        String beginTimeStr = paramMap.get("beginTime");
        String endTimeStr = paramMap.get("endTime");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Calendar calendar = Calendar.getInstance();
        Date beginTime = null;
        Date endTime = null;
        Page<GoodsKeyword> page = new Page<GoodsKeyword>(pageNo, pageSize);
        EntityWrapper<GoodsKeyword> ew = new EntityWrapper<GoodsKeyword>();
        Calendar c = Calendar.getInstance();
        //未指定数据时间情况下默认显示昨天到今天导入文件数据,根据data_date排序
        if (StringUtils.isEmpty(beginTimeStr) && StringUtils.isEmpty(endTimeStr)) {
            c.setTime(new Date());
            c.add(Calendar.DAY_OF_YEAR, -2);
            c.set(Calendar.HOUR_OF_DAY, 23);
            c.set(Calendar.MINUTE, 59);
            c.set(Calendar.SECOND, 59);
            ew.like(!StringUtils.isEmpty(shopId), "shop_id", shopId)
                    .between("update_time", c.getTime(), new Date())
                    .orderBy("data_date", false);
            return ResultUtil.success(goodsKeywordDao.selectPage(page, ew), goodsKeywordDao.selectCount(ew));
        }
        //指定时间情况下,对时间参数进行处理
        else {
            beginTime = DateUtil.setTimeParam(beginTimeStr, endTimeStr).get("beginTime");
            endTime = DateUtil.setTimeParam(beginTimeStr, endTimeStr).get("endTime");
            ew.like(!StringUtils.isEmpty(shopId), "shop_id", shopId)
                    .between("data_date", beginTime, endTime)
                    .orderBy("update_time", false);
            return ResultUtil.success(goodsKeywordDao.selectPage(page, ew), goodsKeywordDao.selectCount(ew));
        }
    }


    /**
     * 导入数据
     *
     * @param files
     * @param paramMap
     * @return
     * @throws IOException
     * @throws ParseException
     */
    @Override
    public Map<String, Object> importData(MultipartFile[] files, Map<String, String> paramMap) throws IOException, ParseException {
        String shopId = paramMap.get("shopId");
        String shopName = paramMap.get("shopName");
        String userName = paramMap.get("userName");
        String userId = paramMap.get("userId");
        List<GoodsKeyword> goodsKeywordList = new ArrayList<>(4000);
        for (int i = 0; i < files.length; i++) {
            System.out.print(">>>>>>>>>开始解析第" + (i + 1) + "个文件!");
            String fileName = files[i].getOriginalFilename().toLowerCase();
            Boolean isExcel = fileName.endsWith(".csv");
            String dateTime = fileName.split("-")[1];
            Date dateData = new SimpleDateFormat("yyyyMMdd").parse(dateTime);
            if (!isExcel) {
                return ResultUtil.failure("文件格式错误,请上传csv文件!");
            }
            InputStream is = files[i].getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "gbk"));
            List<GoodsKeyword> resultList = readerExcel(reader);
            reader.close();
            is.close();
            //批量插入GoodsKeyword
            if (!resultList.isEmpty()) {
                resultList.remove(0);
                for (GoodsKeyword goodsKeyword : resultList) {
                    goodsKeyword.setId(UUID.randomUUID().toString().replace("-", ""));
                    goodsKeyword.setShopName(shopName);
                    goodsKeyword.setShopId(shopId);
                    goodsKeyword.setUserName(userName);
                    goodsKeyword.setUserId(userId);
                    goodsKeyword.setDataDate(dateData);
                }
                goodsKeywordList.addAll(resultList);
            }
        }
        if (!goodsKeywordList.isEmpty()) {
            System.out.println("开始插入" + goodsKeywordList.size() + "条数据>>>>>");
            goodsKeywordDao.batchInsert(goodsKeywordList);
        }
        return ResultUtil.success("成功上传" + goodsKeywordList.size() + "条数据!");
    }

    /**
     * 解析Excel文件
     *
     * @param reader
     * @return
     */
    private List<GoodsKeyword> readerExcel(BufferedReader reader) throws IOException {
        String line = null;
        List<GoodsKeyword> goodsKeywordList = new ArrayList<>(1000);
        GoodsKeyword goodsKeyword;
        while ((line = reader.readLine()) != null) {
            String items[] = line.split(",", -1);
            goodsKeyword = new GoodsKeyword();
            int i = 0;
            //宝贝ID

            if (items[i] != null) {
                goodsKeyword.setGoodsId(items[i]);
            }
            //宝贝标题
            if (items[++i] != null) {
                goodsKeyword.setTitle(items[i]);
            }
            //宝贝链接
            if (items[++i] != null) {
                goodsKeyword.setUrl(items[i]);
            }
            //搜索类型
            if (items[++i] != null) {
                goodsKeyword.setSearchType(items[i]);
            }
            //关键词
            if (items[++i] != null) {
                goodsKeyword.setKeyWord(items[i]);
            }
            //直接访客数（UV）
            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsKeyword.setDirectUv(Integer.parseInt(items[i]));
                }
            }
            //跳失率
            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    goodsKeyword.setBounceRate(Float.parseFloat(items[i].split("%")[0]));
                }
            }
            //直接销售量（件）
            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsKeyword.setDirectPayGoods(Integer.parseInt(items[i]));
                }
            }
            //直接转化率
            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    goodsKeyword.setDirectPayConversion(Float.parseFloat(items[i].split("%")[0]));
                }
            }
            //间接销售量（件）
            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsKeyword.setIndirectPayGoods(Integer.parseInt(items[i]));
                }
            }
            //直接订单数（笔）
            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsKeyword.setDirectOrderCount(Integer.parseInt(items[i]));
                }
            }
            goodsKeywordList.add(goodsKeyword);
        }
        return goodsKeywordList;
    }
}
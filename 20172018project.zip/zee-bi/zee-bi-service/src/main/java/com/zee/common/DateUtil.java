package com.zee.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @Auther: chenxiang
 * @Date: 2018/8/7/0007 17:04
 * @Description: 分表查询时间参数设置
 */
public class DateUtil {

    /**
     * 根据传递的时间参数设置查询时间
     *
     * @param beginTimeStr
     * @param endTimeStr
     * @return
     */
    public static Map<String, Date> setTimeParam(String beginTimeStr, String endTimeStr) {
        final Logger logger = LoggerFactory.getLogger(DateUtil.class);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Calendar calendar = Calendar.getInstance();
        Date beginTime = null;
        Date endTime = null;
        Map<String, Date> resultMap = new HashMap<>(2);
        try {
            if (StringUtils.isEmpty(beginTimeStr)) {
                calendar.setTime(new Date());
                calendar.add(Calendar.DAY_OF_YEAR, -2);
                calendar.set(Calendar.HOUR_OF_DAY, 23);
                calendar.set(Calendar.MINUTE, 59);
                calendar.set(Calendar.MILLISECOND, 59);
                beginTime = calendar.getTime();
            } else {
                beginTimeStr = beginTimeStr + " 00:00:00";
                calendar.setTime(sdf.parse(beginTimeStr));
                calendar.add(Calendar.DAY_OF_YEAR, -1);
                calendar.set(Calendar.HOUR_OF_DAY, 23);
                calendar.set(Calendar.MINUTE, 59);
                calendar.set(Calendar.SECOND, 59);
                beginTime = calendar.getTime();
            }
            if (StringUtils.isEmpty(endTimeStr)) {
                calendar.setTime(new Date());
                calendar.set(Calendar.HOUR_OF_DAY, 23);
                calendar.set(Calendar.MINUTE, 59);
                calendar.set(Calendar.SECOND, 59);
                endTime = calendar.getTime();
            } else {
                endTimeStr = endTimeStr + " 23:59:59";
                endTime = sdf.parse(endTimeStr);
            }
        } catch (ParseException e) {
            logger.error(e.getMessage(), e);
        }
        resultMap.put("beginTime", beginTime);
        resultMap.put("endTime", endTime);
        return resultMap;
    }

    /**
     * 返回两个日日期间的所有日期集合
     *
     * @param beginDate
     * @param endDate
     * @return
     */
    public static List<Date> getDatesBetweenTwoDate(Date beginDate, Date endDate) {
        List<Date> dateList = new ArrayList<>();
        Calendar c = Calendar.getInstance();
        c.setTime(beginDate);
        boolean bContinue = true;
        Date date;
        while (bContinue) {
            // 根据日历的规则，为给定的日历字段添加或减去指定的时间量
            c.add(Calendar.DAY_OF_YEAR, +1);
            // 测试此日期是否在指定日期之后
            c.set(Calendar.HOUR_OF_DAY, 0);
            c.set(Calendar.MINUTE, 0);
            c.set(Calendar.SECOND, 0);
            date=c.getTime();
            if (endDate.after(date)) {
                dateList.add(date);
            } else {
                break;
            }
        }
        return dateList;
    }

    /**
     * 返回两个日期列表的差集
     *
     * @param dataDateList
     * @param dateList
     * @return
     */
    public static List<String> findDifferenceBetwwenTwoDateList(List<Date> dataDateList, List<Date> dateList) {
        List<Date> difference = new ArrayList<>(100);
        List<String> dateStrList = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String dateStr;
        for (Date date : dateList) {
            if (dataDateList.contains(date)) {
                continue;
            } else {
                difference.add(date);
            }
        }
        if (difference != null && !difference.isEmpty()) {
            for (Date date : difference) {
                dateStr = sdf.format(date);
                dateStrList.add(dateStr);
            }
        }
        Collections.sort(dateStrList);
        return dateStrList;

    }
}

package com.zee.common;

/**
 * @Author: gaoruyi
 * @Description: 工作流相关业务定义
 * @Date: Created in 下午3:45 2018/3/29
 * @Modified By:
 * Copyright(c) zeeic.com
 */
public interface Constants {
    /**
     * 流程变量名,业务数据id
     */
    String BUSINESS_KEY = "businessKey";
    /**
     * 是否需要执行监听器
     */
    String IS_NEED_LISTENER = "isNeedListener";

    /**
     * 流程变量名,发起人部门id
     */
    String DEPT_ID = "deptId";

    /**
     * 流程统一发起节点的taskdefineKey
     */
    String START_TASK_DEFKEY = "startTaskDefineKey";
    /**
     * 岗位审核级别常量
     */
    String WORKFLOW_AUDIT_LEVEL= "workflow_audit_level";
    /**
     * 待办消息变量
     */
    String WORKFLOW_BLOG_MESSAGE = "backlogManage";
}

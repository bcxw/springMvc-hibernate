package com.zee.task;

import com.zee.service.*;
import com.zee.serviceImpl.OrderServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;


/**
 * @author : chenxiang
 * @date : 2018/6/21
 */
@Component
@Transactional(rollbackFor = RuntimeException.class)
public class JuShuiTanDataSyncTask {
    private static final Logger logger = LoggerFactory.getLogger(JuShuiTanDataSyncTask.class);
    @Autowired
    private ShopBaseService shopBaseService;
    @Autowired
    private SiteGoodsService siteGoodsService;
    @Autowired
    private GoodsMappingService goodsMappingService;
    @Autowired
    private ReturnGoodsService returnGoodsService;
    @Autowired
    private OrderServiceImpl orderService;
    @Autowired
    private InventoryService inventoryService;

    /**
     * 12小时一次获取店铺数据,退换货
     */
    @Scheduled(fixedRate = 43200000)
    public void syncOneDay() {
        shopBaseService.fetchShop();

    }

    /**
     * 6小时一次获取平台商品,订单,商品映射关系
     */
    @Scheduled(fixedRate = 21600000)
    public void syncSixHour() {
        //siteGoodsService.fetchSiteGoods(1);
        orderService.fetchOrder(1,null);
        goodsMappingService.fetchGoodsMapping(1,null);
        returnGoodsService.fetchReturnGoods(1,null);
    }

    /**
     * 一小时获取一次库存数据
     */
    @Scheduled(fixedRate = 3600000)
    public void syncOneHour() {
        inventoryService.fetchInventory(1,null);
    }

}
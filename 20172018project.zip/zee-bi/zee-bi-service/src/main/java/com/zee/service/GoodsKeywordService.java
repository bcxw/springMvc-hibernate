package com.zee.service;

import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.Map;

/**
 * @Auther: chenxiang
 * @Date: 2018/7/27/0027 09:46
 * @Description:
 */
public interface GoodsKeywordService {

    /**
     * 查询分页
     *
     * @param paramMap
     * @return
     */
    Map<String, Object> list(Map<String, String> paramMap) throws ParseException;

    /**
     * 数据导入
     *
     * @param files
     * @param paramMap
     * @return
     * @throws IOException
     */
    Map<String, Object> importData(MultipartFile[] files, Map<String, String> paramMap) throws IOException, ParseException;

}

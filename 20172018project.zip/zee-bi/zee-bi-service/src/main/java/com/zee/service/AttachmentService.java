package com.zee.service;

import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Map;

/**
 * 附件管理
 */
public interface AttachmentService {

    /**
     * 上传文件
     * @param file
     * @return 文件id
     */
    String upload(MultipartFile file)throws IOException;

    /**
     * 通过id获取文件路径
     * @param id
     * @return
     */
    Map<String,String> getFile(String id);


}

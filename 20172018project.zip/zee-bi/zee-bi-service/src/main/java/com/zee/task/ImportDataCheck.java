package com.zee.task;

import com.taobao.api.ApiException;
import com.zee.model.GoodsData;
import com.zee.model.GoodsKeyword;
import com.zee.service.GoodsDataService;
import com.zee.service.GoodsKeywordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;

/**
 * @Auther: chenxiang
 * @Date: 2018/8/9/0009 10:04
 * @Description:定时检查数据导入
 */
@Component
@Transactional(rollbackFor = RuntimeException.class)
public class ImportDataCheck {
    @Autowired
    private GoodsDataService goodsDataService;

    /**
     * 24小时检查一次商品数据和关键词数据是否导入
     *
     * @throws ApiException
     */
    @Scheduled(cron = "0 0 14 * * ?")
    public void checkData() throws ApiException, ParseException {
        goodsDataService.checkData();
    }
}

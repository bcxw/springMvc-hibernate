package com.zee.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author : chenxiang
 * @date : 2018/7/9
 */
public class IsNumericUtil {
    //判断是否为数字(包括整数与小数)
    public static Boolean isNumeric(String str) {
        String regEx = "^[0-9]+([.]{1}[0-9]+){0,1}$";
        Pattern pattern = Pattern.compile(regEx);
        // 忽略大小写的写法
        Matcher matcher = pattern.matcher(str);
        boolean rs = matcher.find();
        return rs;
    }
}

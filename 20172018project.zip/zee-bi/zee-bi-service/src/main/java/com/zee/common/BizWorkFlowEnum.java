package com.zee.common;

/**
 * 工作流业务枚举
 * Created by gaoruyi on 2018/4/2.
 */
public enum BizWorkFlowEnum {

    PRODUCT_ORDER("product_order", "产品下单") ;

    private String bizCode;

    private String bizName;

    BizWorkFlowEnum(String bizCode, String bizName){
        this.bizCode =  bizCode;
        this.bizName = bizName;
    }

    public String getBizCode() {
        return bizCode;
    }

    public String getBizName() {
        return bizName;
    }

}

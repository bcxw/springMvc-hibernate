package com.zee.serviceImpl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.zee.common.ResultUtil;
import com.zee.dao.GoodsDataDao;
import com.zee.dao.InventoryDao;
import com.zee.dao.QueryTimeDao;
import com.zee.jushuitanApi.Api.OpenSearch;
import com.zee.jushuitanApi.Models.JobModel;
import com.zee.model.Inventory;
import com.zee.model.QueryTime;
import com.zee.service.InventoryService;
import com.zee.task.JuShuiTanDataSyncTask;
import org.apache.commons.collections4.Put;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Clock;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author : chenxiang
 * @date : 2018/6/22
 * 仓库服务实现类
 */
@Transactional(rollbackFor = RuntimeException.class)
@Service
public class InventoryServiceImpl implements InventoryService {
    private static final Logger logger = LoggerFactory.getLogger(JuShuiTanDataSyncTask.class);
    private static final String queryType = "inventory";
    @Autowired
    private InventoryDao inventoryDao;
    @Autowired
    private GoodsDataDao goodsDataDao;
    @Autowired
    private QueryTimeDao queryTimeDao;
    @Value("${jushuitan.url}")
    private String url;
    @Value("${jushuitan.partnerId}")
    private String partnerId;
    @Value("${jushuitan.partnerKey}")
    private String partnerKey;
    @Value("${jushuitan.token}")
    private String token;

    /**
     * 同步聚水潭库存数据
     *
     * @param pageIndex
     */
    @Override
    public void fetchInventory(int pageIndex, String startDate) {
        String beginTime;
        String endTime;
        //获取仓库信息
        String method = "inventory.query";
        OpenSearch os = new OpenSearch(partnerId, partnerKey, token, method, url);
        JobModel jobModel = new JobModel();
        Map<String, Object> queryMap = new HashMap<>();
        queryMap.put("page_index", pageIndex);
        queryMap.put("page_size", 50);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (StringUtils.isEmpty(startDate)) {
            startDate = queryTimeDao.selectLastTime(queryType);
        }
        //每次查询以上次结束时间作为此次开始时间;上次结束为空时,开始时间为当前时间天数-1
        Calendar calendar = Calendar.getInstance();
        if (StringUtils.isEmpty(startDate)) {
            calendar.setTime(new Date());
            endTime = simpleDateFormat.format(calendar.getTime());
            calendar.add(Calendar.DAY_OF_YEAR, -1);
            beginTime = simpleDateFormat.format(calendar.getTime());
        } else {
            try {
                calendar.setTime(simpleDateFormat.parse(startDate));
            } catch (ParseException e) {
                logger.error(e.getMessage(), e);
            }
            beginTime = simpleDateFormat.format(calendar.getTime());
            endTime = simpleDateFormat.format(new Date());
        }
        queryMap.put("modified_end", endTime);
        queryMap.put("modified_begin", beginTime);
        jobModel.setData(JSON.toJSONString(queryMap));
        try {
            System.out.println(">>>>>>>开始同步聚水潭库存数据");
            String sData = os.QueryData(jobModel);
            JSONObject jsonObject = JSON.parseObject(sData);
            if ("0".equals(jsonObject.get("code") + "")) {
                JSONArray jsonArray = jsonObject.getJSONArray("inventorys");
                if (jsonArray != null && !jsonArray.isEmpty()) {
                    System.out.println(">>>>>>>开始保存库存数据");
                    saveInventory(jsonArray, beginTime, endTime);
                    boolean has_next = jsonObject.getBoolean("has_next");
                    if (has_next) {
                        pageIndex++;
                        fetchInventory(pageIndex, startDate);
                        logger.info("获取聚水潭库存页数:" + pageIndex);
                    }
                } else {
                    logger.info("聚水潭无数据信息" + jsonObject.get("msg"));
                }
            } else {
                logger.error("获取库存信息失败 " + jsonObject.get("msg"));
            }
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        } catch (ParseException e) {
            logger.error(e.getMessage(), e);
        }
        QueryTime queryTime = new QueryTime();
        queryTime.setEndTime(endTime);
        queryTime.setQueryType(queryType);
        queryTimeDao.insert(queryTime);
    }

    /**
     * 库存预警信息展示
     *
     * @param paramMap
     * @return
     */
    @Override
    public Map<String, Object> list(Map<String, String> paramMap) {
        Page<Inventory> page = new Page<Inventory>(Integer.valueOf(paramMap.get("page")), Integer.valueOf(paramMap.get("limit")));
        String skuId = paramMap.get("skuId");
        EntityWrapper<Inventory> ew = new EntityWrapper<Inventory>();
        ew.like(!StringUtils.isEmpty(skuId), "sku_id", skuId)
                .orderBy("residue_days", false);
        return ResultUtil.success(inventoryDao.selectPage(page, ew), inventoryDao.selectCount(ew));
    }


    /**
     * 保存库存数据
     *
     * @param jsonArray
     */
    private void saveInventory(JSONArray jsonArray, String beginTime, String endTime) throws ParseException {
        EntityWrapper<Inventory> ew = new EntityWrapper<Inventory>();
        ew.le("modified", endTime).ge("modified ", beginTime);
        Map<String, Object> paramMap = new HashMap<>(10);
        List<Inventory> inventoryList = new ArrayList<Inventory>(100);
        //获取过去7天商品数据,计算平均数据
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String maxDateTime = sdf.format(new Date());
        Date date = sdf.parse(maxDateTime);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_YEAR, -7);
        Date date1 = calendar.getTime();
       // String startTime = sdf.format(date1);
        paramMap.put("beginTime", date1);
        paramMap.put("endTime", new Date());
        for (int i = 0; jsonArray != null && i < jsonArray.size(); i++) {
            Inventory inventory = jsonArray.getObject(i, Inventory.class);
            paramMap.put("skuId", inventory.getSkuId());
            //获取7天平均数据
            Map<String, Object> resultMap = goodsDataDao.selectResidueDays(paramMap);
            if (resultMap != null) {
                if (resultMap.get("avgPayGoods") != null) {
                    float avgSale = Float.parseFloat(resultMap.get("avgPayGoods").toString());
                    //前7天平均销售额为0,标识滞销,用1000标识
                    if (avgSale == 0.0) {
                        inventory.setResidueDays(1000);
                    } else {
                        inventory.setResidueDays(inventory.getQty() / avgSale);
                    }

                }
                if (resultMap.get("avgPv") != null) {
                    float avgPv = Float.parseFloat(resultMap.get("avgPv").toString());
                    inventory.setAvgPv(avgPv);
                }
                if (resultMap.get("avgUv") != null) {
                    float avgUv = Float.parseFloat(resultMap.get("avgUv").toString());
                    inventory.setAvgUv(avgUv);
                }


            }
            inventory.setId(UUID.randomUUID().toString().replace("-", ""));
            inventoryList.add(inventory);
        }
        if (inventoryList != null && !inventoryList.isEmpty()) {
            inventoryDao.batchInsert(inventoryList);
        }
    }
}

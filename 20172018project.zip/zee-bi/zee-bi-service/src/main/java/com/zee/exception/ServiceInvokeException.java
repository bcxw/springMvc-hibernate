package com.zee.exception;



/**
 *
 * 自定义异常类
 * 支持参数动态添加
 */
public class ServiceInvokeException extends RuntimeException {
    private static final long serialVersionUID = 2669040717172917220L;

    private ServiceInvokeException() {}

    private ServiceInvokeException(String message) {
        super(message);
    }

    private ServiceInvokeException(Throwable innerException) {
        super(innerException);
    }

    private ServiceInvokeException(String message, Throwable innerException) {
        super(message, innerException);
    }

    /**
     * 支持动态添加参数
     * 
     * @param message
     * @param parameters
     * @return
     */
    public static ServiceInvokeException newException(String message, String... parameters) {
        return newException(null, message, parameters);
    }

    public static ServiceInvokeException newException(Throwable innerException, String message, String... parameters) {
        StringBuilder result = new StringBuilder(message);
        if (parameters != null) {
            for (int i = 0; i < parameters.length; ++i) {
                String parameterName = "{" + i + "}";
                int indexFound = result.indexOf(parameterName);
                while (indexFound >= 0) {
                    result.replace(indexFound, indexFound + parameterName.length(), parameters[i]);
                    indexFound = result.indexOf(parameterName, indexFound);
                }
            }
        }
        if (innerException == null) {
            return new ServiceInvokeException(result.toString());
        } else {
            return new ServiceInvokeException(result.toString(), innerException);
        }

    }

    public static ServiceInvokeException newException(String message) {

        return new ServiceInvokeException(message);
    }

    public static ServiceInvokeException newException(String message,  Throwable innerException) {

        return new ServiceInvokeException(message, innerException);
    }
}

package com.zee.serviceImpl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.taobao.api.ApiException;
import com.zee.common.IsNumericUtil;
import com.zee.common.DateUtil;
import com.zee.common.ResultUtil;
import com.zee.dao.*;
import com.zee.dto.DingtalkMessageResponse;
import com.zee.model.*;
import com.zee.service.DingtalkMessageService;
import com.zee.service.GoodsDataService;
import com.zee.vo.GoodsIndexVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author : chenxiang
 * @date : 2018/7/6
 */
@Transactional(rollbackFor = RuntimeException.class)
@Service
public class GoodsDataServiceImpl implements GoodsDataService {
    @Autowired
    private GoodsDataDao goodsDataDao;
    @Autowired
    private GoodsDataMpDao goodsDataMpDao;
    @Autowired
    private GoodsDataPcDao goodsDataPcDao;
    @Autowired
    private GoodsMappingDao goodsMappingDao;
    @Autowired
    private ShopAgpDao shopAgpDao;
    @Autowired
    private GoodsKeywordDao goodsKeywordDao;
    @Autowired
    private ShopBasePeopleDao shopBasePeopleDao;
    @Reference(version = "1.0.0")
    private DingtalkMessageService dingtalkMessageService;
    @Value("${application.id}")
    private String applicationId;

    /**
     * 列表显示分页
     *
     * @param paramMap
     * @return
     */
    @Override
    public Map<String, Object> list(Map<String, String> paramMap) throws ParseException {
        // 获取查询参数
        Integer pageNo = Integer.parseInt(paramMap.get("page"));
        Integer pageSize = Integer.parseInt(paramMap.get("limit"));
        String shopId = paramMap.get("shopId");
        String beginTimeStr = paramMap.get("beginTime");
        String endTimeStr = paramMap.get("endTime");
        String skuId = paramMap.get("skuId");
        String goodsId = paramMap.get("goodsId");
        String action = paramMap.get("action");
        Date beginTime = null;
        Date endTime = null;
        // 当action=import时显示最近导入excel文件的数据
        Page<GoodsData> page = new Page<GoodsData>(pageNo, pageSize);
        Page<GoodsDataMp> page1 = new Page<GoodsDataMp>(pageNo, pageSize);
        Page<GoodsDataPc> page2 = new Page<GoodsDataPc>(pageNo, pageSize);
        Page<GoodsMapping> page3 = new Page<GoodsMapping>(pageNo, pageSize);
        EntityWrapper<GoodsData> ew = new EntityWrapper<GoodsData>();
        EntityWrapper<GoodsDataMp> ew1 = new EntityWrapper<GoodsDataMp>();
        EntityWrapper<GoodsDataPc> ew2 = new EntityWrapper<GoodsDataPc>();
        EntityWrapper<GoodsMapping> ew3 = new EntityWrapper<GoodsMapping>();
        Calendar c = Calendar.getInstance();
        if ("import".equals(action)) {
            // 未指定数据时间情况下默认显示昨天到今天导入文件数据,根据data_date排序
            if (StringUtils.isEmpty(beginTimeStr) && StringUtils.isEmpty(endTimeStr)) {
                c.setTime(new Date());
                c.add(Calendar.DAY_OF_YEAR, -2);
                c.set(Calendar.HOUR_OF_DAY, 23);
                c.set(Calendar.MINUTE, 59);
                c.set(Calendar.SECOND, 59);
                ew.like(!StringUtils.isEmpty(goodsId), "goods_id", goodsId)
                        .like(!StringUtils.isEmpty(shopId), "shop_id", shopId)
                        .between("update_time", c.getTime(), new Date()).orderBy("update_time", false);
                return ResultUtil.success(goodsDataDao.selectPage(page, ew), goodsDataDao.selectCount(ew));
            }
            // 指定时间情况下,对时间参数进行处理
            else {
                beginTime = DateUtil.setTimeParam(beginTimeStr, endTimeStr).get("beginTime");
                endTime = DateUtil.setTimeParam(beginTimeStr, endTimeStr).get("endTime");
                ew.like(!StringUtils.isEmpty(goodsId), "goods_id", goodsId)
                        .like(!StringUtils.isEmpty(shopId), "shop_id", shopId).between("data_date", beginTime, endTime)
                        .orderBy("data_date", false);
                return ResultUtil.success(goodsDataDao.selectPage(page, ew), goodsDataDao.selectCount(ew));
            }
        }
        // 否则查询所有数据
        else {
            beginTime = DateUtil.setTimeParam(beginTimeStr, endTimeStr).get("beginTime");
            endTime = DateUtil.setTimeParam(beginTimeStr, endTimeStr).get("endTime");
            List<GoodsIndexVO> voList = new ArrayList<>(1000);
            List<GoodsData> goodsDataList = new ArrayList<>(16);
            List<GoodsDataMp> mpList = new ArrayList<>(16);
            List<GoodsDataPc> pcList = new ArrayList<>(16);
            List<GoodsMapping> mappingList = new ArrayList<>(16);
            List<String> goodsIdList = new ArrayList<>(16);
            // 查询参数skuId不为空
            if (!StringUtils.isEmpty(skuId)) {
                ew3.like("sku_id", skuId);
                mappingList = goodsMappingDao.selectList(ew3);
                if (mappingList != null && !mappingList.isEmpty()) {
                    for (GoodsMapping gm : mappingList) {
                        goodsIdList.add(gm.getShopIId());
                    }
                    ew.like(!StringUtils.isEmpty(shopId), "shop_id", shopId).in("goods_id", goodsIdList)
                            .between("data_date", beginTime, endTime).orderBy("data_date", false);
                    goodsDataList = goodsDataDao.selectPage(page, ew);

                    ew1.like(!StringUtils.isEmpty(shopId), "shop_id", shopId).in("goods_id", goodsIdList)
                            .between("data_date", beginTime, endTime).orderBy("data_date", false);
                    mpList = goodsDataMpDao.selectPage(page, ew1);
                    ew2.like(!StringUtils.isEmpty(shopId), "shop_id", shopId).in("goods_id", goodsIdList)
                            .between("data_date", beginTime, endTime).orderBy("data_date", false);
                    pcList = goodsDataPcDao.selectPage(page, ew2);
                    voList = setGoodsVO(goodsDataList, pcList, mpList, mappingList);
                }
            } // 查询参数skuId为空
            else {
                ew.like(!StringUtils.isEmpty(shopId), "shop_id", shopId).between("data_date", beginTime, endTime)
                        .orderBy("data_date", false);
                goodsDataList = goodsDataDao.selectPage(page, ew);
                ew1.like(!StringUtils.isEmpty(shopId), "shop_id", shopId).between("data_date", beginTime, endTime)
                        .orderBy("data_date", false);
                mpList = goodsDataMpDao.selectPage(page, ew1);
                ew2.like(!StringUtils.isEmpty(shopId), "shop_id", shopId).between("data_date", beginTime, endTime)
                        .orderBy("data_date", false);
                pcList = goodsDataPcDao.selectPage(page, ew2);

                for (GoodsData gd : goodsDataList) {
                    goodsIdList.add(gd.getGoodsId());
                }
                ew3.in("shop_i_id", goodsIdList);
                mappingList = goodsMappingDao.selectList(ew3);
                voList = setGoodsVO(goodsDataList, pcList, mpList, mappingList);

            }
            return ResultUtil.success(voList, goodsDataDao.selectCount(ew));
        }

    }

    /**
     * 将不同表查询结果放在VO类中
     *
     * @param goodsDataList
     * @param pcList
     * @param mpList
     * @param mappingList
     * @return
     */
    private List<GoodsIndexVO> setGoodsVO(List<GoodsData> goodsDataList, List<GoodsDataPc> pcList,
                                          List<GoodsDataMp> mpList, List<GoodsMapping> mappingList) {
        List<GoodsIndexVO> voList = new ArrayList<>(500);
        if (goodsDataList != null && !goodsDataList.isEmpty()) {
            for (GoodsData gd : goodsDataList) {
                GoodsIndexVO goodsIndexVO = new GoodsIndexVO();
                goodsIndexVO.setGoodsId(gd.getGoodsId());
                goodsIndexVO.setPv(gd.getPv());
                goodsIndexVO.setUv(gd.getUv());
                goodsIndexVO.setUrl(gd.getUrl());
                goodsIndexVO.setTransactionNumber(gd.getTransactionNumber());
                goodsIndexVO.setTitle(gd.getTitle());
                goodsIndexVO.setShoppingCartGoodsNumber(gd.getShoppingCartGoodsNumber());
                goodsIndexVO.setShoppingCartCustomerNumber(gd.getShoppingCartCustomerNumber());
                goodsIndexVO.setShopName(gd.getShopName());
                goodsIndexVO.setShopId(gd.getShopId());
                goodsIndexVO.setSearchUv(gd.getSearchUv());
                goodsIndexVO.setRefundRate(gd.getRefundRate());
                goodsIndexVO.setRefundMoney(gd.getRefundMoney());
                goodsIndexVO.setRefundCount(gd.getRefundCount());
                goodsIndexVO.setPayMoney(gd.getPayMoney());
                goodsIndexVO.setPayGoods(gd.getPayGoods());
                goodsIndexVO.setPayConversion(gd.getPayConversion());
                goodsIndexVO.setOldUv(gd.getOldUv());
                goodsIndexVO.setOldTransactionNumber(gd.getOldTransactionNumber());
                goodsIndexVO.setOldPayMoney(gd.getOldPayMoney());
                goodsIndexVO.setOldPayGoods(gd.getOldPayGoods());
                goodsIndexVO.setOldPayConversion(gd.getOldPayConversion());
                goodsIndexVO.setMerchantCode(gd.getMerchantCode());
                goodsIndexVO.setIndustryType(gd.getIndustryType());
                goodsIndexVO.setExitNumber(gd.getExitNumber());
                goodsIndexVO.setEntranceNumber(gd.getEntranceNumber());
                goodsIndexVO.setCollectionNumber(gd.getCollectionNumber());
                goodsIndexVO.setAvgStayTime(gd.getAvgStayTime());
                goodsIndexVO.setBounceRate(gd.getBounceRate());
                goodsIndexVO.setDataDate(gd.getDataDate());
                // 无线端数据
                if (mpList != null && !mpList.isEmpty()) {
                    for (GoodsDataMp mp : mpList) {
                        if (gd.getGoodsId().equals(mp.getGoodsId()) && gd.getShopName().equals(mp.getShopName())
                                && gd.getDataDate().equals(mp.getDataDate())) {
                            goodsIndexVO.setMpAvgStayTime(mp.getMpAvgStayTime());
                            goodsIndexVO.setMpBounceRate(mp.getMpBounceRate());
                            goodsIndexVO.setMpEntranceNumber(mp.getMpEntranceNumber());
                            goodsIndexVO.setMpExitNumber(mp.getMpExitNumber());
                            goodsIndexVO.setMpPayConversion(mp.getMpPayConversion());
                            goodsIndexVO.setMpPayGoods(mp.getMpPayGoods());
                            goodsIndexVO.setMpPayMoney(mp.getMpPayMoney());
                            goodsIndexVO.setMpPv(mp.getMpPv());
                            goodsIndexVO.setMpSearchUv(mp.getMpSearchUv());
                            goodsIndexVO.setMpTransactionNumber(mp.getMpTransactionNumber());
                            goodsIndexVO.setMpUv(mp.getMpUv());
                            continue;

                        }
                    }
                }
                // pc端商品数据
                if (pcList != null && !pcList.isEmpty()) {
                    for (GoodsDataPc pc : pcList) {
                        if (gd.getGoodsId().equals(pc.getGoodsId()) && gd.getShopName().equals(pc.getShopName())
                                && gd.getDataDate().equals(pc.getDataDate())) {
                            goodsIndexVO.setPcAvgStayTime(pc.getPcAvgStayTime());
                            goodsIndexVO.setPcBounceRate(pc.getPcBounceRate());
                            goodsIndexVO.setPcCollectionUv(pc.getPcCollectionUv());
                            goodsIndexVO.setPcEntranceNumber(pc.getPcEntranceNumber());
                            goodsIndexVO.setPcExitNumber(pc.getPcExitNumber());
                            goodsIndexVO.setPcPayConversion(pc.getPcPayConversion());
                            goodsIndexVO.setPcPayGoods(pc.getPcPayGoods());
                            goodsIndexVO.setPcPayMoney(pc.getPcPayMoney());
                            goodsIndexVO.setPcPv(pc.getPcPv());
                            goodsIndexVO.setPcSearchUv(pc.getPcSearchUv());
                            goodsIndexVO.setPcUv(pc.getPcUv());
                            goodsIndexVO.setPcTbkUv(pc.getPcTbkUv());
                            goodsIndexVO.setPcTransactionNumber(pc.getPcTransactionNumber());
                            goodsIndexVO.setPcTypeUv(pc.getPcTypeUv());
                            goodsIndexVO.setPcZtcUv(pc.getPcZtcUv());
                            continue;
                        }


                    }

                }
                // 映射关系
                if (mappingList != null && !mappingList.isEmpty()) {
                    for (GoodsMapping gm : mappingList) {
                        if (gd.getGoodsId().equals(gm.getShopIId())) {
                            goodsIndexVO.setShopIId(gm.getShopIId());
                            goodsIndexVO.setIId(gm.getIId());
                            goodsIndexVO.setShopSkuId(gm.getShopSkuId());
                            goodsIndexVO.setSkuId(gm.getSkuId());
                            continue;
                        }
                    }
                }
                voList.add(goodsIndexVO);
            }
        }


        return voList;
    }

    /**
     * 数据导入
     *
     * @param files
     * @param paramMap
     * @return
     * @throws IOException
     */
    @Override
    public Map<String, Object> importData(MultipartFile[] files, Map<String, String> paramMap)
            throws IOException, ParseException {
        String shopId = paramMap.get("shopId");
        String shopName = paramMap.get("shopName");
        String userName = paramMap.get("userName");
        String userId = paramMap.get("userId");
        for (int i = 0; i < files.length; i++) {
            System.out.print(">>>>>>>>>开始解析第" + (i + 1) + "个文件!");
            String fileName = files[i].getOriginalFilename().toLowerCase();
            Boolean isExcel = fileName.endsWith(".csv");
            if (!isExcel) {
                return ResultUtil.failure("文件格式错误,请上传csv文件!");
            }
            InputStream is = files[i].getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "gbk"));
            Map<String, Object> resultMap = readExcel(reader, fileName);
            List<GoodsData> goodsDataList = (List<GoodsData>) resultMap.get("goodsDataList");
            List<GoodsDataMp> goodsDataMpList = (List<GoodsDataMp>) resultMap.get("goodsDataMpList");
            List<GoodsDataPc> goodsDataPcList = (List<GoodsDataPc>) resultMap.get("goodsDataPcList");
            reader.close();
            is.close();
            // 批量插入goodesData
            if (!goodsDataList.isEmpty()) {
                goodsDataList.remove(0);
                for (GoodsData goodsData : goodsDataList) {
                    goodsData.setId(UUID.randomUUID().toString().replace("-", ""));
                    goodsData.setUserName(userName);
                    goodsData.setUserId(userId);
                    goodsData.setShopId(shopId);
                    goodsData.setShopName(shopName);
                }
                goodsDataDao.batchInsert(goodsDataList);
            }
            // 批量插入goodsDataMp
            if (!goodsDataMpList.isEmpty()) {
                goodsDataMpList.remove(0);
                for (GoodsDataMp goodsDataMp : goodsDataMpList) {
                    goodsDataMp.setId(UUID.randomUUID().toString().replace("-", ""));
                    goodsDataMp.setUserName(userName);
                    goodsDataMp.setUserId(userId);
                    goodsDataMp.setShopId(shopId);
                    goodsDataMp.setShopName(shopName);
                }
                goodsDataMpDao.batchInsert(goodsDataMpList);
            }
            // 批量插入goodsDataPc
            if (!goodsDataPcList.isEmpty()) {
                goodsDataPcList.remove(0);
                for (GoodsDataPc goodsDataPc : goodsDataPcList) {
                    goodsDataPc.setId(UUID.randomUUID().toString().replace("-", ""));
                    goodsDataPc.setUserName(userName);
                    goodsDataPc.setUserId(userId);
                    goodsDataPc.setShopId(shopId);
                    goodsDataPc.setShopName(shopName);
                }
                goodsDataPcDao.batchInsert(goodsDataPcList);
            }


        }
        return ResultUtil.success("上传成功!");
    }

    /**
     * 检查数据导入
     */
    @Override
    public void checkData() throws ApiException {
        // 获取数据库类数据最小日期
        Calendar c = Calendar.getInstance();
        Date minGoodsDataDate;
        Date minGoodsKeywqordDataDate;
        EntityWrapper<ShopAgp> ew = new EntityWrapper<ShopAgp>();
        ew.groupBy("shop_name").orderBy("agp_month");
        List<Date> dataDateList;
        List<Date> dateList;
        List<ShopAgp> agpList = shopAgpDao.selectList(ew);
        List<String> emptyDate;
        List<ShopBasePeople> peopleList;
        EntityWrapper<ShopBasePeople> ew1 = new EntityWrapper<>();
        Map<String, Object> pMap = new HashMap<>(16);
        pMap.put("endTime", new Date());
        c.setTime(new Date());
        c.add(Calendar.YEAR, -4);
        pMap.put("startTime", c.getTime());
        List<String> userIds = new ArrayList<>();
        for (ShopAgp sa : agpList) {
            ew1.eq("shop_id", sa.getShopId()).eq("type", "admin");
            peopleList = shopBasePeopleDao.selectList(ew1);
            if (peopleList != null && !peopleList.isEmpty()) {
                for (ShopBasePeople sbp : peopleList) {
                    userIds.add(sbp.getUserId());
                }
            }
            pMap.put("shopId", sa.getShopId());
            minGoodsDataDate = goodsDataDao.findMinDataDate(pMap);
            minGoodsKeywqordDataDate = goodsKeywordDao.findMinDataDate(pMap);
            // 检查每个店铺商品导入的数据
            if (minGoodsDataDate != null) {
                dataDateList = goodsDataDao.selectDataDateByShopId(sa.getShopId(), minGoodsDataDate, new Date());
                dateList = DateUtil.getDatesBetweenTwoDate(minGoodsDataDate, new Date());
                emptyDate = DateUtil.findDifferenceBetwwenTwoDateList(dataDateList, dateList);
                if (emptyDate != null && !emptyDate.isEmpty()) {
                    dingtalkMessageService.sendTextMessage(applicationId, userIds.toString().replace("[", "").replace("]", ""),
                            "BI消息提醒:您有下列日期的商品数据未导入,请及时导入数据!" + emptyDate.toString());
                }
            }
            // 检查每个店铺关键词导入的数据
            if (minGoodsKeywqordDataDate != null) {
                dataDateList =
                        goodsDataDao.selectDataDateByShopId(sa.getShopId(), minGoodsKeywqordDataDate, new Date());
                dateList = DateUtil.getDatesBetweenTwoDate(minGoodsKeywqordDataDate, new Date());
                emptyDate = DateUtil.findDifferenceBetwwenTwoDateList(dataDateList, dateList);
                if (emptyDate != null && !emptyDate.isEmpty()) {
                    dingtalkMessageService.sendTextMessage(applicationId, userIds.toString().replace("[", "").replace("]", ""),
                            "BI消息提醒:您有下列日期的关键词数据未导入,请及时导入数据!" + emptyDate.toString());

                }

            }

        }

    }

    /**
     * 读取Excel文件数据
     *
     * @param reader
     * @return
     * @throws IOException
     */
    private Map<String, Object> readExcel(BufferedReader reader, String fileName) throws IOException, ParseException {
        String line = null;
        Map<String, Object> resultMap = new HashMap<>(16);
        List<GoodsData> goodsDataList = new ArrayList<>(100);
        List<GoodsDataMp> goodsDataMpList = new ArrayList<>(100);
        List<GoodsDataPc> goodsDataPcList = new ArrayList<>(100);
        String[] chips = fileName.split("-");
        String datetime = chips[1];
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Date date = sdf.parse(datetime);
        while ((line = reader.readLine()) != null) {
            String items[] = line.split(",", -1);
            GoodsData goodsData = new GoodsData();
            GoodsDataPc goodsDataPc = new GoodsDataPc();
            GoodsDataMp goodsDataMp = new GoodsDataMp();
            int i = 0;
            goodsData.setDataDate(date);
            goodsDataPc.setDataDate(date);
            goodsDataMp.setDataDate(date);
            // 商品id
            if (items[i] != null) {
                goodsData.setGoodsId(items[i]);
                goodsDataPc.setGoodsId(items[i]);
                goodsDataMp.setGoodsId(items[i]);
            }
            // 商品编码
            if (items[++i] != null) {
                goodsData.setMerchantCode(items[i]);
            }
            // 行业类目
            if (items[++i] != null) {
                goodsData.setIndustryType(items[i]);
            }
            // 宝贝标题
            if (items[++i] != null) {
                goodsData.setTitle(items[i]);
            } // 宝贝链接
            if (items[++i] != null) {
                goodsData.setUrl(items[i]);
            }
            // 浏览量
            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsData.setPv(Integer.parseInt(items[i]));
                }
            }
            // 访客数
            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsData.setUv(Integer.parseInt(items[i]));
                }

            } // 销售额

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsData.setPayMoney(Float.parseFloat(items[i]));
                }

            } // 成交宝贝数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsData.setPayGoods(Integer.parseInt(items[i]));
                }

            } // 交易笔数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsData.setTransactionNumber(Integer.parseInt(items[i]));
                }

            } // 转化率

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    goodsData.setPayConversion(Float.parseFloat(items[i].split("%")[0]));
                }

            } // 入口数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsData.setEntranceNumber(Integer.parseInt(items[i]));
                }

            }
            // 出口数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsData.setExitNumber(Integer.parseInt(items[i]));
                }

            }
            // 跳失率

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    goodsData.setBounceRate(Float.parseFloat(items[i].split("%")[0]));

                }

            } // 停留时间

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsData.setAvgStayTime(Float.parseFloat(items[i]));
                }

            } // 收藏量

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsData.setCollectionNumber(Integer.parseInt(items[i]));
                }

            }
            // 新增购物车人数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsData.setShoppingCartCustomerNumber(Integer.parseInt(items[i]));
                }

            }
            // 新增购物车宝贝件数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsData.setShoppingCartGoodsNumber(Integer.parseInt(items[i]));
                }

            } // 退款额

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsData.setRefundMoney(Float.parseFloat(items[i]));
                }
            }
            // 退货量

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsData.setRefundCount(Integer.parseInt(items[i]));
                }

            } // 退款率

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    goodsData.setRefundRate(Float.parseFloat(items[i].split("%")[0]));
                }

            } // 搜索UV

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsData.setSearchUv(Integer.parseInt(items[i]));
                }

            } // PC端类目UV

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataPc.setPcTypeUv(Integer.parseInt(items[i]));
                }

            }
            // PC端收藏UV

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataPc.setPcCollectionUv(Integer.parseInt(items[i]));
                }

            } // PC端直通车UV

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataPc.setPcZtcUv(Integer.parseInt(items[i]));
                }

            }
            // PC端淘宝客UV

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    goodsDataPc.setPcTbkUv(Integer.parseInt(items[i].split("%")[0]));
                }

            }
            // 浏览量（PC）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataPc.setPcPv(Integer.parseInt(items[i]));
                }

            }
            // 访客数（PC）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataPc.setPcUv(Integer.parseInt(items[i]));
                }

            }
            // 销售额（PC）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataPc.setPcPayMoney(Float.parseFloat(items[i]));
                }

            }
            // 成交宝贝数（PC）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataPc.setPcPayGoods(Integer.parseInt(items[i]));
                }

            }
            // 交易笔数（PC）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataPc.setPcTransactionNumber(Integer.parseInt(items[i]));
                }

            }
            // 转化率（PC)

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    goodsDataPc.setPcPayConversion(Float.parseFloat(items[i].split("%")[0]));
                }

            }
            // 入口数（PC）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataPc.setPcEntranceNumber(Integer.parseInt(items[i]));
                }

            }
            // 出口数（PC）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataPc.setPcExitNumber(Integer.parseInt(items[i]));
                }

            }
            // 跳失率（PC）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    goodsDataPc.setPcBounceRate(Float.parseFloat(items[i].split("%")[0]));
                }

            }
            // 停留时间（PC）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataPc.setPcAvgStayTime(Float.parseFloat(items[i]));
                }

            }
            // 搜索UV（PC）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataPc.setPcSearchUv(Integer.parseInt(items[i]));
                }

            }
            // 浏览量（手机）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataMp.setMpPv(Integer.parseInt(items[i]));
                }

            }
            // 访客数（手机）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataMp.setMpUv(Integer.parseInt(items[i]));
                }

            }
            // 销售额（手机）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataMp.setMpPayMoney(Float.parseFloat(items[i]));
                }

            }
            // 成交宝贝数（手机）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataMp.setMpPayGoods(Integer.parseInt(items[i]));
                }

            }
            // 交易笔数（手机）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataMp.setMpTransactionNumber(Integer.parseInt(items[i]));
                }

            }
            // 转化率（手机)

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    goodsDataMp.setMpPayConversion(Float.parseFloat(items[i].split("%")[0]));
                }

            }
            // 入口数（手机）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataMp.setMpEntranceNumber(Integer.parseInt(items[i]));
                }

            }
            // 出口数（手机）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataMp.setMpExitNumber(Integer.parseInt(items[i]));
                }

            }
            // 跳失率（手机）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    goodsDataMp.setMpBounceRate(Float.parseFloat(items[i].split("%")[0]));
                }

            }
            // 停留时间（手机）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataMp.setMpAvgStayTime(Float.parseFloat(items[i]));
                }

            }
            // 搜索UV（手机）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    goodsDataMp.setMpSearchUv(Integer.parseInt(items[i]));
                }

            }

            goodsDataList.add(goodsData);
            goodsDataMpList.add(goodsDataMp);
            goodsDataPcList.add(goodsDataPc);
        }
        resultMap.put("goodsDataList", goodsDataList);
        resultMap.put("goodsDataPcList", goodsDataPcList);
        resultMap.put("goodsDataMpList", goodsDataMpList);
        return resultMap;
    }
}

package com.zee.serviceImpl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.zee.common.IsNumericUtil;
import com.zee.common.ResultUtil;
import com.zee.dao.*;
import com.zee.model.ShopData;
import com.zee.model.ShopDataMp;
import com.zee.model.ShopDataPc;
import com.zee.service.AgpService;
import com.zee.service.ShopDataService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author : chenxiang
 * @date : 2018/6/29
 */
@Service
@Transactional(rollbackFor = RuntimeException.class)
public class ShopDataServiceImpl implements ShopDataService {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());


    @Autowired
    private ShopDataDao shopDataDao;
    @Autowired
    private ShopDataMpDao shopDataMpDao;
    @Autowired
    private ShopDataPcDao shopDataPcDao;
    @Autowired
    private AgpService agpService;
    @Autowired
    private AGPDao agpDao;
    @Autowired
    private ShopAgpDao shopAgpDao;

    /**
     * 分页查询
     *
     * @param paramMap
     * @return
     */
    @Override
    public Map<String, Object> list(Map<String, String> paramMap) {
        //获取查询参数
        Integer pageNo = Integer.parseInt(paramMap.get("page"));
        Integer pageSize = Integer.parseInt(paramMap.get("limit"));
        String shopId = paramMap.get("shopId");
        String beginTime = paramMap.get("beginTime");
        String endTime = paramMap.get("endTime");
        Page<ShopData> page = new Page<ShopData>(pageNo, pageSize);
        EntityWrapper<ShopData> ew = new EntityWrapper<ShopData>();
        ew.like(!StringUtils.isEmpty(shopId), "shop_id", shopId)
                .ge(!StringUtils.isEmpty(beginTime), "data_date", beginTime)
                .le(!StringUtils.isEmpty(endTime), "data_date", endTime)
                .orderBy("update_time", false);

        return ResultUtil.success(shopDataDao.selectPage(page, ew), shopDataDao.selectCount(ew));
    }

    /**
     * 数据导入
     *
     * @param files
     * @param paramMap
     * @return
     */
    @Override
    public Map<String, Object> importData(MultipartFile[] files, Map<String, String> paramMap) throws IOException, ParseException {
        String shopId = paramMap.get("shopId");
        String shopName = paramMap.get("shopName");
        String userName = paramMap.get("userName");
        for (int i = 0; i < files.length; i++) {
            System.out.print(">>>>>>>>>开始解析第" + (i + 1) + "个文件!");
            Boolean isExcel = files[i].getOriginalFilename().toLowerCase().endsWith(".csv");
            if (!isExcel) {
                return ResultUtil.failure("文件格式错误,请上传csv文件!");
            }
            InputStream is = files[i].getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "gbk"));
            Map<String, Object> resultMap = readerExcel(reader);
            List<ShopData> shopDataList = (List<ShopData>) resultMap.get("shopDataList");
            List<ShopDataPc> shopDataPcList = (List<ShopDataPc>) resultMap.get("shopDataPcList");
            List<ShopDataMp> shopDataMpList = (List<ShopDataMp>) resultMap.get("shopDataMpList");
            reader.close();
            is.close();
            //批量插入shopData
            if (!shopDataList.isEmpty()) {
                for (ShopData shopData : shopDataList) {
                    shopData.setId(UUID.randomUUID().toString().replace("-", ""));
                    shopData.setShopName(shopName);
                    shopData.setShopId(shopId);
                    shopData.setUserName(userName);
                }
                shopDataDao.batchInsert(shopDataList);
            }
            //批量插入shopDataPc
            if (!shopDataPcList.isEmpty()) {
                for (ShopDataPc shopDataPc : shopDataPcList) {
                    shopDataPc.setId(UUID.randomUUID().toString().replace("-", ""));
                    shopDataPc.setShopId(shopId);
                    shopDataPc.setShopName(shopName);
                    shopDataPc.setUserName(userName);
                }
                shopDataPcDao.batchInsert(shopDataPcList);
            }
            //批量插入shopDataMp
            if (!shopDataMpList.isEmpty()) {
                for (ShopDataMp shopDataMp : shopDataMpList) {
                    shopDataMp.setId(UUID.randomUUID().toString().replace("-", ""));
                    shopDataMp.setShopName(shopName);
                    shopDataMp.setShopId(shopId);
                    shopDataMp.setUserName(userName);
                }
                shopDataMpDao.batchInsert(shopDataMpList);
            }
            //每次新导入shopData时插入agp
            agpService.createAgp(shopName, shopDataList, null);
        }
        return ResultUtil.success("上传成功!");
    }

    /**
     * 解析excel文件
     *
     * @param reader
     */
    private Map<String, Object> readerExcel(BufferedReader reader) throws IOException, ParseException {
        String line = null;
        Map<String, Object> resultMap = new HashMap<>(16);
        List<ShopData> shopDataList = new ArrayList<>(64);
        List<ShopDataPc> shopDataPcList = new ArrayList<>(64);
        List<ShopDataMp> shopDataMpList = new ArrayList<>(64);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        int j = 0;
        while ((line = reader.readLine()) != null) {
            j++;
            //跳过第一行
            if (j == 1) {
                continue;
            }
            String items[] = line.split(",", -1);
            ShopData shopData = new ShopData();
            ShopDataPc shopDataPc = new ShopDataPc();
            ShopDataMp shopDataMp = new ShopDataMp();
            int i = 0;
            //统计时间

            if (items[i] != null) {
                shopData.setDataDate(sdf.parse(items[i].replace("/", "-")));
                shopDataPc.setDataDate(sdf.parse(items[i].replace("/", "-")));
                shopDataMp.setDataDate(sdf.parse(items[i].replace("/", "-")));
            }
            //浏览量
            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setPv(Integer.parseInt(items[i]));
                }

            }
            //访客数
            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setUv(Integer.parseInt(items[i]));
                }
            }
            //访问深度
            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setUvDepth(Float.parseFloat(items[i]));
                }

            }  //销售额
            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setPayMoney(Float.parseFloat(items[i]));
                }
            }  //销售量

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setPayGoods(Integer.parseInt(items[i]));
                }

            }  //订单数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setOrderCount(Integer.parseInt(items[i]));
                }

            }  //成交用户数

            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setPayCustomers(Integer.parseInt(items[i]));
                }

            }  //客单价

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setPct(Float.parseFloat(items[i]));
                }

            }  //转化率(支付)

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    shopData.setPayConversion(Float.parseFloat(items[i].split("%")[0]));
                }

            }
            //退款额

            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setRefundAmount(Float.parseFloat(items[i]));
                }

            } //退款量

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setRefundCount(Integer.parseInt(items[i]));
                }

            }
            //退款率
            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    shopData.setRefundMoneyRate(Float.parseFloat(items[i].split("%")[0]));
                }
            }
            //退货率
            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    shopData.setRefundGoodsRate(Float.parseFloat(items[i].split("%")[0]));
                }
            }
            //店铺收藏数
            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setShopCollectionCustomers(Integer.parseInt(items[i]));
                }
            }
            //宝贝收藏数
            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setGoodsCollectionCustomers(Integer.parseInt(items[i]));
                }

            }
            //新增购物车人数
            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setAddShoppingCartCustomer(Integer.parseInt(items[i]));
                }

            }
            //新增购物车宝贝件数

            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setAddShoppingCartGoods(Integer.parseInt(items[i]));
                }
            }
            //页面平均停留时间（秒）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setPageAvgStayTime(Float.parseFloat(items[i]));
                }

            }
            //人均停留时间（秒）
            if (items[++i] != null) {
                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setAvgStayTime(Float.parseFloat(items[i]));
                }

            }
            //新客平均停留时间（秒）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setNewAvgStayTime(Float.parseFloat(items[i]));
                }

            }
            //老客平均停留时间（秒）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setOldAvgStayTime(Float.parseFloat(items[i]));
                }

            }

            //旺旺咨询人数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    shopData.setWwConsultNumber(Integer.parseInt(items[i].split("%")[0]));
                }

            }
            //询盘-成交转化率

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    shopData.setInquiryTransactionConversion(Float.parseFloat(items[i].split("%")[0]));
                }

            }
            //静默转化率

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    shopData.setSilentConversionRate(Float.parseFloat(items[i].split("%")[0]));
                }
            }
            //pc端浏览量

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataPc.setPcPv(Integer.parseInt(items[i]));
                }

            }
            //pc端访客数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataPc.setPcUv(Integer.parseInt(items[i]));
                }
            }
            //pc端新客浏览量

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataPc.setPcNewPv(Integer.parseInt(items[i]));
                }

            }
            //pc端老客浏览量

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataPc.setPcOldPv(Integer.parseInt(items[i]));
                }

            }
            //pc端新访客数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataPc.setPcNewUv(Integer.parseInt(items[i]));
                }
            }
            //pc端老访客数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataPc.setPcOldUv(Integer.parseInt(items[i]));
                }
            }
            //pc端销售额

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataPc.setPcPayMoney(Float.parseFloat(items[i]));
                }
            }
            //pc端销售量

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataPc.setPcPayGoods(Integer.parseInt(items[i]));
                }
            }
            //pc端订单数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataPc.setPcOrderCount(Integer.parseInt(items[i]));
                }
            }
            //pc端成交用户数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataPc.setPcPayCustomers(Integer.parseInt(items[i]));
                }
            }
            //pc端客单价

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataPc.setPcPct(Float.parseFloat(items[i]));
                }
            }
            //pc端转化率

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataPc.setPcPayConversion(Float.parseFloat(items[i]));
                }
            }
            //pc端退款额

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataPc.setPcRefundAmount(Float.parseFloat(items[i]));
                }
            }
            //pc端退款数量

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataPc.setPcRefundCount(Integer.parseInt(items[i]));
                }
            }

            //pc端退款率

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    shopDataPc.setPcRefundMoneyRate(Float.parseFloat(items[i].split("%")[0]));
                }
            }
            //pc端退货率

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    shopDataPc.setPcRefundGoodsRate(Float.parseFloat(items[i].split("%")[0]));
                }
            }


            //手机端浏览量

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataMp.setMpPv(Integer.parseInt(items[i]));
                }

            }
            //手机端访客数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataMp.setMpUv(Integer.parseInt(items[i]));
                }
            }
            //手机端新客浏览量

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataMp.setMpNewPv(Integer.parseInt(items[i]));
                }

            }
            //手机端老客浏览量

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataMp.setMpOldPv(Integer.parseInt(items[i]));
                }

            }
            //手机端新访客数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataMp.setMpNewUv(Integer.parseInt(items[i]));
                }
            }
            //手机端老访客数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataMp.setMpOldUv(Integer.parseInt(items[i]));
                }
            }
            //手机端销售额

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataMp.setMpPayMoney(Float.parseFloat(items[i]));
                }
            }
            //手机端销售量

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataMp.setMpPayGoods(Integer.parseInt(items[i]));
                }
            }
            //手机端订单数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataMp.setMpOrderCount(Integer.parseInt(items[i]));
                }
            }
            //手机端成交用户数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataMp.setMpPayCustomers(Integer.parseInt(items[i]));
                }
            }
            //手机端客单价

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataMp.setMpPct(Float.parseFloat(items[i]));
                }
            }
            //手机端转化率

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataMp.setMpPayConversion(Float.parseFloat(items[i]));
                }
            }
            //手机端退款额

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataMp.setMpRefundAmount(Float.parseFloat(items[i]));
                }
            }
            //手机端退款数量

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopDataMp.setMpRefundCount(Integer.parseInt(items[i]));
                }
            }

            //手机端退款率

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    shopDataMp.setMpRefundMoneyRate(Float.parseFloat(items[i].split("%")[0]));
                }
            }
            //手机端退货率

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    shopDataMp.setMpRefundGoodsRate(Float.parseFloat(items[i].split("%")[0]));
                }
            }
            //pc端6日回访客数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    shopDataPc.setPcSixBack(Integer.parseInt(items[i].split("%")[0]));
                }
            }
            //手机端6日回访客数

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i].split("%")[0])) {
                    shopDataMp.setMpSixBack(Integer.parseInt(items[i].split("%")[0]));
                }
            }
            //销售额(老客)

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setOldPayMoney(Float.parseFloat(items[i]));
                }
            }
            //销售量(老客)

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setOldPayGoods(Integer.parseInt(items[i]));
                }
            }
            //成交用户数（老客）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setOldPayCustomers(Integer.parseInt(items[i]));
                }
            }
            //DSR得分（描述相符）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setDsrDescribeScore(Float.parseFloat(items[i]));
                }
            }  //DSR评分次数（描述相符）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setDsrDescribeNumber(Integer.parseInt(items[i]));
                }
            }  //DSR得分（服务态度）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setDsrServerScore(Float.parseFloat(items[i]));
                }
            }  //DSR评分次数（服务态度）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setDsrServerNumber(Integer.parseInt(items[i]));
                }
            }  //DSR得分（发货速度）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setDsrShipmentsScore(Float.parseFloat(items[i]));
                }
            }  //DSR评分次数（发货速度）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setDsrShipmentsNumber(Integer.parseInt(items[i]));
                }
            }  //DSR得分（物流速度）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setDsrLogisticsScore(Float.parseFloat(items[i]));
                }
            }  //DSR评分次数（物流速度）

            if (items[++i] != null) {

                if (IsNumericUtil.isNumeric(items[i])) {
                    shopData.setDsrLogisticsNumber(Integer.parseInt(items[i]));
                }
            }
            shopData.setOldUv(shopDataPc.getPcOldUv() + shopDataMp.getMpOldUv());
            shopData.setNewUv(shopDataPc.getPcNewUv() + shopDataMp.getMpNewUv());
            shopDataList.add(shopData);
            shopDataMpList.add(shopDataMp);
            shopDataPcList.add(shopDataPc);
        }

        resultMap.put("shopDataList", shopDataList);
        resultMap.put("shopDataMpList", shopDataMpList);
        resultMap.put("shopDataPcList", shopDataPcList);
        return resultMap;
    }


    /**
     * 店铺销售额图表
     *
     * @param paramMap
     * @return
     */
    @Override
    public Map<String, Object> shopSalesChart(Map<String, Object> paramMap) {
        try {
            SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date dateStart=sdf.parse(paramMap.get("dateStart")+" 00:00:00");
            Date dateEnd=sdf.parse(paramMap.get("dateEnd")+" 23:59:59");
            return ResultUtil.success(shopDataDao.shopSalesChart(dateStart,dateEnd,paramMap.get("shopId")+""));
        } catch (ParseException e) {
            logger.error(e.getMessage(), e);
            return ResultUtil.failure(e.getMessage());
        }
    }

    /**
     * 获取新老访客数量
     *
     * @param shopId
     * @param dataDate
     * @return
     */
    @Override
    public Map<String, Object> getNewOldCustomers(String shopId, String dataDate) {
        try {
            SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date=sdf.parse(dataDate+" 00:00:00");

            Wrapper wrapper = new EntityWrapper<ShopData>();
            wrapper.where("DATE_FORMAT(data_date,'%Y-%m-%d 00:00:00')={0}",date);
            wrapper.eq("shop_id", shopId);
            List<ShopData> shopDataList = shopDataDao.selectList(wrapper);
            ShopData shopData = shopDataList != null && !shopDataList.isEmpty() ? shopDataList.get(0) : null;
            List<Map<String, Object>> datas = new ArrayList<Map<String, Object>>();
            if (shopData != null) {
                Map<String, Object> mapOld = new HashMap<>();
                mapOld.put("title", "老客(" + shopData.getOldUv() + ")");
                mapOld.put("uv", shopData.getOldUv());
                datas.add(mapOld);

                Map<String, Object> mapNew = new HashMap<>();
                mapNew.put("title", "新客(" + shopData.getNewUv() + ")");
                mapNew.put("uv", shopData.getNewUv());
                datas.add(mapNew);
            }
            return ResultUtil.success(datas);
        } catch (ParseException e) {
            logger.error(e.getMessage(), e);
            return ResultUtil.failure(e.getMessage());
        }
    }
}



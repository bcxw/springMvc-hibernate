package com.zee.serviceImpl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.zee.dao.GoodsMappingDao;
import com.zee.dao.QueryTimeDao;
import com.zee.jushuitanApi.Api.OpenSearch;
import com.zee.jushuitanApi.Models.JobModel;
import com.zee.model.GoodsMapping;
import com.zee.model.QueryTime;
import com.zee.service.GoodsMappingService;
import com.zee.task.JuShuiTanDataSyncTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import javax.management.Query;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author : chenxiang
 * @date : 2018/6/22
 */
@Transactional(rollbackFor = RuntimeException.class)
@Service
public class GoodsMappingServiceImpl implements GoodsMappingService {
    @Autowired
    private GoodsMappingDao goodsMappingDao;
    @Autowired
    private QueryTimeDao queryTimeDao;
    private static final Logger logger = LoggerFactory.getLogger(JuShuiTanDataSyncTask.class);
    private static final String queryType = "goodsMapping";
    @Value("${jushuitan.url}")
    private String url;
    @Value("${jushuitan.partnerId}")
    private String partnerId;
    @Value("${jushuitan.partnerKey}")
    private String partnerKey;
    @Value("${jushuitan.token}")
    private String token;

    /**
     * 同步聚水潭商品映射数据
     *
     * @param pageIndex
     */
    @Override
    public void fetchGoodsMapping(int pageIndex, String startDate) {
        String beginTime;
        String endTime;
        EntityWrapper<GoodsMapping> ew = new EntityWrapper<>();
        int total = goodsMappingDao.selectCount(ew);
        //获取仓库信息
        String method = "skumap.query";
        OpenSearch os = new OpenSearch(partnerId, partnerKey, token, method, url);
        JobModel jobModel = new JobModel();
        Map<String, Object> queryMap = new HashMap<>(16);
        queryMap.put("page_index", pageIndex);
        queryMap.put("page_size", 50);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //每次查询以上次结束时间作为此次开始时间;上次结束为空时,开始时间为当前时间天数-1
        if (StringUtils.isEmpty(startDate)) {
            startDate = queryTimeDao.selectLastTime(queryType);
        }

        Calendar calendar = Calendar.getInstance();
        if (StringUtils.isEmpty(startDate)) {
            calendar.setTime(new Date());
            endTime = simpleDateFormat.format(calendar.getTime());
            calendar.add(Calendar.DAY_OF_YEAR, -1);
            beginTime = simpleDateFormat.format(calendar.getTime());
        } else {
            try {
                calendar.setTime(simpleDateFormat.parse(startDate));

            } catch (ParseException e) {
                logger.error(e.getMessage(), e);
            }
            beginTime = simpleDateFormat.format(calendar.getTime());
            endTime = simpleDateFormat.format(new Date());
        }
        queryMap.put("modified_end", endTime);
        queryMap.put("modified_begin", beginTime);
        jobModel.setData(JSON.toJSONString(queryMap));
        try {
            System.out.println(">>>>>>>开始同步聚水潭商品映射数据");
            String sData = os.QueryData(jobModel);
            JSONObject jsonObject = JSON.parseObject(sData);
            if ("0".equals(jsonObject.get("code") + "")) {
                JSONArray jsonArray = jsonObject.getJSONArray("datas");
                if (jsonArray != null && !jsonArray.isEmpty()) {
                    System.out.println(">>>>>>>开始保存商品映射数据");
                    saveGoodsMapping(jsonArray, beginTime, endTime);
                    boolean has_next = jsonObject.getBoolean("has_next");
                    if (has_next) {
                        pageIndex++;
                        fetchGoodsMapping(pageIndex, startDate);
                        logger.info("获取聚水潭商品映射页数:" + pageIndex);
                    }
                } else {
                    logger.info("聚水潭无数据信息" + jsonObject.get("msg"));
                }
            } else {
                logger.error("获取商品映射信息失败 " + jsonObject.get("msg"));
            }
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
        QueryTime queryTime = new QueryTime();
        queryTime.setEndTime(endTime);
        queryTime.setQueryType(queryType);
        queryTimeDao.insert(queryTime);
    }


    /**
     * 保存商品映射数据
     *
     * @param jsonArray
     * @param beginTime
     * @param endTime
     */
    private void saveGoodsMapping(JSONArray jsonArray, String beginTime, String endTime) {
        List<GoodsMapping> goodsMappingList = new ArrayList<>(100);
        for (int i = 0; jsonArray != null && i < jsonArray.size(); i++) {
            GoodsMapping goodsMapping = jsonArray.getObject(i, GoodsMapping.class);
            goodsMapping.setId(UUID.randomUUID().toString().replace("-", ""));
            goodsMapping.setShopSkuId(goodsMapping.getShopId() + "_" + goodsMapping.getSkuId());
            goodsMappingList.add(goodsMapping);
        }
        if (goodsMappingList != null && !goodsMappingList.isEmpty()) {
            goodsMappingDao.batchInsert(goodsMappingList);
        }
    }
}

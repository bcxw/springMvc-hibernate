package com.zee.serviceImpl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.zee.common.ResultUtil;
import com.zee.dao.AGPDao;
import com.zee.dao.ShopAgpDao;
import com.zee.dao.ShopBasePeopleDao;
import com.zee.dao.ShopDataDao;
import com.zee.model.AGP;
import com.zee.model.ShopAgp;
import com.zee.model.ShopBasePeople;
import com.zee.model.ShopData;
import com.zee.service.AgpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @Auther: chenxiang
 * @Date: 2018/7/16/0016 15:23
 * @Description:
 */

@Service
@Transactional(rollbackFor = RuntimeException.class)
public class AgpServiceImpl implements AgpService {
    @Autowired
    private AGPDao agpDao;
    @Autowired
    private ShopAgpDao shopAgpDao;
    @Autowired
    private ShopDataDao shopDataDao;
    @Autowired
    private ShopBasePeopleDao shopBasePeopleDao;

    /**
     * agp查询
     *
     * @param paramMap
     * @return
     */
    @Override
    public Map<String, Object> list(Map<String, Object> paramMap) {
        EntityWrapper<AGP> ew = new EntityWrapper<AGP>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar calendar = Calendar.getInstance();
        //只查询昨天的agp
        calendar.setTime(new Date());
        calendar.add(Calendar.DAY_OF_YEAR, -1);
        String date = sdf.format(calendar.getTime());
        ew.eq("data_date", date).orderBy("yesterday_agp", false);
        return ResultUtil.success(agpDao.selectList(ew));
    }

    /**
     * 插入agp
     *
     * @param shopName
     * @param shopDataList
     * @throws ParseException
     * @throws ParseException
     */
    @Override
    public void createAgp(String shopName, List<ShopData> shopDataList, String agpMonth) throws ParseException, ParseException {
        //设置店铺agp率是插入agp
        if (shopDataList == null || shopDataList.isEmpty()) {
            //查询
            EntityWrapper<ShopData> ew = new EntityWrapper<ShopData>();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
            Date agpDate = sdf.parse(agpMonth);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(agpDate);
            calendar.add(Calendar.MONTH, +1);
            ew.eq("shop_name", shopName).like("data_date", sdf.format(calendar.getTime()));
            shopDataList = shopDataDao.selectList(ew);
        }
        if (shopDataList != null && !shopDataList.isEmpty()) {
            List<AGP> agpList = new ArrayList<>(100);
            ShopAgp shopAgp = new ShopAgp();
            for (ShopData sd : shopDataList) {
                //shopData中日期格式为yyyy/MM/dd 将起转换为yyyy-MM
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM");
                Date dataDate = sd.getDataDate();
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(dataDate);
                calendar.add(Calendar.MONTH, -1);
                //查询店铺是否已经进行agp率设置,设置的才保存agp
                shopAgp = shopAgpDao.selectByCondition(shopName, sdf1.format(calendar.getTime()));
                if (shopAgp != null) {
                    EntityWrapper<ShopBasePeople> ew = new EntityWrapper<>();
                    ew.eq("shop_id", shopAgp.getShopId());
                    List<ShopBasePeople> peopleList = shopBasePeopleDao.selectList(ew);
                    if (peopleList.isEmpty()) {
                        continue;
                    }
                    List<String> owerStr = new ArrayList<>();
                    List<String> participatorStr = new ArrayList<>();
                    for (ShopBasePeople sbp : peopleList) {
                        if (sbp.getType().equals("admin")) {
                            owerStr.add(sbp.getUsername());
                        }
                        if (sbp.getType().equals("participator")) {
                            participatorStr.add(sbp.getUsername());
                        }
                    }
                    AGP agp = new AGP();
                    agp.setStoreOwner(owerStr.toString().replace("[", "").replace("]", ""));
                    agp.setStoreParticipants(participatorStr.toString().replace("[", "").replace("]", ""));
                    agp.setLastMonthAgp(shopAgp.getAgpRate());
                    agp.setShopName(shopName);
                    agp.setDataDate(dataDate);
                    agp.setTurnover(sd.getPayMoney());
                    agp.setYesterdayAgp((int) (agp.getTurnover() * agp.getLastMonthAgp()));
                    //上周同比
                    calendar.setTime(dataDate);
                    calendar.add(Calendar.DAY_OF_YEAR, -7);
                    String lastweekday = sdf.format(calendar.getTime());
                    sd = shopDataDao.selectByDataDate(lastweekday, shopName);
                    if (sd != null) {
                        agp.setComparedToLastWeek((agp.getTurnover() - sd.getPayMoney()) / sd.getPayMoney());
                    }
                    //去年同比
                    calendar.setTime(dataDate);
                    int weeknumber = calendar.get(Calendar.WEEK_OF_YEAR);
                    calendar.add(Calendar.YEAR, -1);
                    calendar.set(Calendar.WEEK_OF_YEAR, weeknumber);
                    calendar.set(Calendar.DAY_OF_WEEK, 1);
                    String startTime = sdf.format(calendar.getTime());
                    calendar.set(Calendar.DAY_OF_WEEK, 7);
                    String endTime = sdf.format(calendar.getTime());
                    Float avgPayMoney = shopDataDao.getAvgPayMoney(startTime, endTime, shopName);
                    if (avgPayMoney != null) {
                        agp.setComparedToLastYear((agp.getTurnover() - avgPayMoney) / avgPayMoney);
                    }
                    agp.setId(UUID.randomUUID().toString().replace("-", ""));
                    agpList.add(agp);
                }
            }
            if ( !agpList.isEmpty()) {
                agpDao.batchInsert(agpList);
            }

        }

    }
}

package com.zee.service;

import java.util.Map;

/**
 * @author : chenxiang
 * @date : 2018/6/22
 * 退换货服务
 */
public interface ReturnGoodsService {
    /**
     * 同步退换货
     */
    void fetchReturnGoods(int index, String startDatef);

    /**
     * 退换货排行列表
     *
     * @param paramMap
     * @return
     */
    Map<String, Object> list(Map<String, Object> paramMap);

}

package com.zee.service;

import com.zee.model.ShopData;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

/**
 * @Auther: chenxiang
 * @Date: 2018/7/16/0016 15:17
 * @Description:
 */
public interface AgpService {
    /**
     * 展示
     *
     * @param paramMap
     * @return
     */
    Map<String, Object> list(Map<String, Object> paramMap);

    /**
     * 插入agp
     *
     * @param shopName
     * @param shopDataList
     * @throws ParseException
     * @throws ParseException
     */
    void createAgp(String shopName, List<ShopData> shopDataList, String agpMonth) throws ParseException, ParseException;
}

package com.zee.service;

/**
 * @author : chenxiang
 * @date : 2018/6/22
 * 订单服务
 */
public interface OrderService {
    /**
     * 同步订单信息
     */
    void fetchOrder(int pageIndex, String startDate);
}

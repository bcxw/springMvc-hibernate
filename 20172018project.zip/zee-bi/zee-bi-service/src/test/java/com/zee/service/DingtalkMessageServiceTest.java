package com.zee.service;

import com.alibaba.dubbo.config.annotation.Reference;
import com.taobao.api.ApiException;
import com.zee.dto.DingtalkMessageResponse;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;


public class DingtalkMessageServiceTest extends BaseTest {

    @Reference(version = "1.0.0")
    private DingtalkMessageService dingtalkMessageService;

    @Value("${application.id}")
    private String appId;

    @Test
    public void sendTextMessageTest() throws ApiException {

        DingtalkMessageResponse dingtalkMessageResponse = dingtalkMessageService.sendTextMessage(appId, "639141769", "BI消息提醒 要吃饭了！！！ 哈哈 ！");
        System.out.println("taskId:" + dingtalkMessageResponse.getTaskId() + ";状态码：" + dingtalkMessageResponse.getCode() + ";消息：" + dingtalkMessageResponse.getMessage());

    }

}

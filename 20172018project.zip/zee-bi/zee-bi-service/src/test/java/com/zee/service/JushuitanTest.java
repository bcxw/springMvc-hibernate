package com.zee.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zee.jushuitanApi.Api.OpenSearch;
import com.zee.jushuitanApi.Models.JobModel;
import com.zee.jushuitanApi.Response.SkuResponse;
import com.zee.jushuitanApi.Search.SearchSkuModel;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


public class JushuitanTest extends BaseTest {

    @Value("http://b.sursung.com/api/open/query.aspx")
    private String url;
    @Value("ywv5jGT8ge6Pvlq3FZSPol345asd")
    private String partnerId;
    @Value("ywv5jGT8ge6Pvlq3FZSPol2323")
    private String partnerKey;
    @Value("181ee8952a88f5a57db52587472c3798")
    private String token;

    @Test
    public void skuQueryTest() throws JsonProcessingException, IOException {
        //获取店铺信息
        String method = "shops.query";
        OpenSearch os = new OpenSearch(partnerId, partnerKey, token, method, url);
        JobModel jobModel = new JobModel();
        try {
            System.out.print(">>>>>>>开始同步聚水潭店铺数据");
            String sData = os.QueryData(jobModel);
            JSONObject jsonObject = JSON.parseObject(sData);
            if ("0".equals(jsonObject.get("code") + "")) {
                JSONArray jsonArray = jsonObject.getJSONArray("shops");
                if (jsonArray != null && !jsonArray.isEmpty()) {
                    System.out.print("======>" + jsonArray.size());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

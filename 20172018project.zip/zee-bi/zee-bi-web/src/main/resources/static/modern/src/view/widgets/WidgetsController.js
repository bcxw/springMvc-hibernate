Ext.define('Admin.view.widgets.WidgetsController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.widgets',

    onFollow: function (sender) {
        // TODO
    },

    onMessage: function (sender) {
        // TODO
    },

    onContactFacebook: function (sender) {
        // TODO
    },

    onContactTwitter: function (sender) {
        // TODO
    },

    onContactGooglePlus: function (sender) {
        // TODO
    },

    onContactEmail: function (sender) {
        // TODO
    }
});

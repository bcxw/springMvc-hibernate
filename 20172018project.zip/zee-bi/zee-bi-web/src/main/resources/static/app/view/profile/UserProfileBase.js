Ext.define('Admin.view.profile.UserProfileBase', {
    extend: 'Ext.Container',

    viewModel: {
        type: 'userprofile'
    }
});

Ext.define('Admin.data.marketshare.Yearwise', {
    extend: 'Admin.data.Simulated',

    data: [
        {
            "xvalue": 2011,
            "y1value": 517.27,
            "y2value": 520.3,
            "y3value": 291.41,
            "y4value": 420.24
        },
        {
            "xvalue": 2012,
            "y1value": 389.38,
            "y2value": 632.31,
            "y3value": 882.90,
            "y4value": 771.08
        },
        {
            "xvalue": 2013,
            "y1value": 287.24,
            "y2value": 440.78,
            "y3value": 549.99,
            "y4value": 627.71
        },
        {
            "xvalue": 2014,
            "y1value": 505.25,
            "y2value": 631.07,
            "y3value": 570.43,
            "y4value": 583.67
        }
    ]
});

Ext.define('Admin.model.FriendsList', {
    extend: 'Admin.model.Base',

    fields: [
        {
            name: 'friendsName'
        },
        {
            name: 'connectionStatus'
        }
    ]
});

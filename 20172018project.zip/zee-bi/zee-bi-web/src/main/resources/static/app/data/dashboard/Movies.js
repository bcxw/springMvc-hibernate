Ext.define('Admin.data.dashboard.Movies', {
    extend: 'Admin.data.Simulated',

    data: [
        {
            "xvalue": "Foo",
            "yvalue": 943
        },
        {
            "xvalue": "Bar",
            "yvalue": 622
        },
        {
            "xvalue": "Baz",
            "yvalue": 1044
        }
    ]
});

Ext.define('Admin.dashboard.Dashboard', {
    extend: 'Ext.container.Container',
    alias: 'widget.dashboard',

    requires: [
        'Ext.ux.layout.ResponsiveColumn',
        'Admin.dashboard.AGPGrid',
        'Admin.dashboard.ShopBarChart',
        'Admin.dashboard.ShopConversionChart',
        'Admin.dashboard.ShopPVUVChart',
        'Admin.dashboard.ShopVisitorChart'
    ],

    layout: 'responsivecolumn',

    items:[
        {
            xtype: 'shopBarChart',
            userCls: 'big-60 small-100'
        },
        {
            xtype: 'shopPVUVChart',
            userCls: 'big-40 small-100'
        },
        {
            xtype: 'shopConversionChart',
            userCls: 'big-40 small-100'
        },
        {
            xtype: 'agpGrid',
            userCls: 'big-60 small-100'
        },
        {
            xtype: 'shopVisitorChart',
            userCls: 'big-40 small-100'
        }
    ]
});

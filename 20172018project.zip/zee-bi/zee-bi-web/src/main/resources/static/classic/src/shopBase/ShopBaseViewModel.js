Ext.define('Admin.shopBase.ShopBaseViewModel',{
    extend:'Admin.main.MainModel',
    alias:'viewmodel.shopBaseViewModel',

    stores:{
        shopBaseStore:{
            pageSize:20,
            proxy: {
                type:'ajax',
                url:'shopBase/list',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            }
        }
    }
});
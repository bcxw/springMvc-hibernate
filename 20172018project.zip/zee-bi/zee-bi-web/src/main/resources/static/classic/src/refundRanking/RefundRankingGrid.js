Ext.define('Admin.refundRanking.RefundRankingGrid', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.refundRankingGrid',

    requires: ['Admin.common.BasedataCombobox','Admin.refundRanking.RefundRankingModel','Admin.refundRanking.RefundRankingController','Admin.common.ShopCombobox'],

    controller: 'refundRankingController',
    viewModel: "refundRankingModel",

    margin: "20px",//边距 必须
    cls: 'shadow',//阴影 必须

    autoLoad:true,
    tbar: {
        xtype: "form",
        bodyBorder: true,
        items: [{
            layout:"column",
            border:false,
            defaults:{
                labelAlign: "right",
                labelWidth:50,
                width: 200,
                margin:"5 0 5 0"
            },
            items: [{
                fieldLabel: "销售日期",
                xtype: "fieldcontainer",
                name:"dateScale",
                labelWidth:70,
                width: 350,
                layout:"hbox",
                items:[{
                    xtype: "datefield",
                    format:"Y-m-d",
                    width: 125,
                    name:"dateStart",
                    editable:false,
                    value:new Date(new Date().getTime()-(30*24*60*60*1000))
                },{
                    html:"&nbsp;-&nbsp;",
                    border:false
                },{
                    xtype: "datefield",
                    width: 125,
                    format:"Y-m-d",
                    name:"dateEnd",
                    editable:false,
                    value:new Date()
                }]
            },{
                xtype: "shopCombobox",
                fieldLabel: "店铺",
                name: 'shopId'
            },{
                xtype: "textfield",
                fieldLabel: "款号",
                name: "sku"
            },{
                fieldLabel: "类型",
                xtype: "basedataCombobox",
                basedataCode:"refundType",
                name:"type"
            },{
                fieldLabel: "原因",
                xtype: "basedataCombobox",
                basedataCode:"refundReason",
                name:"reason"
            }/*,{
                fieldLabel: "退货率",
                xtype: "textfield",
                name: "refundRate",
                enableKeyEvents:true,
                listeners:{
                    keydown:"enterSearch"
                }
            }*/]
        },{
            border: false,
            layout: "column",
            defaults: {
                xtype: "button",
                margin: "5 0 5 10"
            },
            items: [{
                text: '查询',
                handler: 'search',
                iconCls: "x-fa fa-search"
            },{
                text: '重置',
                handler: 'searchAll',
                iconCls: "x-fa fa-minus"
            }]
        }]
    },
    bind: {
        store: '{shopBaseStore}'
    },

    selModel: {
        selType: 'checkboxmodel',
        mode :'SINGLE'
    },

    bbar: {
        xtype: 'pagingtoolbar',
        displayInfo: true
    },
    columns: [{
        xtype: 'rownumberer'
    },{
        dataIndex: 'shopName',
        text: '店铺',
        width: 120
    },{
        dataIndex: 'sku',
        text: '款号',
        width: 120,
        renderer: function (value, metaData ,record) {
            var result=value;
            if (!isNaN(value)||!value){
                result = record.data.sku_id;
                var ra=result.split("-");
                ra.pop();
                result=ra.join("-");
            }
            return result;
        }
    },{
        dataIndex: 'refundNum',
        text: '退货数量',
        width: 100
    },{
        dataIndex: 'refundAmount',
        text: '退款金额',
        width: 100
    },{
        dataIndex: 'refundNum',
        text: '退货率%',
        width: 100,
        renderer: function (value, record) {
            var result;
            if (value&&record.data.saleGoods){
                result=value/record.data.saleGoods;
                result=result.toFixed(2);
            }
            return result;
        }
    },{
        dataIndex: 'refundAmount',
        text: '退款率%',
        width: 100,
        renderer: function (value, record) {
            var result;
            if (value&&record.data.saleAmount){
                result=value/record.data.saleAmount;
                result=result.toFixed(2);
            }
            return result;
        }
    },{
        dataIndex: 'refundNumSend',
        text: '发货前退货量',
        width: 120
    },{
        dataIndex: 'refundNumSend',
        text: '发货后退货量',
        width: 120,
        renderer: function (value, record) {
            return record.data.refundNum-refundNumSend;
        }
    },{
        dataIndex: 'saleGoods',
        text: '销售件数',
        width: 100
    },{
        dataIndex: 'saleAmount',
        text: '销售金额',
        width: 100,
        flex:1
    }]
});

Ext.define('Admin.inventoryWarning.InventoryWarningController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.inventoryWarningController',
    /**
     * 回车查询
     * @param cmp
     * @param e
     * @param eOpts
     */
    enterSearch: function (cmp, e, eOpts) {
        if (e && e.keyCode == 13) {
            this.search(cmp);
        }
    },
    /**
     * 取消and返回
     */
    closeBack: function () {
        var contentPanel = this.getView().up('#contentPanel');
        var oldItem = contentPanel.getLayout().getActiveItem();
        contentPanel.getLayout().setActiveItem(contentPanel.getComponent(contentPanel.items.length - 2));
        contentPanel.remove(oldItem);
    },
    /**
     *查询
     * @param button
     */
    search: function (button) {
        var grid = button.up("grid");
        Ext.apply(grid.store.proxy.extraParams, button.up("form").getValues());
        grid.store.loadPage(1);
    },
    /**
     * 全部
     * @param button
     */
    searchAll: function (button) {
        button.up("form").reset();
        this.search(button);
    }


});
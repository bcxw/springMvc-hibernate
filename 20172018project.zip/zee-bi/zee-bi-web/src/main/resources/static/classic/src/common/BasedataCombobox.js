/**
 * 基础数据主界面通用组件 下拉框
 * 示例：｛xtype:"basedataCombobox",basedataCode:"品牌"｝
 */
Ext.define('Admin.common.BasedataCombobox', {
    extend: 'Ext.form.field.ComboBox',
    alias: 'widget.basedataCombobox',
    editable: false,
    basedataCode: '',

    displayField: 'name',
    valueField: 'code',
    store: {
        autoLoad: true,
        fields: [{
            name: 'id'
        }, {
            name: 'name'
        }, {
            name: 'code'
        }],
        proxy: {
            type: 'ajax',
            reader: {rootProperty: 'data'},
            url: 'basedata/getBaseDataByParentCode'
        }
    },

    initComponent: function () {
        this.store.proxy.extraParams = {parentCode: this.basedataCode};
        this.callParent();
    }

});
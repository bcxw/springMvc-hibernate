Ext.define('Admin.goodsKeyword.GoodsKeywordImportModel', {
    extend: 'Admin.main.MainModel',
    alias: 'viewmodel.goodsKeywordImportModel',
    stores: {
        goodsStore: {
            type: "store",
            defaultRootProperty: "data",
            pageSize: 20,
            fields: [{
                name: 'id'
            }, {
                name: 'dataDate'
            }, {
                name: 'goodsId'
            },
                {
                    name: 'title'
                }, {
                    name: 'url'
                }, {
                    name: 'searchType'
                }, {
                    name: 'keyWord'
                }, {
                    name: 'directUv'
                }, {
                    name: 'bounceRate'
                }, {
                    name: 'directPayGoods'
                }, {
                    name: 'directPayConversion'
                }, {
                    name: 'indirectPayGoods'
                }, {
                    name: 'directOrderCount'
                }, {
                    name: 'shopId'
                }, {
                    name: 'shopName'
                }],

            proxy: {
                type: 'ajax',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    implicitIncludes: false
                },
                url: 'goodsKeyword/list',
                paramsAsJson: true
            }
        }
    }
});
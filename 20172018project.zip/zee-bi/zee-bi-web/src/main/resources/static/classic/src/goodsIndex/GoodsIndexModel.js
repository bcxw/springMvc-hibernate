Ext.define('Admin.goodsIndex.GoodsIndexModel', {
    extend: 'Admin.main.MainModel',
    alias: 'viewmodel.goodsIndexModel',
    stores: {
        goodsStore: {
            pageSize:20,
            type: "store",
            defaultRootProperty: "data",

            fields: [{
                name: 'id'
            }, {
                name: 'dataDate'
            }, {
                name: 'shopName'
            },
                {
                    name: 'shopId'
                },
                {
                    name: 'iId'
                },
                {
                    name: 'skuId'
                },
                {
                    name: 'shopIId'
                }, {
                    name: 'uv'
                }, {
                    name: 'pv'
                }, {
                    name: 'pct'
                }, {
                    name: 'searchPayConversion'
                }, {
                    name: 'searchUv'
                }, {
                    name: 'payCustomers'
                }, {
                    name: 'refundMoney'
                }, {
                    name: 'refundCount'
                }, {
                    name: 'pct'
                }, {
                    name: 'searchPayCustomers'
                }, {
                    name: 'collectionCustomers'
                }, {
                    name: 'showNumber'
                }, {
                    name: 'clickRate'
                }, {
                    name: 'clickNumber'
                }, {
                    name: 'customerValueAvg'
                }, {
                    name: 'shoppingCartNumber'
                }, {
                    name: 'payGoods'
                }, {
                    name: 'payMoney'
                }, {
                    name: 'orderCustomers'
                }, {
                    name: 'orderGoods'
                }, {
                    name: 'orderMoney'
                }, {
                    name: 'payConversion'
                }, {
                    name: 'orderPayConversion'
                }, {
                    name: 'orderConversion'
                }, {
                    name: 'detailHoppingRate'
                }, {
                    name: 'avgStayTime'
                }, {
                    name: 'status'
                }, {
                    name: 'url'
                }, {
                    name: 'title'
                }, {
                    name: 'datetime'
                }],

            proxy: {
                type: 'ajax',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    implicitIncludes: false
                },
                url: 'goodsData/list',
                paramsAsJson: true
            }
        }
    }
});
Ext.define('Admin.view.main.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.main',

    listen : {
        controller : {
            '#' : {
                unmatchedroute : 'onRouteChange'
            }
        }
    },

    routes: {
        ':node': 'onRouteChange'
    },

    lastView: null,

    setCurrentView: function(hashTag) {
        var me = this,
            refs = me.getReferences(),
            mainCard = refs.mainCardPanel,
            mainLayout = mainCard.getLayout(),
            navigationList=refs.navigationTreeList,
            view = hashTag,
            lastView = me.lastView,
            existingItem = mainCard.child('component[routeId=' + hashTag + ']'),
            newView;

        var store = navigationList.getStore();
        store = store?store:Ext.data.StoreManager.lookup('navigationTreeStore');
        if (store.loadCount<=0){
            store.on("load",function (cmp, records, successful, operation, node, eOpts ) {
                me.setCurrentView(hashTag);
            });
        }else{


            if(existingItem){
                newView=existingItem;
            }else{
                if (lastView){
                    lastView.destroy();
                }

                if(view.toLowerCase().indexOf("http")==0){
                    newView = Ext.create("Ext.panel.Panel",{
                        //xtype: view,
                        margin: "20px",//边距 必须
                        cls: 'shadow',//阴影 必须
                        routeId: hashTag,  // for existingItem search later
                        hideMode: 'offsets',
                        html:"<iframe frameborder='0' width='100%' height='100%' src='"+view+"'></iframe>"
                    });
                }else{
                    newView = Ext.create(view,{
                        //xtype: view,
                        routeId: hashTag,  // for existingItem search later
                        hideMode: 'offsets'
                    });
                }


            }

            var node = store.findNode('viewType', hashTag);
            if (node){
                navigationList.setSelection(node);
                var panelVM=newView.getViewModel();
                if(panelVM&&node.data.authData&&Ext.isObject(node.data.authData)){
                    panelVM.setData(node.data.authData);
                }

                mainLayout.setActiveItem(mainCard.add(newView));

                me.lastView = newView;
            }

        }


    },
    onNavigationTreeSelectionChange: function (tree, node) {
        var to = node && (node.get('routeId') || node.get('viewType'));
        if(to){
            this.redirectTo(to);
        }

    },

    onToggleNavigationSize: function () {
        var me = this,
            refs = me.getReferences(),
            navigationList = refs.navigationTreeList,
            wrapContainer = refs.mainContainerWrap,
            collapsing = !navigationList.getMicro(),
            new_width = collapsing ? 64 : 250;

        if (Ext.isIE9m || !Ext.os.is.Desktop) {
            Ext.suspendLayouts();

            refs.senchaLogo.setWidth(new_width);

            navigationList.setWidth(new_width);
            navigationList.setMicro(collapsing);

            Ext.resumeLayouts(); // do not flush the layout here...

            // No animation for IE9 or lower...
            wrapContainer.layout.animatePolicy = wrapContainer.layout.animate = null;
            wrapContainer.updateLayout();  // ... since this will flush them
        }
        else {
            if (!collapsing) {
                // If we are leaving micro mode (expanding), we do that first so that the
                // text of the items in the navlist will be revealed by the animation.
                navigationList.setMicro(false);
            }

            // Start this layout first since it does not require a layout
            refs.senchaLogo.animate({dynamic: true, to: {width: new_width}});

            // Directly adjust the width config and then run the main wrap container layout
            // as the root layout (it and its chidren). This will cause the adjusted size to
            // be flushed to the element and animate to that new size.
            navigationList.width = new_width;
            wrapContainer.updateLayout({isRoot: true});
            navigationList.el.addCls('nav-tree-animating');

            // We need to switch to micro mode on the navlist *after* the animation (this
            // allows the "sweep" to leave the item text in place until it is no longer
            // visible.
            if (collapsing) {
                navigationList.on({
                    afterlayoutanimation: function () {
                        navigationList.setMicro(true);
                        navigationList.el.removeCls('nav-tree-animating');
                    },
                    single: true
                });
            }
        }
    },

    onMainViewRender:function() {
        if (!window.location.hash) {
            this.redirectTo("Admin.dashboard.Dashboard");
        }

    },

    onRouteChange:function(id){
        this.setCurrentView(id);
    },

    onSearchRouteChange: function () {
        this.setCurrentView('searchresults');
    },

    onSwitchToModern: function () {
        Ext.Msg.confirm('Switch to Modern', 'Are you sure you want to switch toolkits?',
                        this.onSwitchToModernConfirmed, this);
    },

    onSwitchToModernConfirmed: function (choice) {
        if (choice === 'yes') {
            var s = location.search;

            // Strip "?classic" or "&classic" with optionally more "&foo" tokens
            // following and ensure we don't start with "?".
            s = s.replace(/(^\?|&)classic($|&)/, '').replace(/^\?/, '');

            // Add "?modern&" before the remaining tokens and strip & if there are
            // none.
            location.search = ('?modern&' + s).replace(/&$/, '');
        }
    },

    onEmailRouteChange: function () {
        this.setCurrentView('email');
    },
    logout:function(){
        Ext.MessageBox.confirm('系统提示', '您确定要注销登录吗？',function(btn){
            if(btn=="yes"){
                location.href="http://auth.zeeic.com/exit";
            }

        });
    }
});

Ext.define('Admin.view.email.DetailsViewModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.emaildetails'
});
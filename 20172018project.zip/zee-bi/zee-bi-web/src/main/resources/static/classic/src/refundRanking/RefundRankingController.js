Ext.define('Admin.refundRanking.RefundRankingController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.refundRankingController',
    closeBack:function () {
        var contentPanel = this.getView().up('#contentPanel');
        var oldItem=contentPanel.getLayout().getActiveItem();
        contentPanel.getLayout().setActiveItem(contentPanel.getComponent(contentPanel.items.length-2));
        contentPanel.remove(oldItem);
    },
    search:function (btn) {
        Ext.apply(btn.up("grid").store.proxy.extraParams,btn.up("form").getValues());
        btn.up("grid").store.loadPage(1);
    },
    searchAll:function (btn) {
        btn.up("form").reset();
        this.search(btn);
    },
    beforeload:function ( store, operation, eOpts) {
        var formPanel=this.getView().down("form");
        Ext.apply(store.proxy.extraParams,formPanel.getValues());
    }


});

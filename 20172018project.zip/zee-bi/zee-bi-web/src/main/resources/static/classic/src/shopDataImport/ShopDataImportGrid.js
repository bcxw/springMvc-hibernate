Ext.define('Admin.shopDataImport.ShopDataImportGrid', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.shopDataImportGrid',
    requires: ['Admin.shopDataImport.ShopDataImportController', 'Admin.shopDataImport.ShopDataImportModel', 'Admin.common.ShopCombobox'],
    controller: 'shopDataImportController',
    viewModel: 'shopDataImportModel',
    scrollable: true,
    columnLines: true,
    margin: "20px",//边距 必须
    cls: 'shadow',//阴影 必须
    autoLoad: true,
    bind: {
        store: '{shopStore}'
    },
    viewConfig: {
        enableTextSelection: true
    },
    tbar: {
        xtype: "form",
        bodyBorder: true,
        items: [{
            border: false,
            layout: "column",
            defaults: {
                labelAlign: "right",
                margin: "5 0 5 0"
            },
            items: [{
                border: false,
                width: 280,
                fieldLabel: '选择店铺',
                xtype: "shopCombobox",
                labelAlign: 'right',
                name: "shopId",
                buttonText: "浏览",
                labelWidth: 80
            }, {
                xtype: "fieldcontainer",
                fieldLabel: "日期",
                labelWidth: 100,
                name: 'planTosaleDate',
                width: 370,
                layout: "hbox",
                items: [{
                    xtype: "datefield",
                    format: "Y-m-d",
                    width: 125,
                    name: 'beginTime',
                    editable: false
                }, {
                    html: "&nbsp;-&nbsp;",
                    border: false
                }, {
                    xtype: "datefield",
                    width: 125,
                    name: 'endTime',
                    format: "Y-m-d",
                    editable: false
                }]
            }]
        }, {
            border: false,
            layout: "column",
            defaults: {
                xtype: "button",
                margin: "5 0 5 10"
            },
            items: [{
                text: '数据导入',
                handler: 'importData',
                glyph: 0xf067
            }, {
                xtype: "button",
                text: "查询",
                glyph: 0xf002,
                handler: "search"
            }, {
                xtype: "button",
                text: "全部",
                glyph: 0xf021,
                handler: "searchAll"
            }]
        }]
    },
    selModel: {
        selType: 'checkboxmodel',
        checkOnly: true,
        showHeaderCheckbox: true
    },
    bbar: {
        xtype: 'pagingtoolbar',
        displayInfo: true
    },
    columns: [
        {

            dataIndex: 'dataDate',
            text: '日期',
            width: 120,
            align: 'left',
            renderer: function (value) {
                if (value) {
                    return value.split(" ")[0];
                }
            }
        },
        {
            dataIndex: 'shopName',
            text: '商店名称',
            width: 100,
            align: 'left'
        },
        {
            dataIndex: 'uv',
            text: '访客数',
            width: 100,
            align: 'left'
        },
        {
            dataIndex: 'oldUv',
            text: '老访客数',
            width: 100,
            align: 'left'
        },
        {
            dataIndex: 'newUv',
            text: '新访客数',
            width: 100,
            align: 'left'
        },
        {
            dataIndex: 'pv',
            text: '浏览量',
            width: 100,
            align: 'left'
        },

        {
            dataIndex: 'uvDepth',
            text: '访问深度',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'pct',
            text: '客单价',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'payMoney',
            text: '支付金额',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'payCustomers',
            text: '支付买家数',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'payGoods',
            text: '支付商品数',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'payConversion',
            text: '支付转化率',
            width: 120,
            align: 'left',
            renderer: function (value) {
                if (value) {
                    return value + "%";
                }
            }
        },
        {
            dataIndex: 'pageAvgStayTime',
            text: '页面平均停留时长',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'avgStayTime',
            text: '人均停留时长',
            width: 120,
            align: 'left',
            renderer: function (value) {
                return value + "%";
            }
        },
        {
            dataIndex: 'newAvgStayTime',
            text: '新客人均停留时长',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'oldAvgStayTime',
            text: '老客人均停留时长',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'inquiryTransactionConversion',
            text: '询盘-成交转化率',
            width: 120,
            align: 'left',
            renderer: function (value) {
                if (value) {
                    return value + "%";
                }
            }
        },
        {
            dataIndex: 'silentConversionRate',
            text: '静默转化率',
            width: 120,
            align: 'left',
            renderer: function (value) {
                if (value) {
                    return value + "%";
                }
            }
        },
        {
            dataIndex: 'refundAmount',
            text: '退款金额',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'refundCount',
            text: '退款数量',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'refundMoneyRate',
            text: '退款率',
            width: 120,
            align: 'left',
            renderer: function (value) {
                if (value) {
                    return value + "%";
                }
            }
        },
        {
            dataIndex: 'refundGoodsRate',
            text: '退货率',
            width: 120,
            align: 'left',
            renderer: function (value) {
                if (value) {
                    return value + "%";
                }
            }
        },
        {
            dataIndex: 'shopCollectionCustomers',
            text: '店铺收藏买家数',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'orderCount',
            text: '下单件数',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'addShoppingCartCustomer',
            text: '新增购物车人数',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'goodsCollectionCustomers',
            text: '宝贝收藏数',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'oldPayMoney',
            text: '老客销售额',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'oldPayGoods',
            text: '老客销售量',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'oldPayCustomers',
            text: '老客成交用户数',
            width: 120,
            align: 'left'
        }

    ]
});

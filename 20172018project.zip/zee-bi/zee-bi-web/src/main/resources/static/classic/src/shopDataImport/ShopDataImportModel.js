Ext.define('Admin.shopDataImport.ShopDataImportModel', {
    extend: 'Admin.main.MainModel',
    alias: 'viewmodel.shopDataImportModel',
    stores: {
        shopStore: {
            type: "store",
            defaultRootProperty: "data",
            pageSize:20,
            fields: [{
                name: 'id'
            }, {
                name: 'dataDate'
            }, {
                name: 'shopName'
            },
                {
                    name: 'shopId'
                }, {
                    name: 'uv'
                }, {
                    name: 'pv'
                }, {
                    name: 'pct'
                }, {
                    name: 'olduv'
                }, {
                    name: 'goodsCollectionsTimes'
                }, {
                    name: 'hoppingRate'
                }, {
                    name: 'orderMoney'
                }, {
                    name: 'orderCustomers'
                }, {
                    name: 'orderConversion'
                }, {
                    name: 'newUv'
                }, {
                    name: 'payOrders'
                }, {
                    name: 'payMoney'
                }, {
                    name: 'payCustomers'
                }, {
                    name: 'payGoods'
                }, {
                    name: 'payConversion'
                }, {
                    name: 'paySuborders'
                }, {
                    name: 'goodsUv'
                }],

            proxy: {
                type: 'ajax',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    implicitIncludes: false
                },
                url: 'shopData/list',
                paramsAsJson: true
            }
        }
    }
});
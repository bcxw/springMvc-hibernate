Ext.define('Admin.dashboard.ShopBarChart', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.shopBarChart',

    requires: [
        'Ext.chart.CartesianChart',
        'Ext.chart.axis.Category',
        'Ext.chart.axis.Numeric',
        'Ext.chart.series.Bar',
        'Admin.common.ShopCombobox',
        'Ext.toolbar.Toolbar',
        'Ext.data.Store'
    ],

    cls: 'dashboard-main-chart shadow',
    height: 380,
    layout: 'fit',

    tbar:[{
        xtype:"container",
        html:"<span style='font-weight: bold;font-size: 16px;padding:0 0 0 20px;'>店铺销售额</span>"
    },"->",{
        xtype:"shopCombobox",
        margin:"0 20px 0 0",
        listeners:{
            beforerender:function( cmp, eOpts ){
                cmp.getStore().on("load",function(store, records, successful, operation, eOpts ){
                    if(!cmp.getValue()){
                        cmp.setValue(records[0]);
                    }
                });
            },
            change:function ( cmp, newValue, oldValue, eOpts) {
                var chart=cmp.up("shopBarChart").down("cartesian");

                var now=new Date();
                var yDate=new Date(now.getFullYear(),now.getMonth(),now.getDate()-1);
                var yDateStr=yDate.getFullYear()+"-"+(yDate.getMonth()+1)+"-"+yDate.getDate();
                var wDate=new Date(now.getFullYear(),now.getMonth(),now.getDate()-14);
                var wDateStr=wDate.getFullYear()+"-"+(wDate.getMonth()+1)+"-"+wDate.getDate();

                Ext.apply(chart.store.proxy.extraParams,{shopId:newValue,dateStart:wDateStr,dateEnd:yDateStr});
                chart.store.reload();

            }
        }
    }],

    items:[{
        xtype:"cartesian",
        store: {
            fields: [
                'payMoney',
                'dataDate'
            ],
            proxy: {
                type:'ajax',
                url:'shopData/shopSalesChart',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            }

        },
        innerPadding: {
            top: 10,
            right: 10
        },
        axes: [{
            type: 'numeric',
            position: 'left'
        }, {
            type: 'category',
            position: 'bottom'
        }],
        animation: Ext.isIE8 ? false : true,
        series: {
            type: 'bar',
            xField: 'dataDate',
            yField: 'payMoney',
            colors:["#5CACEE"],
            style: {
                minGapWidth: 20
            },
			//highlight:true,// {strokeStyle:'#35BAF6',fillStyle:'#82D9EA'},
			label: {
                field: 'payMoney',
                display: 'insideEnd',
                color:"#ddd"
            }
        }
    }]
});

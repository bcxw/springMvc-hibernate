Ext.define('Admin.goodsDataImport.GoodsDataImportGrid', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.goodsDataImportGrid',
    requires: ['Admin.goodsDataImport.GoodsDataImportController', 'Admin.goodsDataImport.GoodsDataImportModel', 'Admin.common.ShopCombobox'],
    controller: 'goodsDataImportController',
    viewModel: 'goodsDataImportModel',
    scrollable: true,
    columnLines: true,
    margin: "20px",//边距 必须
    cls: 'shadow',//阴影 必须
    autoLoad: true,
    bind: {
        store: '{goodsStore}'
    },
    viewConfig: {
        enableTextSelection: true
    },
    tbar: {
        xtype: "form",
        bodyBorder: true,
        items: [{
            border: false,
            layout: "column",
            defaults: {
                labelAlign: "right",
                margin: "5 0 5 0"
            },
            items: [{
                border: false,
                width: 280,
                fieldLabel: '选择店铺',
                xtype: "shopCombobox",
                labelAlign: 'right',
                name: "shopId",
                buttonText: "浏览",
                labelWidth: 80
            }, {
                xtype: "fieldcontainer",
                fieldLabel: "日期",
                labelWidth: 100,
                name: 'planTosaleDate',
                width: 370,
                layout: "hbox",
                items: [{
                    xtype: "datefield",
                    format: "Y-m-d",
                    width: 125,
                    name: 'beginTime',
                    editable: false
                }, {
                    html: "&nbsp;-&nbsp;",
                    border: false
                }, {
                    xtype: "datefield",
                    width: 125,
                    name: 'endTime',
                    format: "Y-m-d",
                    editable: false
                }]
            }]
        }, {
            border: false,
            layout: "column",
            defaults: {
                xtype: "button",
                margin: "5 0 5 10"
            },
            items: [{
                text: '数据导入',
                handler: 'importData',
                glyph: 0xf067
            }, {
                xtype: "button",
                text: "查询",
                glyph: 0xf002,
                handler: "search"
            }, {
                xtype: "button",
                text: "全部",
                glyph: 0xf021,
                handler: "searchAll"
            }]
        }]
    },
    selModel: {
        selType: 'checkboxmodel',
        checkOnly: true,
        showHeaderCheckbox: true
    },


    bbar: {
        xtype: 'pagingtoolbar',
        displayInfo: true
    },
    columns: [
        {

            dataIndex: 'dataDate',
            text: '日期',
            width: 100,
            align: 'left',
            renderer: function (value) {
                if (value) {
                    return value.split(" ")[0];
                }
            }

        },
        {
            dataIndex: 'shopName',
            text: '商店名称',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'goodsId',
            text: '商品id',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'industryType',
            text: '行业类目',
            width: 140,
            align: 'left'
        },
        {
            dataIndex: 'merchantCode',
            text: '商家编码',
            width: 110,
            align: 'left'
        },

        {
            dataIndex: 'title',
            text: '标题',
            width: 220,
            align: 'left'
        },

        {
            dataIndex: 'uv',
            text: '访客数',
            width: 80,
            align: 'left'
        },
        {
            dataIndex: 'pv',
            text: '浏览量',
            width: 80,
            align: 'left'
        },

        {
            dataIndex: 'transactionNumber',
            text: '交易笔数',
            width: 90,
            align: 'left'
        },
        {
            dataIndex: 'entranceNumber',
            text: '入口数',
            width: 80,
            align: 'left'
        },
        {
            dataIndex: 'exitNumber',
            text: '出口数',
            width: 80,
            align: 'left'
        },

        {
            dataIndex: 'avgStayTime',
            text: '平均停留时长',
            width: 100,
            align: 'left'
        },
        {
            dataIndex: 'bounceRate',
            text: '跳失率',
            width: 80,
            align: 'left'
        }, {
            dataIndex: 'collectionNumber',
            text: '收藏数',
            width: 80,
            align: 'left'
        }, {
            dataIndex: 'searchUv',
            text: '搜索引导访客数',
            width: 120,
            align: 'left'
        }, {
            dataIndex: 'oldUv',
            text: '老访客数',
            width: 90,
            align: 'left'
        }, {
            dataIndex: 'oldPayMoney',
            text: '老客销售额',
            width: 100,
            align: 'left'
        }, {
            dataIndex: 'oldPayGoods',
            text: '成交宝贝数(老客)',
            width: 120,
            align: 'left'
        }, {
            dataIndex: 'oldTransactionNumber',
            text: '老客成交笔数',
            width: 120,
            align: 'left'
        }, {
            dataIndex: 'oldPayConversion',
            text: '老客支付转化率',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'payConversion',
            text: '支付转化率',
            width: 100,
            align: 'left',
            renderer: function (value) {
                if (value) {
                    return value + "%";
                }
            }
        },
        {
            dataIndex: 'payMoney',
            text: '支付金额',
            width: 100,
            align: 'left'
        }, {
            dataIndex: 'payGoods',
            text: '支付商品件数',
            width: 100,
            align: 'left'
        },

        {
            dataIndex: 'refundCount',
            text: '成功退款笔数',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'refundMoney',
            text: '成功退款金额',
            width: 120,
            align: 'left'
        }
        ,
        {
            dataIndex: 'refundRate',
            text: '退款率',
            width: 120,
            align: 'left',
            renderer: function (value) {
                if (value) {
                    return value + "%";
                }

            }

        }
    ]
});

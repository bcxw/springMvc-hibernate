Ext.define('Admin.main.MainViewModel', {
    extend: 'Admin.main.MainModel',
    alias: 'viewmodel.mainViewModel',

    stores:{
        navigationTreeStore:{
            storeId: 'navigationTreeStore',
            type:"tree",
            fields: [{
                name: 'text'
            }],
            defaultRootProperty:"data",
            proxy: {
                type:'ajax',
                url:'user/getMenu'
            },
            root: {
                expanded: true
            }
        }
    }
});

Ext.define('Admin.dashboard.ShopConversionChart', {
    extend: 'Ext.chart.CartesianChart',
    alias: 'widget.shopConversionChart',

	requires: [
        'Ext.chart.CartesianChart',
        'Ext.chart.axis.Category',
        'Ext.chart.axis.Numeric',
        'Ext.chart.series.Line',
        'Admin.common.ShopCombobox',
        'Ext.toolbar.Toolbar',
        'Ext.data.Store'
    ],
	
    cls: 'dashboard-main-chart shadow',
    height: 180,

    tbar:[{
        xtype:"container",
        html:"<span style='font-weight: bold;font-size:15px;padding:0 0 0 10px;color:#FF9728'>—退货率</span><span style='font-weight: bold;font-size:15px;padding:0 0 0 10px;color:#B3D20F'>—转化率</span>"
    },"->",{
        xtype:"shopCombobox",
        margin:"0 20px 0 0",
        listeners:{
            beforerender:function( cmp, eOpts ){
                cmp.getStore().on("load",function(store, records, successful, operation, eOpts ){
                    if(!cmp.getValue()){
                        cmp.setValue(records[0]);
                    }
                });
            },
            change:function ( cmp, newValue, oldValue, eOpts) {
                var chart=cmp.up("shopConversionChart");

                var now=new Date();
                var yDate=new Date(now.getFullYear(),now.getMonth(),now.getDate()-1);
                var yDateStr=yDate.getFullYear()+"-"+(yDate.getMonth()+1)+"-"+yDate.getDate();
                var wDate=new Date(now.getFullYear(),now.getMonth(),now.getDate()-14);
                var wDateStr=wDate.getFullYear()+"-"+(wDate.getMonth()+1)+"-"+wDate.getDate();

                Ext.apply(chart.store.proxy.extraParams,{shopId:newValue,dateStart:wDateStr,dateEnd:yDateStr});
                chart.store.reload();

            }
        }
    }],


    store: {
        fields: [
            'dataDate','payConversion','refundGoodsRate'
        ],
        proxy: {
            type:'ajax',
            url:'shopData/shopSalesChart',
            reader: {
                type: 'json',
                rootProperty: 'data'
            }
        }
    },

    innerPadding: {
        top: 10,
        right: 20
    },
    colors:["#FF9728","#B3D20F"],
    axes: [{
        type: 'numeric',
        fields: ['refundGoodsRate','payConversion'],
        position: 'left'
    }, {
        type: 'category',
        fields: 'dataDate',
        position: 'bottom'
    }],
    series: [{
        type: 'line',
        xField: 'dataDate',
        yField: 'refundGoodsRate',
        marker: {
            type: 'square'
        },
        //highlightCfg: {scaling: 2},
        label: {
            field: 'refundGoodsRate',
            display: 'over'
        },
        /*tooltip: {
            trackMouse: true,
            renderer: function (tooltip, record, item) {
                tooltip.setHtml(record.get(item.series.getYField()) + '%');
            }
        }*/
    }, {
        type: 'line',
        xField: 'dataDate',
        yField: 'payConversion',
        marker: {
            radius:5
        },
        //highlightCfg: {scaling: 2},
        label: {
            field: 'payConversion',
            display: 'under'
        },
        /*tooltip: {
            trackMouse: true,
            renderer: function (tooltip, record, item) {
                tooltip.setHtml(record.get(item.series.getYField()) + '%');
            }
        }*/
    }]
});

Ext.define('Admin.dashboard.AGPGrid', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.agpGrid',
    //xtype: 'agpGrid',
    requires: [
        'Ext.grid.Panel',
        'Ext.grid.View',
        'Ext.form.field.Text',
        'Ext.button.Button',
        'Ext.selection.CheckboxModel'
    ],

    cls: 'todo-list shadow-panel shadow',
    title: 'AGP列表',
    height: 400,
    layout: 'fit',
    scroll: 'none',
    columns: [
        {
            xtype: 'rownumberer',
            width: 30
        },
        {
            xtype: 'gridcolumn',
            dataIndex: 'shopName',
            text: '店铺名称',
            flex: 1
        },
        {
            xtype: 'gridcolumn',
            dataIndex: 'yesterdayAgp',
            text: '昨日AGP',
            flex: 1
        }, {
            xtype: 'gridcolumn',
            dataIndex: 'storeOwner',
            text: '店铺负责人',
            flex: 1
        }, {
            xtype: 'gridcolumn',
            dataIndex: 'storeParticipants',
            text: '店铺参与人',
            flex: 1
        }, {
            xtype: 'gridcolumn',
            dataIndex: 'comparedToLastWeek',
            text: '上周同比(%)',
            flex: 1
        }, {
            xtype: 'gridcolumn',
            dataIndex: 'comparedToLastYear',
            text: '去年同比(%)',
            flex: 1
        }
    ],
    store: {
        autoLoad: true,
        proxy: {
            type: 'ajax',
            url: 'agp/list',
            reader: {
                type: 'json',
                rootProperty: 'data'
            }
        }
    }
});

Ext.define('Admin.dashboard.ShopVisitorChart', {
    extend: 'Ext.chart.PolarChart',
    alias: 'widget.shopVisitorChart',

	
	requires: [
        'Ext.chart.PolarChart',
        'Ext.chart.axis.Category',
        'Ext.chart.axis.Numeric',
        'Ext.chart.series.Pie3D',
        'Admin.common.ShopCombobox',
        'Ext.toolbar.Toolbar',
        'Ext.data.Store'
    ],
	
    cls: 'dashboard-main-chart shadow',
    height: 400,

    title: '访客来源',
    tools: [{
        xtype:"container",
        layout:"column",
        items:[{
            xtype: "datefield",
            margin:"-10px 10px -10px 0",
            format:"Y-m-d",
            width: 125,
            name:"dataDate",
            editable:false,
            value:new Date(new Date().getTime()-(24*60*60*1000)),
            listeners:{
                change:function ( cmp, newValue, oldValue, eOpts) {
                    var chart=cmp.up("shopVisitorChart");
                    var shopId=cmp.up().down("shopCombobox").getValue();

                    Ext.apply(chart.store.proxy.extraParams,{shopId:shopId,dataDate:cmp.getSubmitValue()});
                    chart.store.reload();

                }
            }
        },{
            xtype:"shopCombobox",
            margin:"-10px 0 -10px 0",
            listeners:{
                beforerender:function( cmp, eOpts ){
                    cmp.getStore().on("load",function(store, records, successful, operation, eOpts ){
                        if(!cmp.getValue()){
                            cmp.setValue(records[0]);
                        }
                    });
                },
                change:function ( cmp, newValue, oldValue, eOpts) {
                    var chart=cmp.up("shopVisitorChart");
                    var dataDate=cmp.up().down("datefield[name='dataDate']").getSubmitValue();

                    Ext.apply(chart.store.proxy.extraParams,{shopId:newValue,dataDate:dataDate});
                    chart.store.reload();

                }
            }
        }]
    }],
    store: {
        fields: ['title', 'uv' ],
        proxy: {
            type:'ajax',
            url:'shopData/getNewOldCustomers',
            reader: {
                type: 'json',
                rootProperty: 'data'
            }
        }
    },

    colors:["#FF9728","#B3D20F"],
    innerPadding: 40,
    legend: {
        type: 'sprite',
        docked: 'right'
    },
    series: [
        {
            type: 'pie3d',
            angleField: 'uv',
            donut: 30,
            distortion: 0.6,
            //highlight: {margin: 20},
            label: {
                field: 'title'
            }
        }
    ]


});

Ext.define('Admin.goodsIndex.GoodsIndexGrid', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.goodsIndexGrid',
    requires: ['Admin.goodsIndex.GoodsIndexController', 'Admin.goodsIndex.GoodsIndexModel', 'Admin.common.ShopCombobox'],
    controller: 'goodsIndexController',
    viewModel: 'goodsIndexModel',
    scrollable: true,
    columnLines: true,
    margin: "20px",//边距 必须
    cls: 'shadow',//阴影 必须
    autoLoad: true,
    bind: {
        store: '{goodsStore}'
    },
    viewConfig: {
        enableTextSelection: true
    },
    tbar: {
        xtype: "form",
        bodyBorder: true,
        items: [{
            border: false,
            layout: "column",
            defaults: {
                labelAlign: "right",
                margin: "5 0 5 0"
            },
            items: [{
                border: false,
                width: 280,
                fieldLabel: '选择店铺',
                xtype: "shopCombobox",
                labelAlign: 'right',
                name: "shopId",
                buttonText: "浏览",
                labelWidth: 80
            }, {
                border: false,
                width: 280,
                fieldLabel: '款号',
                xtype: "textfield",
                labelAlign: 'right',
                name: "skuId",
                labelWidth: 80,
                enableKeyEvents: true,
                listeners: {
                    keydown: "enterSearch"
                }
            }, {
                xtype: "fieldcontainer",
                fieldLabel: "日期",
                labelWidth: 100,
                name: 'planTosaleDate',
                width: 370,
                layout: "hbox",
                items: [{
                    xtype: "datefield",
                    format: "Y-m-d",
                    width: 125,
                    name: 'beginTime',
                    editable: false
                }, {
                    html: "&nbsp;-&nbsp;",
                    border: false
                }, {
                    xtype: "datefield",
                    width: 125,
                    name: 'endTime',
                    format: "Y-m-d",
                    editable: false
                }]
            }]
        }, {
            border: false,
            layout: "column",
            defaults: {
                xtype: "button",
                margin: "5 0 5 10"
            },
            items: [{
                xtype: "button",
                text: "查询",
                glyph: 0xf002,
                handler: "search"
            }, {
                xtype: "button",
                text: "全部",
                glyph: 0xf021,
                handler: "searchAll"
            }]
        }]
    },
    selModel: {
        selType: 'checkboxmodel',
        checkOnly: true,
        showHeaderCheckbox: true
    },

    bbar: {
        xtype: 'pagingtoolbar',
        displayInfo: true
    },
    columns: [
        {

            dataIndex: 'dataDate',
            text: '日期',
            width: 100,
            align: 'left',
            renderer: function (value, opt) {
                if (value) {
                    return value.split(" ")[0];
                }
            }
        }, {
            dataIndex: 'goodsId',
            text: '商品id',
            width: 160,
            align: 'left'
        },
        {
            dataIndex: 'iId',
            text: '款号',
            width: 180,
            align: 'left',
            renderer: function (value, opt) {
                if (value) {
                    if (opt.record.data.iId == opt.record.data.shopIId) {
                        var sku = "";
                        var skuId = opt.record.data.skuId;
                        if (skuId.indexOf("-") !== -1) {
                            var strArray = skuId.split("-");
                            strArray.pop();
                            for (var i = 0; i < strArray.length; i++) {
                                if (i !== (strArray.length - 1)) {
                                    sku += strArray[i] + "-";
                                } else {
                                    sku += strArray[i];
                                }
                            }
                            return sku;
                        } else {
                            return skuId;
                        }

                    }
                    return value;
                }

            }
        },
        {
            dataIndex: 'skuId',
            text: '商品编码',
            width: 160,
            align: 'left'
        },
        {
            dataIndex: 'shopName',
            text: '商店名称',
            width: 100,
            align: 'left'
        },
        {
            dataIndex: 'title',
            text: '标题',
            width: 160,
            align: 'left'
        },
        {
            dataIndex: 'url',
            text: '链接',
            width: 330,
            align: 'left'
        },

        {
            dataIndex: 'uv',
            text: '访客数',
            width: 90,
            align: 'left'
        },
        {
            dataIndex: 'pv',
            text: '浏览量',
            width: 90,
            align: 'left'
        },
        {
            dataIndex: 'avgStayTime',
            text: '平均停留时长',
            width: 100,
            align: 'left'
        },
        {
            dataIndex: 'bounceRate',
            text: '跳失率',
            width: 100,
            align: 'left'
        },
        {
            dataIndex: 'payConversion',
            text: '支付转化率',
            width: 90,
            align: 'left',
            renderer: function (value) {
                return value + "%";

            }
        },
        {
            dataIndex: 'payMoney',
            text: '支付金额',
            width: 90,
            align: 'left'
        },
        {
            dataIndex: 'payGoods',
            text: '支付商品件数',
            width: 100,
            align: 'left'
        },
        {
            dataIndex: 'refundCount',
            text: '成功退款笔数',
            width: 110,
            align: 'left'
        },
        {
            dataIndex: 'refundMoney',
            text: '成功退款金额',
            width: 110,
            align: 'left'
        },
        {
            dataIndex: 'pcUv',
            text: 'pc端访客数',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'pcPv',
            text: 'pc端浏览量',
            width: 120.,
            align: 'left'
        },
        {
            dataIndex: 'pcAvgStayTime',
            text: 'pc端平均停留时长',
            width: 130,
            align: 'left'
        },
        {
            dataIndex: 'pcDetailHoppingRate',
            text: 'pc端详情页跳出率',
            width: 130,
            align: 'left'
        },
        {
            dataIndex: 'pcPayConversion',
            text: 'pc端支付转化率',
            width: 130,
            align: 'left',
            renderer: function (value) {
                if (value) {
                    return value + "%";
                }

            }
        },
        {
            dataIndex: 'pcPayMoney',
            text: 'pc端支付金额',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'pcPayGoods',
            text: 'pc端支付商品件数',
            width: 130,
            align: 'left'
        },
        {
            dataIndex: 'mpUv',
            text: '无线端访客数',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'mpPv',
            text: '无线端浏览量',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'mpAvgStayTime',
            text: '无线端平均停留时长',
            width: 140,
            align: 'left'
        },
        {
            dataIndex: 'mpBounceRate',
            text: '无线端跳失率',
            width: 140,
            align: 'left',
            renderer: function (value) {
                if (value !== undefined) {
                    return value + "%";
                }

            }
        },
        {
            dataIndex: 'mpPayConversion',
            text: '无线端支付转化率',
            width: 140,
            align: '130',
            renderer: function (value) {
                if (value !== undefined) {
                    return value + "%";
                }

            }
        },
        {
            dataIndex: 'mpPayMoney',
            text: '无线端支付金额',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'mpPayGoods',
            text: '无线端支付商品件数',
            width: 140,
            align: 'left'
        }
    ]
});

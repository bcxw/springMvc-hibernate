Ext.define('Admin.main.MainModel', {
    extend: 'Ext.app.ViewModel',

    data: {
        currentView: null,
        addData: false,//添加
        modifyData: false,//修改
        removeData: false,//删除
        submitData: false,//提交
        setData: false,//设置
        addItem: false,//添加子项
        modifyItem: false,//修改子项
        removeItem: false,//删除子项
        committed: false,//提交审核
        cancleCommitted: false,//取消提交
        auditData: false,//审核
        confirmCompleted: false,//确认提交
        stopData: false,//废弃
        exportData:false,//导出
        getbackData:false//收回
    },
    constructor: function (config) {
        this.callParent(arguments);
        Ext.Ajax.request({
            scope: this,
            url: "user/getConfig",
            success: function (response) {
                var data = Ext.decode(response.responseText);
                if(data.success){
                    this.setData(data.data);
                }else{
                    location.href = "http://auth.zeeic.com/exit";
                }
            },
            failure: function (response, opts) {
                location.href = "http://auth.zeeic.com/exit";
            }
        });
    }
});

Ext.define('Admin.shopBase.ShopBaseViewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.shopBaseViewController',
    requires: 'Admin.common.EmployeeSelectPanel',
    closeBack: function () {
        var contentPanel = this.getView().up('#contentPanel');
        var oldItem = contentPanel.getLayout().getActiveItem();
        contentPanel.getLayout().setActiveItem(contentPanel.getComponent(contentPanel.items.length - 2));
        contentPanel.remove(oldItem);
    },
    showEmployeeSelectForm: function (button) {
        var me = this;
        var selectedNode = button.up("shopBaseGrid").getSelection();
        if (selectedNode && selectedNode.length == 1) {
            selectedNode = selectedNode[0];

            var oldEmpArr = new Array();
            var userIds = selectedNode.data.userIds;
            var userNames = selectedNode.data.userNames;
            if (userIds && userNames) {
                var userIdsArr = userIds.split(',');
                var userNamesArr = userNames.split(',');

                Ext.Array.each(userIdsArr, function (value, index, countriesItSelf) {
                    oldEmpArr.push({id: value, username: userNamesArr[index]});
                });
            }

            var employeeForm = Ext.create("Admin.common.EmployeeSelectPanel", {
                margin: "20px",//边距 必须
                controller: 'shopBaseViewController',
                selectedEmployeeData: oldEmpArr,
                selectedCallback: function (empArr) {

                    if (empArr && empArr.length > 0) {
                        var peopleArr = new Array();
                        Ext.Array.each(empArr, function (item) {
                            peopleArr.push({
                                shopId: selectedNode.data.shopId,
                                shopName: selectedNode.data.shopName,
                                userId: item.id,
                                userName: item.username,
                                userCode: item.id,
                                departmentId: item.departmentId,
                                departmentName: item.departmentName
                            });
                        });
                        Ext.Ajax.request({
                            url: 'shopBase/saveEmployees',
                            params: {
                                peoples: Ext.encode(peopleArr),
                                shopId: selectedNode.data.shopId
                            },
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if (obj.success) {
                                    Ext.Msg.alert('系统提示', "保存成功！");
                                    me.getView().store.reload();
                                } else {
                                    Ext.Msg.alert('删除失败', obj.message);
                                }
                            },
                            failure: function (response, opts) {
                                Ext.Msg.alert('操作失败', response.status + response.responseText);
                            }
                        });
                    }

                    me.closeBack();
                }
            });
            var contentPanel = this.getView().up('#contentPanel');
            contentPanel.getLayout().setActiveItem(contentPanel.add(employeeForm));


        } else {
            Ext.Msg.alert('系统提示', '请选择要授权的店铺！')
        }

    },
    /**
     * Agp
     * @param button
     */
    setting: function (button) {
        var me = this;
        var selectedNode = button.up("shopBaseGrid").getSelection();
        if (selectedNode && selectedNode.length == 1) {
            selectedNode = selectedNode[0];
            var formPanel = Ext.create("Admin.shopDataImport.ShopBaseForm", {
                title: '设置',
                width: 400,
                height: 300
            });
            var contentPanel = this.getView().up('#contentPanel');
            contentPanel.getLayout().setActiveItem(contentPanel.add(formPanel));
            formPanel.down("hidden[name='shopId']").setValue(selectedNode.data.shopId);
            formPanel.down("hidden[name='shopName']").setValue(selectedNode.data.shopName);
            formPanel.load({
                url: "shopBase/detail",
                method: 'get',
                params: {
                    shopId: selectedNode.data.shopId
                }
            });


        } else {
            Ext.Msg.alert("系统提示", "请选择需要设置的店铺!");
        }


    },
    confirmSetting: function (button) {
        var formPanel = button.up("shopBaseForm");
        if (formPanel.getForm().isValid()) {
            formPanel.mask("正在处理...");
            formPanel.getForm().submit({
                method: "Post",
                url: 'shopBase/setting',
                success: function (form, action) {
                    formPanel.unmask();
                    if (action.result.success) {
                        Ext.Msg.alert('系统提示', action.result.message);
                    } else {
                        Ext.Msg.alert('系统提示', action.result.message);
                    }
                },
                failure: function (form, action) {
                    formPanel.unmask();
                    Ext.Msg.alert('操作失败', action && action.result ? action.result.message : "访问服务器失败，请联系管理员！");

                }
            });

        } else {
            Ext.Msg.alert("系统提示", "请正确填写信息!");
        }
    },
    /**
     * 选择店铺负责人
     * @param button
     */
    selectStoreOwner: function (button) {
        var me = this;
        var formPanel = button.up("form");
        var shopId = formPanel.down("hidden[name='shopId']").getValue();
        //显示人员选择窗口
        Ext.Ajax.request({
            url: 'shopBase/getPeoplesByShopId',
            method: "Get",
            params: {
                shopId: shopId,
                type: 'admin'
            },
            success: function (response, opts) {
                var obj = Ext.decode(response.responseText);
                if (obj.success) {
                    var selectedEmployeeData = new Array();
                    if (obj.data && obj.data.length > 0) {
                        Ext.Array.each(obj.data, function (item) {
                            selectedEmployeeData.push({
                                id: item.userId,
                                username: item.username,
                                departmentId: item.departmentId,
                                departmentName: item.departmentName
                            });
                        })
                    }
                    //获取已选人员后显示选择人员窗口
                    var selectEmployeeWin = Ext.create("Admin.common.EmployeeSelectPanel", {
                        margin: "20px",//边距 必须
                        controller: 'shopBaseViewController',
                        selectedEmployeeData: selectedEmployeeData,
                        selectedCallback: function (emplyeeArr) {
                            if (emplyeeArr && emplyeeArr.length > 0) {
                                var peopleArr = new Array();
                                Ext.Array.each(emplyeeArr, function (item) {
                                    peopleArr.push({
                                        shopId: shopId,
                                        userId: item.id,
                                        username: item.username,
                                        userCode: item.id,
                                        departmentId: item.departmentId,
                                        departmentName: item.departmentName,
                                        type: 'admin'
                                    });
                                });
                                Ext.Ajax.request({
                                    url: 'shopBase/saveShopPeoples',
                                    params: {
                                        peoples: Ext.encode(peopleArr),
                                        shopId: shopId,
                                        type: "admin"
                                    },
                                    success: function (response, opts) {
                                        var obj = Ext.decode(response.responseText);
                                        if (obj.success) {
                                            Ext.Msg.alert('系统提示', "保存成功！");
                                            selectEmployeeWin.close();
                                        } else {
                                            Ext.Msg.alert('删除失败', obj.message);
                                        }
                                    },
                                    failure: function (response, opts) {
                                        Ext.Msg.alert('操作失败', response.status + response.responseText);
                                    }
                                });
                            } else {
                                Ext.Msg.alert('系统提示', "没有选择任何人员数据，操作失败！");
                            }
                        }
                    });

                    var contentPanel = me.getView().up('#contentPanel');
                    contentPanel.getLayout().setActiveItem(contentPanel.add(selectEmployeeWin));
                } else {
                    Ext.Msg.alert('操作失败', obj.message);
                }
            },
            failure: function (response, opts) {
                Ext.Msg.alert('操作失败', response.status + response.responseText);
            }
        });

    },
    /**
     * 选择店铺参与者
     * @param button
     */
    selectParticipator: function (button) {
        var me = this;
        var formPanel = button.up("form");
        var shopId = formPanel.down("hidden[name='shopId']").getValue();
        //显示人员选择窗口
        Ext.Ajax.request({
            url: 'shopBase/getPeoplesByShopId',
            method: "Get",
            params: {
                shopId: shopId,
                type: 'participator'
            },
            success: function (response, opts) {
                var obj = Ext.decode(response.responseText);
                if (obj.success) {
                    var selectedEmployeeData = new Array();
                    if (obj.data && obj.data.length > 0) {
                        Ext.Array.each(obj.data, function (item) {
                            selectedEmployeeData.push({
                                id: item.userId,
                                username: item.username,
                                departmentId: item.departmentId,
                                departmentName: item.departmentName
                            });
                        })
                    }
                    //获取已选人员后显示选择人员窗口
                    var selectEmployeeWin = Ext.create("Admin.common.EmployeeSelectPanel", {
                        margin: "20px",//边距 必须
                        controller: 'shopBaseViewController',
                        selectedEmployeeData: selectedEmployeeData,
                        selectedCallback: function (emplyeeArr) {
                            if (emplyeeArr && emplyeeArr.length > 0) {
                                var peopleArr = new Array();
                                Ext.Array.each(emplyeeArr, function (item) {
                                    peopleArr.push({
                                        shopId: shopId,
                                        userId: item.id,
                                        username: item.username,
                                        userCode: item.id,
                                        departmentId: item.departmentId,
                                        departmentName: item.departmentName,
                                        type: 'participator'
                                    });
                                });
                                Ext.Ajax.request({
                                    url: 'shopBase/saveShopPeoples',
                                    params: {
                                        peoples: Ext.encode(peopleArr),
                                        shopId: shopId,
                                        type: 'participator'
                                    },
                                    success: function (response, opts) {
                                        var obj = Ext.decode(response.responseText);
                                        if (obj.success) {
                                            Ext.Msg.alert('系统提示', "保存成功！");
                                            selectEmployeeWin.close();
                                        } else {
                                            Ext.Msg.alert('删除失败', obj.message);
                                        }
                                    },
                                    failure: function (response, opts) {
                                        Ext.Msg.alert('操作失败', response.status + response.responseText);
                                    }
                                });
                            } else {
                                Ext.Msg.alert('系统提示', "没有选择任何人员数据，操作失败！");
                            }
                        }
                    });

                    var contentPanel = me.getView().up('#contentPanel');
                    contentPanel.getLayout().setActiveItem(contentPanel.add(selectEmployeeWin));
                } else {
                    Ext.Msg.alert('操作失败', obj.message);
                }
            },
            failure: function (response, opts) {
                Ext.Msg.alert('操作失败', response.status + response.responseText);
            }
        });

    }


})
;

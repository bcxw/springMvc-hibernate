Ext.define('Admin.shopDataImport.ShopBaseForm', {
    extend: 'Ext.form.Panel',
    alias: 'widget.shopBaseForm',

    requires: [
        'Admin.shopBase.ShopBaseViewController',
        'Ext.container.Container',
        'Ext.form.field.HtmlEditor',
        'Ext.layout.container.Anchor',
        'Ext.layout.container.HBox',
        'Admin.common.ShopCombobox',
        'Admin.common.MonthField',
        'Admin.common.EmployeeSelectPanel'
    ],
    controller: 'shopBaseViewController',
    margin: "20px",//边距 必须
    cls: 'shadow',//阴影 必须
    bodyPadding: 10,
    buttonAlign: 'center',
    buttons: [{
        text: '确定',
        handler: 'confirmSetting'
    }, {
        text: '取消',
        handler: 'closeBack'
    }],
    items: [{
        xtype: 'hidden',
        name: 'shopId'
    }, {
        xtype: 'hidden',
        name: 'shopName'
    }, {
        xtype: 'hidden',
        name: 'id'
    }, {
        layout: 'column',
        border: false,
        items: [{
            columnWidth: 0.5,
            border: false,
            items: [{
                xtype: "fieldcontainer",
                fieldLabel: "店铺负责人",
                labelAlign: "right",
                width: '100%',
                items: {
                    xtype: 'button',
                    handler: 'selectStoreOwner',
                    text: '选择人员'
                }

            }, {
                xtype: "fieldcontainer",
                fieldLabel: "店铺参与者",
                labelAlign: "right",
                width: '100%',
                items: {
                    xtype: 'button',
                    handler: 'selectParticipator',
                    text: '选择人员'
                }

            }]
        }, {
            columnWidth: 0.5,
            border: false,
            items: [{
                xtype: "monthfield",
                format: "Y-m",
                fieldLabel: "AGP月份",
                labelAlign: "right",
                name: "agpMonth",
                width: '100%',
                allowBlank: false,
                value: Ext.util.Format.date(Ext.Date.add(new Date(), Ext.Date.MONTH, -1), "Y-m")
            }, {
                xtype: "numberfield",
                fieldLabel: "agp率",
                labelAlign: "right",
                name: "agpRate",
                width: '100%',
                allowBlank: false
            }]
        }]
    }

    ]

})
;

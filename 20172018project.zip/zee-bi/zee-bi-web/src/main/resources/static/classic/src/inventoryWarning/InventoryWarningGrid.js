Ext.define('Admin.inventoryWarning.InventoryWarningGrid', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.inventoryWarningGrid',
    requires: ['Admin.inventoryWarning.InventoryWarningController', 'Admin.inventoryWarning.InventoryWarningModel', 'Admin.common.ShopCombobox'],
    controller: 'inventoryWarningController',
    viewModel: 'inventoryWarningModel',
    scrollable: true,
    columnLines: true,
    margin: "20px",//边距 必须
    cls: 'shadow',//阴影 必须
    autoLoad: true,
    bind: {
        store: '{inventoryWarningStore}'
    },
    viewConfig: {
        enableTextSelection: true
    },
    tbar: {
        xtype: "form",
        bodyBorder: true,
        items: [{
            border: false,
            layout: "column",
            defaults: {
                labelAlign: "right",
                margin: "5 0 5 0"
            },
            items: [{
                border: false,
                width: 280,
                fieldLabel: '商品编码',
                xtype: "textfield",
                labelAlign: 'right',
                name: "skuId",
                labelWidth: 80,
                enableKeyEvents: true,
                listeners: {
                    keydown: "enterSearch"
                }
            }]
        }, {
            border: false,
            layout: "column",
            defaults: {
                xtype: "button",
                margin: "5 0 5 10"
            },
            items: [{
                xtype: "button",
                text: "查询",
                glyph: 0xf002,
                handler: "search"
            }, {
                xtype: "button",
                text: "全部",
                glyph: 0xf021,
                handler: "searchAll"
            }]
        }]
    },
    selModel: {
        selType: 'checkboxmodel',
        checkOnly: true,
        showHeaderCheckbox: true
    },


    bbar: {
        xtype: 'pagingtoolbar',
        displayInfo: true
    },
    columns: [
        {
            dataIndex: 'skuId',
            text: '商品编码',
            width: 140,
            align: 'left'
        },
        {
            dataIndex: 'iid',
            text: '款式编码',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'qty',
            text: '可售数量',
            width: 100,
            align: 'left'
        },
        {
            dataIndex: 'residueDays',
            text: '可售天数',
            width: 100,
            align: 'left'
        },
        {
            dataIndex: 'avgSale',
            text: '7平均销量',
            width: 100,
            align: 'left'
        },
        {
            dataIndex: 'avgUv',
            text: '7天平均访客数',
            width: 120,
            align: 'left'
        },
        {
            dataIndex: 'avgPv',
            text: '7天平均浏览量',
            width: 120,
            align: 'left'
        }

    ]
});

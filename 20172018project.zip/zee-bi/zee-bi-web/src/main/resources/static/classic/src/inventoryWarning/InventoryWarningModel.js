Ext.define('Admin.inventoryWarning.InventoryWarningModel', {
    extend: 'Admin.main.MainModel',
    alias: 'viewmodel.inventoryWarningModel',
    stores: {
        inventoryWarningStore: {
            type: "store",
            defaultRootProperty: "data",
            pageSize: 20,
            fields: [{
                name: 'id'
            }, {
                name: 'skuId'
            }, {
                name: 'iId'
            }, {
                name: 'qty'
            }, {
                name: 'orderLock'
            }, {
                name: 'residueDays'
            }, {
                name: 'avgSale'
            }, {
                name: 'avgUv'
            }, {
                name: 'avgPv'
            }],

            proxy: {
                type: 'ajax',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    implicitIncludes: false
                },
                url: 'inventory/list',
                paramsAsJson: true
            }
        }
    }
});
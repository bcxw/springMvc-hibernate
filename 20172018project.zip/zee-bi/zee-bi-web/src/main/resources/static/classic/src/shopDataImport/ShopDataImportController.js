Ext.define('Admin.shopDataImport.ShopDataImportController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.shopDataImportController',
    closeBack: function () {
        var contentPanel = this.getView().up('#contentPanel');
        var oldItem = contentPanel.getLayout().getActiveItem();
        contentPanel.getLayout().setActiveItem(contentPanel.getComponent(contentPanel.items.length - 2));
        contentPanel.remove(oldItem);
    },
    /**
     * 查询
     * @param button
     */
    search: function (button) {
        var grid = button.up("grid");
        Ext.apply(grid.store.proxy.extraParams, button.up("form").getValues());
        grid.store.loadPage(1);
    },
    /**
     * 全部
     * @param button
     */
    searchAll: function (button) {
        button.up("form").reset();
        this.search(button);
    },
    /**
     * 导入文件
     * @param button
     */
    uploadFile: function (button) {
        var me = this;
        var formPanel = button.up("shopDataImportForm");
        var grid = formPanel.down("grid[name=filesListTable]");
        var items = grid.store.getData().items;
        if (formPanel.getForm().isValid()) {
            if (!items || items.length <= 0) {
                Ext.Msg.alert('系统提示', "请添加文件!");
                return;
            }
            if (!items || items.length > 5) {
                Ext.Msg.alert('系统提示', "上传文件过多,请分批导入!");
                return;
            }
            var shopCombobox = formPanel.down("shopCombobox[name=shopId]");
            formPanel.mask("正在处理...");
            formPanel.getForm().submit({
                method: "Post",
                url: 'shopData/importData',
                params: {
                    shopName: shopCombobox.getRawValue()
                },
                success: function (form, action) {
                    formPanel.unmask();
                    if (action.result.success) {
                        Ext.Msg.alert('系统提示', action.result.message);
                    } else {
                        Ext.Msg.alert('系统提示', action.result.message);
                    }
                    var shopDataImportGrid = me.getView().up('#contentPanel').down("shopDataImportGrid");
                    me.closeBack();
                    shopDataImportGrid.store.reload();
                },
                failure: function (form, action) {
                    formPanel.unmask();
                    Ext.Msg.alert('操作失败', action && action.result ? action.result.message : "访问服务器失败，请联系管理员！");

                }
            });
        } else {
            Ext.Msg.alert("系统提示", "请正确填写信息!");
        }


    },
    /**
     * 打开导入文件窗口
     */
    importData: function () {
        var formPanel = Ext.create("Admin.shopDataImport.ShopDataImportForm", {
            title: '添加',
            width: this.getView().getWidth(),
            height: this.getView().getHeight(),
            x: this.getView().getX(),
            y: this.getView().getY()
        });
        var filesListTablestore = formPanel.down('gridpanel[name=filesListTable]').store;
        filesListTablestore.removeAll();
        var contentPanel = this.getView().up('#contentPanel');
        contentPanel.getLayout().setActiveItem(contentPanel.add(formPanel));

    }


});
Ext.define('Admin.view.main.MainModel', {
    extend: 'Admin.main.MainModel',
    alias: 'viewmodel.main',

    data: {
        currentView: null
    },
    stores:{
        inavigationTree:{
            storeId: 'NavigationTree',
            type:"tree",
            fields: [{
                name: 'text'
            }],
            defaultRootProperty:"data",
            proxy: {
                type:'ajax',
                url:'user/getMenu'
            },
            root: {
                expanded: true
            }
        }
    }
});

Ext.define('Admin.shopDataImport.ShopDataImportForm', {
    extend: 'Ext.form.Panel',
    alias: 'widget.shopDataImportForm',

    requires: [
        'Admin.shopDataImport.ShopDataImportController',
        'Ext.container.Container',
        'Ext.form.field.HtmlEditor',
        'Ext.layout.container.Anchor',
        'Ext.layout.container.HBox',
        'Admin.common.ShopCombobox'
    ],
    controller: 'shopDataImportController',
    margin: "20px",//边距 必须
    cls: 'shadow',//阴影 必须
    bodyPadding: 10,
    buttonAlign: 'center',
    buttons: [{
        text: '上传',
        handler: 'uploadFile'
    }, {
        text: '取消',
        handler: 'closeBack'
    }],
    items: [{
        border: false,
        padding: 40,
        items: [{
            layout: "column",
            defaults: {margin: '0 0 0 10'},
            items: [{
                border: false,
                fieldLabel: '选择店铺',
                xtype: "shopCombobox",
                labelAlign: 'right',
                name: "shopId",
                labelWidth: 80,
                allowBlank: false
            }, {
                xtype: "fileuploadfield",
                buttonText: "选择文件",
                buttonOnly: true,
                name: "file",
                listeners: {
                    afterrender: function (cmp, eOpts) {
                        this.fileInputEl.dom.setAttribute('multiple', true);
                    },

                    change: function ($this, value, eOpts) {
                        var files = $this.fileInputEl.dom.files;
                        var filesListTablestore = Ext.ComponentQuery.query('gridpanel[name=filesListTable]')[0].store;
                        filesListTablestore.removeAll();
                        var size;
                        for (var j = 0; j < files.length; j++) {
                            size = files[j].size / 1024;
                            filesListTablestore.insert(0, {
                                name: files[j].name,
                                size: Math.round(size * 100) / 100 + "KB"
                            });
                        }

                    }
                }
            }, {
                padding: '0,0,0,-100',
                xtype: 'displayfield',
                renderer: function () {
                    return "<span style='color: red'>请选择.csv文件</span>";
                }
            }]
        }]
    }, {
        xtype: 'gridpanel',
        border: false,
        name: "filesListTable",
        store: Ext.create("Ext.data.Store", {
            fields: ['name', 'size']
        }),
        columns: [{
            dataIndex: 'name',
            width: 300
        }, {
            dataIndex: 'size',
            flex: 1
        }]
    }]
})
;

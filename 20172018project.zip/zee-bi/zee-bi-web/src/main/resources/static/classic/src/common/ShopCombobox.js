/**
 * 店铺信息下拉框
 *
 */
Ext.define('Admin.common.ShopCombobox', {
    extend: 'Ext.form.field.ComboBox',
    alias: 'widget.shopCombobox',
    editable: false,
    displayField: 'shopName',
    valueField: 'shopId',
    store: {
        autoLoad: true,
        fields: [{
            name: 'id'
        }, {
            name: 'shopName'
        }, {
            name: 'shopId'
        }],
        proxy: {
            type: 'ajax',
            reader: {rootProperty: 'data'},
            url: 'shopBase/getAllShops'
        }
    },

    initComponent: function () {
        this.callParent();
    }

});
Ext.define('Admin.dashboard.ShopPVUVChart', {
    extend: 'Ext.chart.CartesianChart',
    alias: 'widget.shopPVUVChart',

	requires: [
        'Ext.chart.CartesianChart',
        'Ext.chart.axis.Category',
        'Ext.chart.axis.Numeric',
        'Ext.chart.series.Line',
        'Admin.common.ShopCombobox',
        'Ext.toolbar.Toolbar',
        'Ext.data.Store'
    ],
	
    cls: 'dashboard-main-chart shadow',
    height: 180,

    title: '访客数',
    tools: [{
        xtype:"container",
        items:[{
            xtype:"shopCombobox",
            margin:"-10px 0 -10px 0",
            listeners:{
                beforerender:function( cmp, eOpts ){
                    cmp.getStore().on("load",function(store, records, successful, operation, eOpts ){
                        if(!cmp.getValue()){
                            cmp.setValue(records[0]);
                        }
                    });
                },
                change:function ( cmp, newValue, oldValue, eOpts) {
                    var chart=cmp.up("shopPVUVChart");

                    var now=new Date();
                    var yDate=new Date(now.getFullYear(),now.getMonth(),now.getDate()-1);
                    var yDateStr=yDate.getFullYear()+"-"+(yDate.getMonth()+1)+"-"+yDate.getDate();
                    var wDate=new Date(now.getFullYear(),now.getMonth(),now.getDate()-14);
                    var wDateStr=wDate.getFullYear()+"-"+(wDate.getMonth()+1)+"-"+wDate.getDate();

                    Ext.apply(chart.store.proxy.extraParams,{shopId:newValue,dateStart:wDateStr,dateEnd:yDateStr});
                    chart.store.reload();

                }
            }
        }]
    }],
    store: {
        fields: [
            'uv',
            'dataDate'
        ],
        proxy: {
            type:'ajax',
            url:'shopData/shopSalesChart',
            reader: {
                type: 'json',
                rootProperty: 'data'
            }
        }
    },
    colors:["#FF9728","#B3D20F"],
    innerPadding: {
        top: 10,
        right: 20
    },
    axes: [{
        type: 'numeric',
        position: 'left'
    }, {
        type: 'category',
        position: 'bottom'

    }],
    series: [{
        type: 'line',
        xField: 'dataDate',
        yField: 'uv',
        style: {
            lineWidth: 2
        },
        marker: {
            radius: 4,
            lineWidth: 2
        },
        label: {
            field: 'uv',
            display: 'rotate'
        },
        //highlight:true,
        /*tooltip: {
            trackMouse: true,
            showDelay: 0,
            dismissDelay: 0,
            hideDelay: 0,
            renderer: function (tooltip, record, item) {
                tooltip.setHtml(record.get('uv'));
            }
        }*/
    }]
});

Ext.define('Admin.goodsDataImport.GoodsDataImportController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.goodsDataImportController',
    /**
     * 取消返回
     */
    closeBack: function () {
        var contentPanel = this.getView().up('#contentPanel');
        var oldItem = contentPanel.getLayout().getActiveItem();
        contentPanel.getLayout().setActiveItem(contentPanel.getComponent(contentPanel.items.length - 2));
        contentPanel.remove(oldItem);
    },
    /**查询
     *
     * @param button
     */
    search: function (button) {
        var grid = button.up("grid");
        Ext.apply(grid.store.proxy.extraParams, button.up("form").getValues());
        grid.store.loadPage(1);
    },
    /**
     * 全部
     * @param button
     */
    searchAll: function (button) {
        button.up("form").reset();
        this.search(button);
    },
    /**
     * 文件上传
     * @param button
     */
    uploadFile: function (button) {
        var me = this;
        var formPanel = button.up("goodsDataImportForm");
        var shopId = formPanel.down("shopCombobox[name=shopId]").getValue();
        var grid = formPanel.down("grid[name=filesListTable]");
        var items = grid.store.getData().items;
        if (!shopId) {
            Ext.Msg.alert('系统提示', "请选择店铺!");
            return;
        }
        if (!items || items.length <= 0) {
            Ext.Msg.alert('系统提示', "请添加文件!");
            return;
        }
        formPanel.mask("正在处理...");
        formPanel.getForm().submit({
            method: "Post",
            url: 'goodsData/importData',
            params: {
                shopName: formPanel.down("shopCombobox[name=shopId]").getRawValue()
            },
            success: function (form, action) {
                formPanel.unmask();
                if (action.result.success) {
                    Ext.Msg.alert('系统提示', action.result.message);
                } else {
                    Ext.Msg.alert('系统提示', action.result.message);
                }
                var goodsDataImportGrid = me.getView().up('#contentPanel').down("goodsDataImportGrid");
                me.closeBack();
                goodsDataImportGrid.store.reload();

            },
            failure: function (form, action) {
                formPanel.unmask();
                Ext.Msg.alert('操作失败', action && action.result ? action.result.message : "访问服务器失败，请联系管理员！");

            }
        });


    },
    /**
     * 数据导入
     */
    importData: function () {
        var formPanel = Ext.create("Admin.goodsDataImport.GoodsDataImportForm", {
            title: '添加',
            width: this.getView().getWidth(),
            height: this.getView().getHeight(),
            x: this.getView().getX(),
            y: this.getView().getY()
        });
        var filesListTablestore = formPanel.down('gridpanel[name=filesListTable]').store;
        filesListTablestore.removeAll();
        var contentPanel = this.getView().up('#contentPanel');
        contentPanel.getLayout().setActiveItem(contentPanel.add(formPanel));

    }


});
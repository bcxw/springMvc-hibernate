Ext.define('Admin.goodsKeyword.GoodsKeywordImportGrid', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.goodsKeywordImportGrid',
    requires: ['Admin.goodsKeyword.GoodsKeywordImportController', 'Admin.goodsKeyword.GoodsKeywordImportModel', 'Admin.common.ShopCombobox'],
    controller: 'goodsKeywordImportController',
    viewModel: 'goodsKeywordImportModel',
    scrollable: true,
    columnLines: true,
    margin: "20px",//边距 必须
    cls: 'shadow',//阴影 必须
    autoLoad: true,
    bind: {
        store: '{goodsStore}'
    },
    viewConfig: {
        enableTextSelection: true
    },
    tbar: {
        xtype: "form",
        bodyBorder: true,
        items: [{
            border: false,
            layout: "column",
            defaults: {
                labelAlign: "right",
                margin: "5 0 5 0"
            },
            items: [{
                border: false,
                width: 280,
                fieldLabel: '选择店铺',
                xtype: "shopCombobox",
                labelAlign: 'right',
                name: "shopId",
                buttonText: "浏览",
                labelWidth: 80
            }, {
                xtype: "fieldcontainer",
                fieldLabel: "日期",
                labelWidth: 100,
                name: 'planTosaleDate',
                width: 370,
                layout: "hbox",
                items: [{
                    xtype: "datefield",
                    format: "Y-m-d",
                    width: 125,
                    name: 'beginTime',
                    editable: false
                }, {
                    html: "&nbsp;-&nbsp;",
                    border: false
                }, {
                    xtype: "datefield",
                    width: 125,
                    name: 'endTime',
                    format: "Y-m-d",
                    editable: false
                }]
            }]
        }, {
            border: false,
            layout: "column",
            defaults: {
                xtype: "button",
                margin: "5 0 5 10"
            },
            items: [{
                text: '数据导入',
                handler: 'importData',
                glyph: 0xf067
            }, {
                xtype: "button",
                text: "查询",
                glyph: 0xf002,
                handler: "search"
            }, {
                xtype: "button",
                text: "全部",
                glyph: 0xf021,
                handler: "searchAll"
            }]
        }]
    },
    selModel: {
        selType: 'checkboxmodel',
        checkOnly: true,
        showHeaderCheckbox: true
    },


    bbar: {
        xtype: 'pagingtoolbar',
        displayInfo: true
    },
    columns: [
        {
            dataIndex: 'dataDate',
            text: '日期',
            width: 100,
            align: 'left',
            renderer: function (value) {
                if (value) {
                    return value.split(" ")[0];
                }
            }

        },
        {
            dataIndex: 'shopName',
            text: '店铺名称',
            width: 100,
            align: 'left'
        },
        {
            dataIndex: 'title',
            text: '商品标题',
            width: 200,
            align: 'left'
        },
        {
            dataIndex: 'url',
            text: '链接',
            width: 150,
            align: 'left'
        },
        {
            dataIndex: 'searchType',
            text: '搜索类型',
            width: 100,
            align: 'left'
        },
        {
            dataIndex: 'keyWord',
            text: '关键词',
            width: 170,
            align: 'left'
        },
        {
            dataIndex: 'directUv',
            text: '直接访客数',
            width: 110,
            align: 'left'
        },
        {
            dataIndex: 'bounceRate',
            text: '跳失率',
            width: 100,
            align: 'left',
            renderer: function (value) {
                if (value) {
                    return value + "%";
                }
            }
        },
        {
            dataIndex: 'directPayConversion',
            text: '直接转化率',
            width: 100,
            align: 'left',
            renderer: function (value) {
                if (value) {
                    return value + "%";
                }

            }
        },
        {
            dataIndex: 'directPayGoods',
            text: '直接销量',
            width: 100,
            align: 'left'
        },
        {
            dataIndex: 'directUv',
            text: '直接访客数',
            width: 100,
            align: 'left'
        },
        {
            dataIndex: 'indirectPayGoods',
            text: '间接销售量',
            width: 100,
            align: 'left'
        },
        {
            dataIndex: 'directOrderCount',
            text: '直接订单数',
            width: 120,
            align: 'left'
        }
    ]
});

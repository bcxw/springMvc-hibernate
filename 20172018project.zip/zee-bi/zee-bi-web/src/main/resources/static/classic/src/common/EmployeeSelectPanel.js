/**
 * 人员选择窗口 ｛
 *                  xtype:'employeeSelectPanel',
 *                  selectedCallback:function(employeeArr),//employeeArr:[{id:'',username:'',telephone:'',departmentId:'',departmentName:''}]
 *                  selectedEmployeeData:[{id:'',username:'',telephone:'',departmentId:'',departmentName:''}]｝
 *                  selMode:默认多选，单选"SINGLE",
 */
Ext.define('Admin.common.EmployeeSelectPanel',{
    extend: 'Ext.container.Container',
    alias: 'widget.employeeSelectPanel',

    selectedCallback:null,
    selectedEmployeeData:null,
    selMode:"",

    initComponent: function () {
        var selectedCallback=this.selectedCallback;
        var selectedEmployeeData=this.selectedEmployeeData
        var selMode=this.selMode;
        this.items=[{
            title:"人员选择",
            buttonAlign:'center',
            buttons:[{
                text:"确定",
                handler:function (button) {
                 var grid=button.up("employeeSelectPanel").down("grid[name=toGrid]");
                 var records=grid.store.getData();
                 if(records&&records.length>0){
                     var employeeArr=new Array();
                     Ext.Array.each(records.items,function(item,index,self){

                         employeeArr.push(item.data);
                     });
                     selectedCallback(employeeArr);
                 }else{
                     Ext.Msg.alert("系统提示","请选择要设置的人员！");
                 }
             }
            },{
                text:"取消",
                ui:'gray',
                handler:"closeBack"
            }],

            layout:"hbox",
            items:[{
                xtype:"treepanel",
                name:"employeeSelectSimpleTree",
                width:180,
                height:500,border:true,
                rootVisible:false,
                displayField:"name",
                store:{
                    autoLoad:true,
                    type:"tree",
                    sorters:'sortorder',
                    defaultRootProperty:"deptList",
                    root: {
                        id:"root",
                        text:'顶级菜单',
                        name:'顶级菜单',
                        expanded: true
                    },
                    fields: ['id','name'],
                    proxy: {
                        type:'ajax',
                        url:'user/getAllDepartment'
                    },
                    listeners:{
                        load:function( store, records, successful, operation, node, eOpts ){
                            if(records&&records.length>0){
                                records[0].expand();
                                Ext.ComponentQuery.query("treepanel[name=employeeSelectSimpleTree]")[0].selModel.select(records[0]);
                            }
                        }
                    }

                },
                listeners:{
                    select:function( cmp, record, index, eOpts){
                        var store=this.up("employeeSelectPanel").down("grid").store;
                        Ext.apply(store.proxy.extraParams,{departmentId:record.data.id});
                        store.loadPage(1);
                    }
                }
            },{
                xtype:'gridpanel',
                width:300,
                border:true,
                height:500,
                name:"fromGrid",
                selModel: {selType:'checkboxmodel',mode:selMode?selMode:"multi"},
                store:{
                    fields: ['id','name','telephone'],
                    proxy: {
                        type:'ajax',
                        url:'user/getUserByDepartmentId',
                        reader:{
                            type:'json',
                            rootProperty: 'data'
                        }
                    }
                },
                columns: [{
                    text: '编号',
                    width: 60,
                    dataIndex: 'id'
                },{
                    text: '姓名',
                    width: 80,
                    dataIndex: 'username'
                },{
                    text: '手机',
                    width: 120,
                    dataIndex: 'telephone'
                }],
                listeners:{
                    itemclick:function( cmp, record,item, index, eOpts ){
                        var window=cmp.up("employeeSelectPanel");
                        var toGrid=window.down("grid[name=toGrid]");
                        var tRec=toGrid.store.findRecord("id",record.data.id);
                        if(tRec==null){
                            if(window.selMode=="SINGLE"){
                                toGrid.store.removeAll();
                            }
                            var deptNode=window.down("treepanel").getSelection()[0];

                            record.set("departmentName",deptNode.data.name);
                            record.set("departmentId",deptNode.data.id);
                            tRec=toGrid.store.insert(0,record);
                        }
                        toGrid.selModel.select(tRec);
                    }
                }
            },{
                flex: 1,
                height:500,border:true,
                xtype:"gridpanel",
                name:"toGrid",
                store:{
                    fields: ['id','name','telephone'],
                    data:selectedEmployeeData
                },
                columns: [{
                    align: 'center',
                    text: '操作',
                    dataIndex: 'opt',
                    width: 50,
                    renderer:function(value,record){
                        return "<i class='fa fa-times fa-lg'></i>";
                    }
                },{
                    text: '已选人员编号',
                    width: 120,
                    dataIndex: 'id'
                },{
                    text: '已选人员姓名',
                    width: 120,
                    dataIndex: 'username',
                    flex:1
                },{
                    text: '已选人员手机',
                    width: 120,
                    dataIndex: 'telephone',
                    hidden:true
                }],
                listeners:{
                    cellclick:function( cmp, td, cellIndex, record, tr, rowIndex, e, eOpts ){
                        if(cellIndex==0){
                            cmp.store.remove(record);
                        }
                    }
                }
            }]
        }];
        this.callParent();
    }
});
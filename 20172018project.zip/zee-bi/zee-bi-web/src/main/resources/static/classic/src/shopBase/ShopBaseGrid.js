Ext.define('Admin.shopBase.ShopBaseGrid', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.shopBaseGrid',

    requires: ['Admin.shopBase.ShopBaseViewModel','Admin.shopBase.ShopBaseViewController'],

    controller: 'shopBaseViewController',
    viewModel: "shopBaseViewModel",

    margin: "20px",//边距 必须
    cls: 'shadow',//阴影 必须
    viewConfig: {
        enableTextSelection: true
    },
    autoLoad:true,
    tbar: {
        xtype: "form",
        bodyBorder: true,
        items: [{
            border: false,
            layout: "column",
            defaults: {
                xtype: "button",
                margin: "5 0 5 10"
            },
            items: [{
                text: '店铺授权',
                handler: 'showEmployeeSelectForm',
                iconCls: "x-fa fa-cogs"
            },{
                text: 'AGP设置',
                handler: 'setting',
                iconCls: "x-fa fa-cogs"
            }]
        }]
    },

    bind: {
        store: '{shopBaseStore}'
    },

    selModel: {
        selType: 'checkboxmodel',
        mode :'SINGLE'
    },

    bbar: {
        xtype: 'pagingtoolbar',
        displayInfo: true
    },
    columns: [
        {
            dataIndex: 'shopId',
            text: '店铺编号',
            width: 100
        },{
            dataIndex: 'shopName',
            text: '店铺名称',
            width: 150
        },{
            dataIndex: 'nick',
            text: '店铺别名',
            width: 100
        },{
            dataIndex: 'shopSite',
            text: '平台',
            width: 100
        },{
            dataIndex: 'userNames',
            text: '已授权人员',
            width: 300,
            flex:1
        }
    ]
});

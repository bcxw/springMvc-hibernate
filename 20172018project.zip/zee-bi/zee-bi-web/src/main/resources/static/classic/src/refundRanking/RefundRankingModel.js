Ext.define('Admin.refundRanking.RefundRankingModel',{
    extend:'Admin.main.MainModel',
    alias:'viewmodel.refundRankingModel',

    stores:{
        shopBaseStore:{
            pageSize:20,
            proxy: {
                type:'ajax',
                url:'refundGoods/list',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            listeners:{
                beforeload:"beforeload"
            }
        }
    }
});
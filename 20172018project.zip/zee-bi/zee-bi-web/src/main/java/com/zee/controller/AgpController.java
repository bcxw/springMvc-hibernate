package com.zee.controller;

/**
 * @Auther: chenxiang
 * @Date: 2018/7/16/0016 15:10
 * @Description:
 */

import com.zee.service.AgpService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;


@RestController
@RequestMapping("/agp")
public class AgpController {
    private static final Logger logger = LoggerFactory.getLogger(ShopDataController.class);
    @Autowired
    private AgpService agpService;

    /**
     * 分页查询
     *
     * @param paramMap
     * @return
     */
    @GetMapping("/list")
    public Map<String, Object> list(@RequestParam Map<String, Object> paramMap) {
        return agpService.list(paramMap);
    }

    ;

}

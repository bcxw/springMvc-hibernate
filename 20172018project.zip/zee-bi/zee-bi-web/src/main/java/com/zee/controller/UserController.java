package com.zee.controller;

import com.zee.common.ResultUtil;
import com.zee.service.UserService;
import com.zee.sso.util.UserUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * 用户接口
 */

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    /**
     * 用户登录
     * @param request
     * @param username
     * @param password
     * user:{"id": "1","username": "12154545","telephone": "18718866778","mail": 2 ,"password": "1436864169","deptId": "0","status": "0","remark": "0","operator": "0","operateTime": "0",operateIp": "0",}
     * @return
     */
    @RequestMapping("/login")
    public Map<String, Object> login(HttpServletRequest request,String username, String password) {
        Map<String, Object> result=userService.login(username,password);
        boolean success=Boolean.parseBoolean(result.get("success").toString());
        if(success){
            request.getSession().setAttribute("user",result.get("data"));
        }
        return result;

    }

    /**
     * 获取系统配置包括用户名等
     * @param request
     * @return
     */
    @RequestMapping("/getConfig")
    public Map<String, Object> getUser(HttpServletRequest request) {
        return ResultUtil.success(UserUtil.getCurrentUser());

    }

    /**
     * 退出登录
     * @param request
     * @return
     */
    @RequestMapping("/logout")
    public Map<String, Object> logout(HttpServletRequest request) {
        request.getSession().removeAttribute("user");
        return ResultUtil.success();

    }

    /**
     * 从dubbo获取有权限的菜单
     * @param request
     * user:{"id": "1","username": "12154545","telephone": "18718866778","mail": 2 ,"password": "1436864169","deptId": "0","status": "0","remark": "0","operator": "0","operateTime": "0",operateIp": "0",}
     * @return
     */
    @RequestMapping("/getMenu")
    public Map<String, Object> getMenu(HttpServletRequest request) {
        return userService.getMenu(UserUtil.getUserId().toString());
    }

    /**
     * 从dubbo获取所有树形部门
     * @return
     */
    @RequestMapping("/getAllDepartment")
    public Map<String, Object> getAllDepartment() {
        return userService.getAllDepartment();
    }

    /**
     * 从dubbo根据部门获取用户
     * @param departmentId
     * @return
     */
    @RequestMapping("/getUserByDepartmentId")
    public Map<String, Object> getUserByDepartmentId(String departmentId) {
        return userService.getUserByDepartmentId(departmentId);
    }


}

package com.zee.controller;

import com.zee.common.ResultUtil;
import com.zee.model.SysUser;
import com.zee.service.GoodsDataService;
import com.zee.sso.util.UserUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.util.Map;

/**
 * @author : chenxiang
 * @date : 2018/7/6
 */
@RestController
@RequestMapping("/goodsData")
public class GoodsDataController {
    private static final Logger logger = LoggerFactory.getLogger(ShopDataController.class);
    @Autowired
    private GoodsDataService goodsDataService;

    /**
     * 店铺数据分页查询
     *
     * @param paramMap
     * @return
     */
    @GetMapping("/list")
    public Map<String, Object> list(@RequestParam Map<String, String> paramMap) throws ParseException {
        return goodsDataService.list(paramMap);
    }

    /**
     * 导入店铺Excel文件
     *
     * @param files
     * @param paramMap
     * @param request
     * @return
     */
    @PostMapping("/importData")
    public Map<String, Object> importData(@RequestParam("file") MultipartFile files[], @RequestParam() Map<String, String> paramMap, HttpServletRequest request) {
        Map<String, Object> userMap = (Map<String, Object>) request.getSession().getAttribute("user");
        SysUser user = UserUtil.getCurrentUser();
        String userName = user.getUsername();
        Integer userId = user.getId();
        paramMap.put("userName", userName);
        paramMap.put("userId", userId.toString());
        try {
            return goodsDataService.importData(files, paramMap);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return ResultUtil.failure(e.getMessage());
        }
    }
}

package com.zee.controller;

import com.zee.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * @Auther: chenxiang
 * @Date: 2018/7/20/0020 17:04
 * @Description:
 */
@RestController
@RequestMapping("/inventory")
public class InventoryController {
    @Autowired
    private InventoryService inventoryServic;

    /**
     * 分页查询
     *
     * @param paramMap
     * @return
     */
    @GetMapping("/list")
    public Map<String, Object> list(@RequestParam Map<String, String> paramMap) {
        return inventoryServic.list(paramMap);
    }
}

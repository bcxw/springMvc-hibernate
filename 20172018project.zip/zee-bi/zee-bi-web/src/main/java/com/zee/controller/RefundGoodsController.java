package com.zee.controller;

import com.zee.service.ReturnGoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 退换货
 */
@RestController
@RequestMapping("/refundGoods")
public class RefundGoodsController {
    @Autowired
    private ReturnGoodsService returnGoodsService;

    /**
     * 退换货 排行列表
     * @param paramMap
     * @return
     */
    @GetMapping("/list")
    public Map<String, Object> list(@RequestParam Map<String, Object> paramMap) {
        return returnGoodsService.list(paramMap);
    }


}

package com.zee.controller;

import com.zee.common.ResultUtil;
import com.zee.model.SysUser;
import com.zee.service.GoodsKeywordService;
import com.zee.sso.util.UserUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.util.Map;

/**
 * @Auther: chenxiang
 * @Date: 2018/7/27/0027 09:44
 * @Description:
 */
@RestController
@RequestMapping("/goodsKeyword")
public class GoodsKeywordController {
    private static final Logger logger = LoggerFactory.getLogger(ShopDataController.class);
    @Autowired
    private GoodsKeywordService goodsKeywordService;

    /**
     * 分页查询
     *
     * @param paramMap
     * @return
     */
    @GetMapping("/list")
    public Map<String, Object> list(@RequestParam Map<String, String> paramMap) {
        try {
            return goodsKeywordService.list(paramMap);
        } catch (ParseException e) {
            logger.error(e.getMessage(), e);
            return ResultUtil.failure(e.getMessage());
        }
    }

    /**
     * 数据导入
     *
     * @param files
     * @param paramMap
     * @param request
     * @return
     */
    @PostMapping("/importData")
    public Map<String, Object> importData(@RequestParam("file") MultipartFile files[], @RequestParam() Map<String, String> paramMap, HttpServletRequest request) {
        SysUser user = UserUtil.getCurrentUser();
        paramMap.put("userName", user.getUsername());
        paramMap.put("userId", user.getId().toString());
        try {
            return goodsKeywordService.importData(files, paramMap);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return ResultUtil.failure(e.getMessage());
        }
    }
}

package com.zee.controller;

import com.zee.common.ResultUtil;
import com.zee.service.ShopBaseService;
import com.zee.sso.util.UserUtil;
import com.zee.task.JuShuiTanDataSyncTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.util.Map;

/**
 * @author : chenxiang
 * @date : 2018/6/21
 * 店铺基础接口
 */
@RestController
@RequestMapping("/shopBase")
public class ShopBaseController {
    private static final Logger logger = LoggerFactory.getLogger(JuShuiTanDataSyncTask.class);
    @Autowired
    private ShopBaseService shopBaseService;

    @GetMapping("/list")
    public Map<String, Object> list(@RequestParam Map<String, String> paramMap) {
        return shopBaseService.list(paramMap);
    }

    @GetMapping("/getAllShops")
    public Map<String, Object> getAllShops(HttpServletRequest request) {
        return shopBaseService.getAllShops(UserUtil.getUserId().toString());
    }

    /**
     * 保存授权人员
     *
     * @param peoples
     * @param shopId
     * @return
     */
    @RequestMapping("/saveEmployees")
    public Map<String, Object> saveEmployees(String shopId, String peoples) {
        return shopBaseService.saveEmployees(shopId, peoples);
    }

    /**
     * 保存AGP设置
     */
    @PostMapping("/setting")
    public Map<String, Object> saveSetting(@RequestParam Map<String, String> paramMap) {
        try {
            return shopBaseService.saveSetting(paramMap);
        } catch (ParseException e) {
            logger.error(e.getMessage(), e);
            return ResultUtil.failure(e.getMessage());
        }
    }

    /**
     * 店铺设置详情
     *
     * @param paramMap
     * @return
     */
    @GetMapping("/detail")
    public Map<String, Object> detail(@RequestParam Map<String, String> paramMap) {
        return shopBaseService.detail(paramMap);
    }


    /**
     * 根据店铺获取负责人员
     *
     * @param paramMap
     * @return
     */
    @GetMapping("/getPeoplesByShopId")
    public Map<String, Object> getPeoplesByShopId(@RequestParam Map<String, String> paramMap) {
        return shopBaseService.getPeoplesByBranId(paramMap);
    }

    /**
     * 保存店铺负责人,参与人员
     *
     * @param paramMap
     * @return
     */
    @PostMapping("/saveShopPeoples")
    public Map<String, Object> saveShopPeoples(@RequestParam Map<String, String> paramMap) {
        return shopBaseService.saveShopPeoples(paramMap);
    }
}

DROP TABLE if EXISTS  `db_shop_data`
CREATE TABLE `db_shop_data` (
`id`  varchar(32) NOT NULL ,
`create_time`  timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间' ,
`update_time`  timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间' ,
`user_name`  varchar(20) NULL COMMENT '导入人' ,
`shop_name`  varchar(50) NULL COMMENT '店铺名称' ,
`data_date`  timestamp NULL COMMENT '统计日期' ,
`UV`  int(11) NULL COMMENT '访客数' ,
`PCT`  decimal(11,2) NULL COMMENT '客单价' ,
`oldUV`  int(11) NULL COMMENT '老访客数' ,
`PV`  int(11) NULL COMMENT '浏览量' ,
`goods_collections_times`  int(11) NULL COMMENT '商品收藏次数' ,
`hopping_rate`  decimal(11,2) NULL COMMENT '跳失率' ,
`order_money`  decimal(11,2) NULL COMMENT '下单金额' ,
`order_customers`  int(11) NULL COMMENT '下单买家数' ,
`order_conversion`  decimal(11,2) NULL COMMENT '下单转化率' ,
`newUV`  int(11) NULL COMMENT '新访客数' ,
`pay_orders`  int(11) NULL COMMENT '支付父订单数' ,
`pay_money`  decimal(11,2) NULL COMMENT '支付金额' ,
`pay_customers`  int(11) NULL COMMENT '支付买家数' ,
`pay_goods`  int(11) NULL COMMENT '支付商品数' ,
`pay_conversion`  decimal(11,2) NULL COMMENT '支付转化率' ,
`pay_suborders`  int(11) NULL COMMENT '支付子订单数' ,
`goods_UV`  int(11) NULL COMMENT '商品访客数' ,
`goods_PV`  int(11) NULL COMMENT '商品浏览量' ,
`avg_stay_time`  decimal(11,2) NULL COMMENT '平均停留时长' ,
`goods_collection_customers`  int(11) NULL COMMENT '商品收藏买家数' ,
`shopping_cart_customers`  int(11) NULL COMMENT '加购人数' ,
`pay_goods`  int(11) NULL COMMENT '支付件数' ,
`avg_customers_PV`  decimal(11,2) NULL COMMENT '人均浏览量' ,
`UV_value`  varchar(255) NULL ,
`shopping_cart_goods`  int(11) NULL COMMENT '加购件数' ,
`pay_old_customers`  int(11) NULL COMMENT '支付老买家数' ,
`old_customers_pay_money`  decimal(11,2) NULL COMMENT '老买家支付金额' ,
`express_trainAmount`  decimal(11,2) NULL COMMENT '直通车消耗' ,
`exhibition_position_amount`  decimal(11,2) NULL COMMENT '钻石展位消耗' ,
`taobaoke_amount`  decimal(11,2) NULL COMMENT '淘宝客佣金' ,
`refund_amount`  decimal(11,2) NULL COMMENT '成功退款金额' ,
`comments_number`  int(11) NULL COMMENT '评价数' ,
`img_comments_number`  int(11) NULL COMMENT '有图评价数' ,
`positive_comments_number`  int(11) NULL COMMENT '正面评价数' ,
`nagative_comments_number`  int(11) NULL COMMENT '负面评价数' ,
`old_customers_positive_comments_numver`  int(11) NULL COMMENT '老买家' ,
`old_customers_nagative_comments_numver`  int(11) NULL COMMENT '老买家负面评价数' ,
`package_number`  int(11) NULL COMMENT '揽收包裹数' ,
`delivery_package_number`  int(11) NULL COMMENT '发货包裹数' ,
`send_package_number`  int(11) NULL COMMENT '派送包裹数' ,
`sign_check_package_number`  int(11) NULL COMMENT '签收成功包裹数' ,
`pay_to_sign_time`  decimal(11,2) NULL COMMENT '平均支付_签收时长' ,
`remark_score`  decimal(11,2) NULL COMMENT '描述相符评分' ,
`delivery_score`  decimal(11,2) NULL COMMENT '物流服务评分' ,
`service_score`  decimal(11,2) NULL COMMENT '服务态度评分' ,
`order_to_pay_conversion`  decimal(11,2) NULL COMMENT '下单支付转化率' ,
`shop_collection_customers`  decimal(11,2) NULL COMMENT '店铺收藏买家数' ,
PRIMARY KEY (`id`)
);
-- -------------
-- -------------
DROP TABLE if EXISTS  `db_shop_data_pv`
CREATE TABLE `db_shop_data_pc` (
`id`  varchar(32) NOT NULL ,
`create_time`  timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间' ,
`update_time`  timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间' ,
`user_name`  varchar(20) NULL COMMENT '导入人' ,
`shop_name`  varchar(50) NULL COMMENT '店铺名称' ,
`data_date`  timestamp NULL COMMENT '统计日期' ,
`pc_avg_PV`  decimal(11,2) NULL COMMENT 'PC端人均浏览量	' ,
`pc_UV`  int(11) NULL COMMENT 'PC端访客数' ,
`pc_PCT`  decimal(11,2) NULL COMMENT 'PC端客单价' ,
`pc_old_UV`  int(11) NULL COMMENT 'PC端老访客数' ,
`pc_PV`  int(11) NULL COMMENT 'PC端浏览量' ,
`pc_hopping_rate`  decimal(11,2) NULL COMMENT 'PC端跳失率' ,
`pc_order_money`  decimal(11,2) NULL COMMENT 'PC端下单金额' ,
`pc_order_customers`  int(11) NULL COMMENT 'PC端下单买家数' ,
`pc_order_conversion`  decimal(11,2) NULL COMMENT 'PC端下单转化率' ,
`pc_pay_money`  decimal(11,2) NULL COMMENT 'PC端支付金额' ,
`pc_pay_old_customers`  int(11) NULL COMMENT 'PC端支付老买家数' ,
`pc_pay_customers`  int(11) NULL COMMENT 'PC端支付买家数' ,
`pc_pay_goods`  int(11) NULL COMMENT 'PC端支付商品数' ,
`pc_pay_conversion`  decimal(11,2) NULL COMMENT 'PC端支付转化率' ,
`pc_pay_suborders`  int(11) NULL COMMENT 'PC端支付子订单数' ,
`pc_goods_UV`  int(11) NULL COMMENT 'PC端商品访客数' ,
`pc_goods_PV`  int(11) NULL COMMENT 'PC端商品浏览量' ,
`pc_avg_stay_time`  decimal(11,2) NULL COMMENT 'PC端平均停留时长' ,
`pc_goods_collection_customers`  int(11) NULL COMMENT 'PC端商品收藏买家数' ,
`pc_goods_collection_times`  int(11) NULL COMMENT 'PC端商品收藏次数' ,
`pc_shopping_cart_customers`  int(11) NULL COMMENT 'PC端加购人数' ,
`pc_UV_value`  decimal(11,2) NULL COMMENT 'PC端UV价值' ,
`pc_new_customers`  int(11) NULL COMMENT 'PC端新访客数',
`pc_shopping_cart_goods`  int(11) NULL COMMENT 'PC端加购件数' ,
`pc_order_to_pay_conversion`  decimal(11,2) NULL COMMENT 'PC端下单-支付转化率' ,
`pc_shop_collection_customers`  int(11) NULL COMMENT 'PC端店铺收藏买家数' ,
PRIMARY KEY (`id`)
)
-- -------
-- -------
DROP table if EXISTS 'db_shop_data_mp'
CREATE TABLE `db_shop_data_mp` (
`id`  varchar(32) NOT NULL ,
`create_time`  timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间' ,
`update_time`  timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间' ,
`user_name`  varchar(20) NULL COMMENT '导入人' ,
`shop_name`  varchar(50) NULL COMMENT '店铺名称' ,
`data_date`  timestamp NULL COMMENT '统计日期' ,
`mp_avg_PV`  decimal(11,2) NULL COMMENT '无线端人均浏览量	' ,
`mp_UV`  int(11) NULL COMMENT '无线端访客数' ,
`mp_PCT`  decimal(11,2) NULL COMMENT '无线端客单价' ,
`mp_old_UV`  int(11) NULL COMMENT '无线端老访客数' ,
`mp_PV`  int(11) NULL COMMENT '无线端浏览量' ,
`mp_hopping_rate`  decimal(11,2) NULL COMMENT '无线端跳失率' ,
`mp_order_money`  decimal(11,2) NULL COMMENT '无线端下单金额' ,
`mp_order_customers`  int(11) NULL COMMENT '无线端下单买家数' ,
`mp_order_conversion`  decimal(11,2) NULL COMMENT '无线端下单转化率' ,
`mp_pay_money`  decimal(11,2) NULL COMMENT '无线端支付金额' ,
`mp_pay_old_customers`  int(11) NULL COMMENT '无线端支付老买家数' ,
`mp_pay_customers`  int(11) NULL COMMENT '无线端支付买家数' ,
`mp_pay_goods`  int(11) NULL COMMENT '无线端支付商品数' ,
`mp_pay_conversion`  decimal(11,2) NULL COMMENT '无线端支付转化率' ,
`mp_pay_suborders`  int(11) NULL COMMENT '无线端支付子订单数' ,
`mp_goods_UV`  int(11) NULL COMMENT '无线端商品访客数' ,
`mp_goods_PV`  int(11) NULL COMMENT '无线端商品浏览量' ,
`mp_avg_stay_time`  decimal(11,2) NULL COMMENT '无线端平均停留时长' ,
`mp_goods_collection_customers`  int(11) NULL COMMENT '无线端商品收藏买家数' ,
`mp_goods_collection_times`  int(11) NULL COMMENT '无线端商品收藏次数' ,
`mp_shopping_cart_customers`  int(11) NULL COMMENT '无线端加购人数' ,
`mp_UV_value`  decimal(11,2) NULL COMMENT '无线端UV价值' ,
`mp_new_customers`  int(11) NULL COMMENT '无线端新访客数',
`mp_shopping_cart_goods`  int(11) NULL COMMENT '无线端加购件数' ,
`mp_order_to_pay_conversion`  decimal(11,2) NULL COMMENT '无线端下单-支付转化率' ,
`mp_shop_collection_customers`  int(11) NULL COMMENT '无线端店铺收藏买家数' ,
PRIMARY KEY (`id`)
)


--------
分表分区 商品表2017
--------
SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `db_goods_keyword_2017`;
CREATE TABLE `db_goods_keyword_2017` (
  `id` varchar(32) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `goods_id` varchar(50) DEFAULT NULL COMMENT '宝贝id',
  `title` varchar(200) DEFAULT NULL COMMENT '宝贝标题',
  `url` varchar(200) DEFAULT NULL COMMENT '宝贝链接',
  `search_type` varchar(50) DEFAULT NULL COMMENT '搜索类型',
  `key_word` varchar(50) DEFAULT NULL COMMENT '关键词',
  `direct_uv` int(11) DEFAULT NULL COMMENT '直接访客数',
  `bounce_rate` decimal(11,2) DEFAULT NULL COMMENT '跳失率',
  `direct_pay_goods` int(11) DEFAULT NULL COMMENT '直接销售量',
  `direct_pay_conversion` decimal(11,2) DEFAULT NULL COMMENT '直接转化率',
  `indirect_pay_goods` int(11) DEFAULT NULL COMMENT '间接销售量',
  `direct_order_count` int(11) DEFAULT NULL COMMENT '直接订单数',
  `user_id` varchar(50) DEFAULT NULL COMMENT '导入人id',
  `user_name` varchar(50) DEFAULT NULL COMMENT '导入人姓名',
  `shop_id` varchar(50) DEFAULT NULL COMMENT '店铺id',
  `shop_name` varchar(50) DEFAULT NULL COMMENT '店铺名称',
  `data_date` datetime NOT NULL COMMENT '数据日期',
  PRIMARY KEY (`id`,`data_date`),
  UNIQUE KEY `unkey` (`goods_id`,`key_word`,`shop_name`,`data_date`)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8
PARTITION BY RANGE(to_days(data_date)) (
PARTITION p0 VALUES LESS THAN (to_days("2017-02-01")),
PARTITION p1 VALUES LESS THAN (to_days("2017-03-01")),
PARTITION p2 VALUES LESS THAN (to_days("2017-04-01")),
PARTITION p3 VALUES LESS THAN (to_days("2017-05-01")),
PARTITION p4 VALUES LESS THAN (to_days("2017-06-01")),
PARTITION p5 VALUES LESS THAN (to_days("2017-07-01")),
PARTITION p6 VALUES LESS THAN (to_days("2017-08-01")),
PARTITION p7 VALUES LESS THAN (to_days("2017-09-01")),
PARTITION p8 VALUES LESS THAN (to_days("2017-10-01")),
PARTITION p9 VALUES LESS THAN (to_days("2017-11-01")),
PARTITION p10 VALUES LESS THAN (to_days("2017-12-01")),
PARTITION p11 VALUES LESS THAN (to_days("2018-01-01")),
PARTITION p12 VALUES LESS THAN MAXVALUE
);

------------------
分表分区 商品表2018
------------------
SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `db_goods_keyword_2018`;
CREATE TABLE `db_goods_keyword_2018` (
  `id` varchar(32) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `goods_id` varchar(50) DEFAULT NULL COMMENT '宝贝id',
  `title` varchar(200) DEFAULT NULL COMMENT '宝贝标题',
  `url` varchar(200) DEFAULT NULL COMMENT '宝贝链接',
  `search_type` varchar(50) DEFAULT NULL COMMENT '搜索类型',
  `key_word` varchar(50) DEFAULT NULL COMMENT '关键词',
  `direct_uv` int(11) DEFAULT NULL COMMENT '直接访客数',
  `bounce_rate` decimal(11,2) DEFAULT NULL COMMENT '跳失率',
  `direct_pay_goods` int(11) DEFAULT NULL COMMENT '直接销售量',
  `direct_pay_conversion` decimal(11,2) DEFAULT NULL COMMENT '直接转化率',
  `indirect_pay_goods` int(11) DEFAULT NULL COMMENT '间接销售量',
  `direct_order_count` int(11) DEFAULT NULL COMMENT '直接订单数',
  `user_id` varchar(50) DEFAULT NULL COMMENT '导入人id',
  `user_name` varchar(50) DEFAULT NULL COMMENT '导入人姓名',
  `shop_id` varchar(50) DEFAULT NULL COMMENT '店铺id',
  `shop_name` varchar(50) DEFAULT NULL COMMENT '店铺名称',
  `data_date` datetime NOT NULL COMMENT '数据日期',
  PRIMARY KEY (`id`,`data_date`),
  UNIQUE KEY `unkey` (`goods_id`,`key_word`,`shop_name`,`data_date`)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8
PARTITION BY RANGE(to_days(data_date)) (
PARTITION p0 VALUES LESS THAN (to_days("2018-02-01")),
PARTITION p1 VALUES LESS THAN (to_days("2018-03-01")),
PARTITION p2 VALUES LESS THAN (to_days("2018-04-01")),
PARTITION p3 VALUES LESS THAN (to_days("2018-05-01")),
PARTITION p4 VALUES LESS THAN (to_days("2018-06-01")),
PARTITION p5 VALUES LESS THAN (to_days("2018-07-01")),
PARTITION p6 VALUES LESS THAN (to_days("2018-08-01")),
PARTITION p7 VALUES LESS THAN (to_days("2018-09-01")),
PARTITION p8 VALUES LESS THAN (to_days("2018-10-01")),
PARTITION p9 VALUES LESS THAN (to_days("2018-11-01")),
PARTITION p10 VALUES LESS THAN (to_days("2018-12-01")),
PARTITION p11 VALUES LESS THAN (to_days("2019-01-01")),
PARTITION p12 VALUES LESS THAN MAXVALUE
);
------------------
分表分区 商品表2019
------------------
SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `db_goods_keyword_2019`;
CREATE TABLE `db_goods_keyword_2019` (
  `id` varchar(32) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `goods_id` varchar(50) DEFAULT NULL COMMENT '宝贝id',
  `title` varchar(200) DEFAULT NULL COMMENT '宝贝标题',
  `url` varchar(200) DEFAULT NULL COMMENT '宝贝链接',
  `search_type` varchar(50) DEFAULT NULL COMMENT '搜索类型',
  `key_word` varchar(50) DEFAULT NULL COMMENT '关键词',
  `direct_uv` int(11) DEFAULT NULL COMMENT '直接访客数',
  `bounce_rate` decimal(11,2) DEFAULT NULL COMMENT '跳失率',
  `direct_pay_goods` int(11) DEFAULT NULL COMMENT '直接销售量',
  `direct_pay_conversion` decimal(11,2) DEFAULT NULL COMMENT '直接转化率',
  `indirect_pay_goods` int(11) DEFAULT NULL COMMENT '间接销售量',
  `direct_order_count` int(11) DEFAULT NULL COMMENT '直接订单数',
  `user_id` varchar(50) DEFAULT NULL COMMENT '导入人id',
  `user_name` varchar(50) DEFAULT NULL COMMENT '导入人姓名',
  `shop_id` varchar(50) DEFAULT NULL COMMENT '店铺id',
  `shop_name` varchar(50) DEFAULT NULL COMMENT '店铺名称',
  `data_date` datetime NOT NULL COMMENT '数据日期',
  PRIMARY KEY (`id`,`data_date`),
  UNIQUE KEY `unkey` (`goods_id`,`key_word`,`shop_name`,`data_date`)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8
PARTITION BY RANGE(to_days(data_date)) (
PARTITION p0 VALUES LESS THAN (to_days("2019-02-01")),
PARTITION p1 VALUES LESS THAN (to_days("2019-03-01")),
PARTITION p2 VALUES LESS THAN (to_days("2019-04-01")),
PARTITION p3 VALUES LESS THAN (to_days("2019-05-01")),
PARTITION p4 VALUES LESS THAN (to_days("2019-06-01")),
PARTITION p5 VALUES LESS THAN (to_days("2019-07-01")),
PARTITION p6 VALUES LESS THAN (to_days("2019-08-01")),
PARTITION p7 VALUES LESS THAN (to_days("2019-09-01")),
PARTITION p8 VALUES LESS THAN (to_days("2019-10-01")),
PARTITION p9 VALUES LESS THAN (to_days("2019-11-01")),
PARTITION p10 VALUES LESS THAN (to_days("2019-12-01")),
PARTITION p11 VALUES LESS THAN (to_days("2020-01-01")),
PARTITION p12 VALUES LESS THAN MAXVALUE
);
------------------
分表分区 商品表2020
------------------
SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `db_goods_keyword_2020`;
CREATE TABLE `db_goods_keyword_2020` (
  `id` varchar(32) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `goods_id` varchar(50) DEFAULT NULL COMMENT '宝贝id',
  `title` varchar(200) DEFAULT NULL COMMENT '宝贝标题',
  `url` varchar(200) DEFAULT NULL COMMENT '宝贝链接',
  `search_type` varchar(50) DEFAULT NULL COMMENT '搜索类型',
  `key_word` varchar(50) DEFAULT NULL COMMENT '关键词',
  `direct_uv` int(11) DEFAULT NULL COMMENT '直接访客数',
  `bounce_rate` decimal(11,2) DEFAULT NULL COMMENT '跳失率',
  `direct_pay_goods` int(11) DEFAULT NULL COMMENT '直接销售量',
  `direct_pay_conversion` decimal(11,2) DEFAULT NULL COMMENT '直接转化率',
  `indirect_pay_goods` int(11) DEFAULT NULL COMMENT '间接销售量',
  `direct_order_count` int(11) DEFAULT NULL COMMENT '直接订单数',
  `user_id` varchar(50) DEFAULT NULL COMMENT '导入人id',
  `user_name` varchar(50) DEFAULT NULL COMMENT '导入人姓名',
  `shop_id` varchar(50) DEFAULT NULL COMMENT '店铺id',
  `shop_name` varchar(50) DEFAULT NULL COMMENT '店铺名称',
  `data_date` datetime NOT NULL COMMENT '数据日期',
  PRIMARY KEY (`id`,`data_date`),
  UNIQUE KEY `unkey` (`goods_id`,`key_word`,`shop_name`,`data_date`)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8
PARTITION BY RANGE(to_days(data_date)) (
PARTITION p0 VALUES LESS THAN (to_days("2020-02-01")),
PARTITION p1 VALUES LESS THAN (to_days("2020-03-01")),
PARTITION p2 VALUES LESS THAN (to_days("2020-04-01")),
PARTITION p3 VALUES LESS THAN (to_days("2020-05-01")),
PARTITION p4 VALUES LESS THAN (to_days("2020-06-01")),
PARTITION p5 VALUES LESS THAN (to_days("2020-07-01")),
PARTITION p6 VALUES LESS THAN (to_days("2020-08-01")),
PARTITION p7 VALUES LESS THAN (to_days("2020-09-01")),
PARTITION p8 VALUES LESS THAN (to_days("2020-10-01")),
PARTITION p9 VALUES LESS THAN (to_days("2020-11-01")),
PARTITION p10 VALUES LESS THAN (to_days("2020-12-01")),
PARTITION p11 VALUES LESS THAN (to_days("2021-01-01")),
PARTITION p12 VALUES LESS THAN MAXVALUE
);

---------
分表 商品数据无线端2017
---------
SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `db_goods_data_mp_2017`;
CREATE TABLE `db_goods_data_mp_2017` (
  `id` varchar(32) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `user_name` varchar(32) DEFAULT NULL COMMENT '导入人',
  `user_id` varchar(32) DEFAULT NULL COMMENT '导入人',
  `shop_id` varchar(32) DEFAULT NULL COMMENT '店铺',
  `shop_name` varchar(32) DEFAULT NULL COMMENT '店铺',
  `data_date` datetime DEFAULT NULL COMMENT '数据日期',
  `goods_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `mp_pv` int(11) DEFAULT NULL COMMENT '手机端浏览量',
  `mp_uv` int(11) DEFAULT NULL COMMENT '手机端访客数',
  `mp_entrance_number` int(11) DEFAULT NULL COMMENT '手机端入口数',
  `mp_bounce_rate` decimal(11,2) DEFAULT NULL COMMENT '手机端跳失率',
  `mp_exit_number` int(11) DEFAULT NULL COMMENT '手机端出口数',
  `mp_transaction_number` int(11) DEFAULT NULL COMMENT '手机端交易笔数',
  `mp_avg_stay_time` decimal(11,2) DEFAULT NULL COMMENT '手机端平均停留时长',
  `mp_pay_conversion` decimal(11,2) DEFAULT NULL COMMENT '手机端支付转化率',
  `mp_pay_money` decimal(11,2) DEFAULT NULL COMMENT '无线支付金额',
  `mp_pay_goods` int(11) DEFAULT NULL COMMENT '手机端成交宝贝数',
  `mp_search_uv` int(11) DEFAULT NULL COMMENT '手机搜索引导访客数',
  UNIQUE KEY `date_goodsId_unkey` (`data_date`,`goods_id`,`shop_name`) USING BTREE,
  KEY `query` (`goods_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品数据表无线端2017';


---------
分表 商品数据无线端2018
---------
SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `db_goods_data_mp_2018`;
CREATE TABLE `db_goods_data_mp_2018` (
  `id` varchar(32) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `user_name` varchar(32) DEFAULT NULL COMMENT '导入人',
  `user_id` varchar(32) DEFAULT NULL COMMENT '导入人',
  `shop_id` varchar(32) DEFAULT NULL COMMENT '店铺',
  `shop_name` varchar(32) DEFAULT NULL COMMENT '店铺',
  `data_date` datetime DEFAULT NULL COMMENT '数据日期',
  `goods_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `mp_pv` int(11) DEFAULT NULL COMMENT '手机端浏览量',
  `mp_uv` int(11) DEFAULT NULL COMMENT '手机端访客数',
  `mp_entrance_number` int(11) DEFAULT NULL COMMENT '手机端入口数',
  `mp_bounce_rate` decimal(11,2) DEFAULT NULL COMMENT '手机端跳失率',
  `mp_exit_number` int(11) DEFAULT NULL COMMENT '手机端出口数',
  `mp_transaction_number` int(11) DEFAULT NULL COMMENT '手机端交易笔数',
  `mp_avg_stay_time` decimal(11,2) DEFAULT NULL COMMENT '手机端平均停留时长',
  `mp_pay_conversion` decimal(11,2) DEFAULT NULL COMMENT '手机端支付转化率',
  `mp_pay_money` decimal(11,2) DEFAULT NULL COMMENT '无线支付金额',
  `mp_pay_goods` int(11) DEFAULT NULL COMMENT '手机端成交宝贝数',
  `mp_search_uv` int(11) DEFAULT NULL COMMENT '手机搜索引导访客数',
  UNIQUE KEY `date_goodsId_unkey` (`data_date`,`goods_id`,`shop_name`) USING BTREE,
  KEY `query` (`goods_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品数据表无线端2018';

---------
分表 商品数据无线端2019
---------
SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `db_goods_data_mp_2019`;
CREATE TABLE `db_goods_data_mp_2019` (
  `id` varchar(32) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `user_name` varchar(32) DEFAULT NULL COMMENT '导入人',
  `user_id` varchar(32) DEFAULT NULL COMMENT '导入人',
  `shop_id` varchar(32) DEFAULT NULL COMMENT '店铺',
  `shop_name` varchar(32) DEFAULT NULL COMMENT '店铺',
  `data_date` datetime DEFAULT NULL COMMENT '数据日期',
  `goods_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `mp_pv` int(11) DEFAULT NULL COMMENT '手机端浏览量',
  `mp_uv` int(11) DEFAULT NULL COMMENT '手机端访客数',
  `mp_entrance_number` int(11) DEFAULT NULL COMMENT '手机端入口数',
  `mp_bounce_rate` decimal(11,2) DEFAULT NULL COMMENT '手机端跳失率',
  `mp_exit_number` int(11) DEFAULT NULL COMMENT '手机端出口数',
  `mp_transaction_number` int(11) DEFAULT NULL COMMENT '手机端交易笔数',
  `mp_avg_stay_time` decimal(11,2) DEFAULT NULL COMMENT '手机端平均停留时长',
  `mp_pay_conversion` decimal(11,2) DEFAULT NULL COMMENT '手机端支付转化率',
  `mp_pay_money` decimal(11,2) DEFAULT NULL COMMENT '无线支付金额',
  `mp_pay_goods` int(11) DEFAULT NULL COMMENT '手机端成交宝贝数',
  `mp_search_uv` int(11) DEFAULT NULL COMMENT '手机搜索引导访客数',
  UNIQUE KEY `date_goodsId_unkey` (`data_date`,`goods_id`,`shop_name`) USING BTREE,
  KEY `query` (`goods_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品数据表无线端2019';


---------
分表 商品数据无线端2020
---------
SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `db_goods_data_mp_2020`;
CREATE TABLE `db_goods_data_mp_2020` (
  `id` varchar(32) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `user_name` varchar(32) DEFAULT NULL COMMENT '导入人',
  `user_id` varchar(32) DEFAULT NULL COMMENT '导入人',
  `shop_id` varchar(32) DEFAULT NULL COMMENT '店铺',
  `shop_name` varchar(32) DEFAULT NULL COMMENT '店铺',
  `data_date` datetime DEFAULT NULL COMMENT '数据日期',
  `goods_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `mp_pv` int(11) DEFAULT NULL COMMENT '手机端浏览量',
  `mp_uv` int(11) DEFAULT NULL COMMENT '手机端访客数',
  `mp_entrance_number` int(11) DEFAULT NULL COMMENT '手机端入口数',
  `mp_bounce_rate` decimal(11,2) DEFAULT NULL COMMENT '手机端跳失率',
  `mp_exit_number` int(11) DEFAULT NULL COMMENT '手机端出口数',
  `mp_transaction_number` int(11) DEFAULT NULL COMMENT '手机端交易笔数',
  `mp_avg_stay_time` decimal(11,2) DEFAULT NULL COMMENT '手机端平均停留时长',
  `mp_pay_conversion` decimal(11,2) DEFAULT NULL COMMENT '手机端支付转化率',
  `mp_pay_money` decimal(11,2) DEFAULT NULL COMMENT '无线支付金额',
  `mp_pay_goods` int(11) DEFAULT NULL COMMENT '手机端成交宝贝数',
  `mp_search_uv` int(11) DEFAULT NULL COMMENT '手机搜索引导访客数',
  UNIQUE KEY `date_goodsId_unkey` (`data_date`,`goods_id`,`shop_name`) USING BTREE,
  KEY `query` (`goods_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品数据表无线端2020';

--------------------
分表 商品信息pc端2017
--------------------

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `db_goods_data_pc_2017`;
CREATE TABLE `db_goods_data_pc_2017` (
  `id` varchar(32) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `user_name` varchar(20) DEFAULT NULL COMMENT '导入人',
  `user_id` varchar(32) DEFAULT NULL COMMENT '导入人',
  `shop_id` varchar(32) DEFAULT NULL COMMENT '店铺',
  `shop_name` varchar(32) DEFAULT NULL COMMENT '店铺',
  `data_date` datetime DEFAULT NULL COMMENT '数据日期',
  `goods_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `pc_type_uv` int(11) DEFAULT NULL COMMENT 'pc端类目uv',
  `pc_collection_uv` int(11) DEFAULT NULL COMMENT 'pc端收藏uv',
  `pc_ztc_uv` int(11) DEFAULT NULL COMMENT 'pc端直通车uv',
  `pc_tbk_uv` int(11) DEFAULT NULL COMMENT 'pc端淘宝客uv',
  `pc_pv` int(11) DEFAULT NULL COMMENT 'pc浏览量',
  `pc_uv` int(11) DEFAULT NULL COMMENT 'pc访客数',
  `pc_entrance_number` int(11) DEFAULT NULL COMMENT 'pc入口数',
  `pc_exit_number` int(11) DEFAULT NULL COMMENT 'pc出口数',
  `pc_bounce_rate` decimal(11,2) DEFAULT NULL COMMENT 'pc跳失率',
  `pc_transaction_number` int(11) DEFAULT NULL COMMENT 'pc交易笔数',
  `pc_avg_stay_time` decimal(11,2) DEFAULT NULL COMMENT 'pc平均停留时长',
  `pc_pay_conversion` decimal(11,2) DEFAULT NULL COMMENT 'pc支付转化率',
  `pc_pay_money` decimal(11,2) DEFAULT NULL COMMENT 'pc支付金额',
  `pc_pay_goods` int(11) DEFAULT NULL COMMENT 'pc支付商品件数',
  `pc_search_uv` int(11) DEFAULT NULL COMMENT '搜索UV（PC）',
  UNIQUE KEY `date_goodsId_unkey` (`data_date`,`goods_id`,`shop_name`) USING BTREE,
  KEY `query` (`goods_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品数据表pc2017';


--------------------
分表 商品信息pc端2018
--------------------

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `db_goods_data_pc_2018`;
CREATE TABLE `db_goods_data_pc_2018` (
  `id` varchar(32) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `user_name` varchar(20) DEFAULT NULL COMMENT '导入人',
  `user_id` varchar(32) DEFAULT NULL COMMENT '导入人',
  `shop_id` varchar(32) DEFAULT NULL COMMENT '店铺',
  `shop_name` varchar(32) DEFAULT NULL COMMENT '店铺',
  `data_date` datetime DEFAULT NULL COMMENT '数据日期',
  `goods_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `pc_type_uv` int(11) DEFAULT NULL COMMENT 'pc端类目uv',
  `pc_collection_uv` int(11) DEFAULT NULL COMMENT 'pc端收藏uv',
  `pc_ztc_uv` int(11) DEFAULT NULL COMMENT 'pc端直通车uv',
  `pc_tbk_uv` int(11) DEFAULT NULL COMMENT 'pc端淘宝客uv',
  `pc_pv` int(11) DEFAULT NULL COMMENT 'pc浏览量',
  `pc_uv` int(11) DEFAULT NULL COMMENT 'pc访客数',
  `pc_entrance_number` int(11) DEFAULT NULL COMMENT 'pc入口数',
  `pc_exit_number` int(11) DEFAULT NULL COMMENT 'pc出口数',
  `pc_bounce_rate` decimal(11,2) DEFAULT NULL COMMENT 'pc跳失率',
  `pc_transaction_number` int(11) DEFAULT NULL COMMENT 'pc交易笔数',
  `pc_avg_stay_time` decimal(11,2) DEFAULT NULL COMMENT 'pc平均停留时长',
  `pc_pay_conversion` decimal(11,2) DEFAULT NULL COMMENT 'pc支付转化率',
  `pc_pay_money` decimal(11,2) DEFAULT NULL COMMENT 'pc支付金额',
  `pc_pay_goods` int(11) DEFAULT NULL COMMENT 'pc支付商品件数',
  `pc_search_uv` int(11) DEFAULT NULL COMMENT '搜索UV（PC）',
  UNIQUE KEY `date_goodsId_unkey` (`data_date`,`goods_id`,`shop_name`) USING BTREE,
  KEY `query` (`goods_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品数据表pc2018';




--------------------
分表 商品信息pc端2019
--------------------

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `db_goods_data_pc_2019`;
CREATE TABLE `db_goods_data_pc_2019` (
  `id` varchar(32) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `user_name` varchar(20) DEFAULT NULL COMMENT '导入人',
  `user_id` varchar(32) DEFAULT NULL COMMENT '导入人',
  `shop_id` varchar(32) DEFAULT NULL COMMENT '店铺',
  `shop_name` varchar(32) DEFAULT NULL COMMENT '店铺',
  `data_date` datetime DEFAULT NULL COMMENT '数据日期',
  `goods_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `pc_type_uv` int(11) DEFAULT NULL COMMENT 'pc端类目uv',
  `pc_collection_uv` int(11) DEFAULT NULL COMMENT 'pc端收藏uv',
  `pc_ztc_uv` int(11) DEFAULT NULL COMMENT 'pc端直通车uv',
  `pc_tbk_uv` int(11) DEFAULT NULL COMMENT 'pc端淘宝客uv',
  `pc_pv` int(11) DEFAULT NULL COMMENT 'pc浏览量',
  `pc_uv` int(11) DEFAULT NULL COMMENT 'pc访客数',
  `pc_entrance_number` int(11) DEFAULT NULL COMMENT 'pc入口数',
  `pc_exit_number` int(11) DEFAULT NULL COMMENT 'pc出口数',
  `pc_bounce_rate` decimal(11,2) DEFAULT NULL COMMENT 'pc跳失率',
  `pc_transaction_number` int(11) DEFAULT NULL COMMENT 'pc交易笔数',
  `pc_avg_stay_time` decimal(11,2) DEFAULT NULL COMMENT 'pc平均停留时长',
  `pc_pay_conversion` decimal(11,2) DEFAULT NULL COMMENT 'pc支付转化率',
  `pc_pay_money` decimal(11,2) DEFAULT NULL COMMENT 'pc支付金额',
  `pc_pay_goods` int(11) DEFAULT NULL COMMENT 'pc支付商品件数',
  `pc_search_uv` int(11) DEFAULT NULL COMMENT '搜索UV（PC）',
  UNIQUE KEY `date_goodsId_unkey` (`data_date`,`goods_id`,`shop_name`) USING BTREE,
  KEY `query` (`goods_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品数据表pc2019';



--------------------
分表 商品信息pc端2020
--------------------

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `db_goods_data_pc_2020`;
CREATE TABLE `db_goods_data_pc_2020` (
  `id` varchar(32) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `user_name` varchar(20) DEFAULT NULL COMMENT '导入人',
  `user_id` varchar(32) DEFAULT NULL COMMENT '导入人',
  `shop_id` varchar(32) DEFAULT NULL COMMENT '店铺',
  `shop_name` varchar(32) DEFAULT NULL COMMENT '店铺',
  `data_date` datetime DEFAULT NULL COMMENT '数据日期',
  `goods_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `pc_type_uv` int(11) DEFAULT NULL COMMENT 'pc端类目uv',
  `pc_collection_uv` int(11) DEFAULT NULL COMMENT 'pc端收藏uv',
  `pc_ztc_uv` int(11) DEFAULT NULL COMMENT 'pc端直通车uv',
  `pc_tbk_uv` int(11) DEFAULT NULL COMMENT 'pc端淘宝客uv',
  `pc_pv` int(11) DEFAULT NULL COMMENT 'pc浏览量',
  `pc_uv` int(11) DEFAULT NULL COMMENT 'pc访客数',
  `pc_entrance_number` int(11) DEFAULT NULL COMMENT 'pc入口数',
  `pc_exit_number` int(11) DEFAULT NULL COMMENT 'pc出口数',
  `pc_bounce_rate` decimal(11,2) DEFAULT NULL COMMENT 'pc跳失率',
  `pc_transaction_number` int(11) DEFAULT NULL COMMENT 'pc交易笔数',
  `pc_avg_stay_time` decimal(11,2) DEFAULT NULL COMMENT 'pc平均停留时长',
  `pc_pay_conversion` decimal(11,2) DEFAULT NULL COMMENT 'pc支付转化率',
  `pc_pay_money` decimal(11,2) DEFAULT NULL COMMENT 'pc支付金额',
  `pc_pay_goods` int(11) DEFAULT NULL COMMENT 'pc支付商品件数',
  `pc_search_uv` int(11) DEFAULT NULL COMMENT '搜索UV（PC）',
  UNIQUE KEY `date_goodsId_unkey` (`data_date`,`goods_id`,`shop_name`) USING BTREE,
  KEY `query` (`goods_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品数据表pc2020';


----------------
分表 商品信息2017
----------------

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for db_goods_data_2017
-- ----------------------------
DROP TABLE IF EXISTS `db_goods_data_2017`;
CREATE TABLE `db_goods_data_2017` (
  `id` varchar(32) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `user_name` varchar(32) DEFAULT NULL COMMENT '导入人',
  `user_id` varchar(32) DEFAULT NULL COMMENT '导入人',
  `shop_id` varchar(32) DEFAULT NULL COMMENT '店铺',
  `merchant_code` varchar(50) DEFAULT NULL COMMENT '商家编码',
  `shop_name` varchar(32) DEFAULT NULL COMMENT '店铺',
  `data_date` datetime NOT NULL COMMENT '数据日期',
  `goods_id` varchar(32) DEFAULT NULL COMMENT '宝贝id',
  `industry_type` varchar(50) DEFAULT NULL COMMENT '行业类目',
  `title` varchar(200) DEFAULT NULL COMMENT '商品标题',
  `url` varchar(500) DEFAULT NULL COMMENT '商品链接',
  `pv` int(11) DEFAULT NULL COMMENT '浏览量',
  `uv` int(11) DEFAULT NULL COMMENT '访客数',
  `transaction_number` int(11) DEFAULT NULL COMMENT '交易笔数',
  `entrance_number` int(11) DEFAULT NULL COMMENT '入口数',
  `exit_number` int(11) DEFAULT NULL COMMENT '出口数',
  `bounce_rate` decimal(11,2) DEFAULT NULL COMMENT '跳失率',
  `avg_stay_time` decimal(11,2) DEFAULT NULL COMMENT '平均停留时长',
  `collection_number` int(11) DEFAULT NULL COMMENT '收藏数',
  `pay_money` decimal(11,2) DEFAULT NULL COMMENT '销售额',
  `pay_conversion` decimal(11,2) DEFAULT NULL COMMENT '支付转化率',
  `pay_goods` int(11) DEFAULT NULL COMMENT '支付商品件数',
  `shopping_cart_customer_number` int(11) DEFAULT NULL COMMENT '新增购物车人数',
  `shopping_cart_goods_number` int(11) DEFAULT NULL COMMENT '新增购物车宝贝件数',
  `search_uv` int(11) DEFAULT NULL COMMENT '搜索引导访客数',
  `refund_money` decimal(11,2) DEFAULT NULL COMMENT '售中售后成功退款金额',
  `refund_count` int(11) DEFAULT NULL COMMENT '售中售后成功退款笔数',
  `refund_rate` decimal(11,2) DEFAULT NULL COMMENT '退款率',
  `old_uv` int(11) DEFAULT NULL COMMENT '老访客数',
  `old_pay_money` decimal(11,2) DEFAULT NULL COMMENT '老客销售额',
  `old_pay_goods` int(11) DEFAULT NULL COMMENT '成交宝贝数(老客)',
  `old_transaction_number` int(11) DEFAULT NULL COMMENT '老客成交笔数',
  `old_pay_conversion` decimal(11,2) DEFAULT NULL COMMENT '老客销售额',
  PRIMARY KEY (`id`,`data_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品数据主表2017';


----------------
分表 商品信息2018
----------------

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `db_goods_data_2018`;
CREATE TABLE `db_goods_data_2018` (
  `id` varchar(32) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `user_name` varchar(32) DEFAULT NULL COMMENT '导入人',
  `user_id` varchar(32) DEFAULT NULL COMMENT '导入人',
  `shop_id` varchar(32) DEFAULT NULL COMMENT '店铺',
  `merchant_code` varchar(50) DEFAULT NULL COMMENT '商家编码',
  `shop_name` varchar(32) DEFAULT NULL COMMENT '店铺',
  `data_date` datetime NOT NULL COMMENT '数据日期',
  `goods_id` varchar(32) DEFAULT NULL COMMENT '宝贝id',
  `industry_type` varchar(50) DEFAULT NULL COMMENT '行业类目',
  `title` varchar(200) DEFAULT NULL COMMENT '商品标题',
  `url` varchar(500) DEFAULT NULL COMMENT '商品链接',
  `pv` int(11) DEFAULT NULL COMMENT '浏览量',
  `uv` int(11) DEFAULT NULL COMMENT '访客数',
  `transaction_number` int(11) DEFAULT NULL COMMENT '交易笔数',
  `entrance_number` int(11) DEFAULT NULL COMMENT '入口数',
  `exit_number` int(11) DEFAULT NULL COMMENT '出口数',
  `bounce_rate` decimal(11,2) DEFAULT NULL COMMENT '跳失率',
  `avg_stay_time` decimal(11,2) DEFAULT NULL COMMENT '平均停留时长',
  `collection_number` int(11) DEFAULT NULL COMMENT '收藏数',
  `pay_money` decimal(11,2) DEFAULT NULL COMMENT '销售额',
  `pay_conversion` decimal(11,2) DEFAULT NULL COMMENT '支付转化率',
  `pay_goods` int(11) DEFAULT NULL COMMENT '支付商品件数',
  `shopping_cart_customer_number` int(11) DEFAULT NULL COMMENT '新增购物车人数',
  `shopping_cart_goods_number` int(11) DEFAULT NULL COMMENT '新增购物车宝贝件数',
  `search_uv` int(11) DEFAULT NULL COMMENT '搜索引导访客数',
  `refund_money` decimal(11,2) DEFAULT NULL COMMENT '售中售后成功退款金额',
  `refund_count` int(11) DEFAULT NULL COMMENT '售中售后成功退款笔数',
  `refund_rate` decimal(11,2) DEFAULT NULL COMMENT '退款率',
  `old_uv` int(11) DEFAULT NULL COMMENT '老访客数',
  `old_pay_money` decimal(11,2) DEFAULT NULL COMMENT '老客销售额',
  `old_pay_goods` int(11) DEFAULT NULL COMMENT '成交宝贝数(老客)',
  `old_transaction_number` int(11) DEFAULT NULL COMMENT '老客成交笔数',
  `old_pay_conversion` decimal(11,2) DEFAULT NULL COMMENT '老客销售额',
  PRIMARY KEY (`id`,`data_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品数据主表2018';



----------------
分表 商品信息2019
----------------

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `db_goods_data_2019`;
CREATE TABLE `db_goods_data_2019` (
  `id` varchar(32) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `user_name` varchar(32) DEFAULT NULL COMMENT '导入人',
  `user_id` varchar(32) DEFAULT NULL COMMENT '导入人',
  `shop_id` varchar(32) DEFAULT NULL COMMENT '店铺',
  `merchant_code` varchar(50) DEFAULT NULL COMMENT '商家编码',
  `shop_name` varchar(32) DEFAULT NULL COMMENT '店铺',
  `data_date` datetime NOT NULL COMMENT '数据日期',
  `goods_id` varchar(32) DEFAULT NULL COMMENT '宝贝id',
  `industry_type` varchar(50) DEFAULT NULL COMMENT '行业类目',
  `title` varchar(200) DEFAULT NULL COMMENT '商品标题',
  `url` varchar(500) DEFAULT NULL COMMENT '商品链接',
  `pv` int(11) DEFAULT NULL COMMENT '浏览量',
  `uv` int(11) DEFAULT NULL COMMENT '访客数',
  `transaction_number` int(11) DEFAULT NULL COMMENT '交易笔数',
  `entrance_number` int(11) DEFAULT NULL COMMENT '入口数',
  `exit_number` int(11) DEFAULT NULL COMMENT '出口数',
  `bounce_rate` decimal(11,2) DEFAULT NULL COMMENT '跳失率',
  `avg_stay_time` decimal(11,2) DEFAULT NULL COMMENT '平均停留时长',
  `collection_number` int(11) DEFAULT NULL COMMENT '收藏数',
  `pay_money` decimal(11,2) DEFAULT NULL COMMENT '销售额',
  `pay_conversion` decimal(11,2) DEFAULT NULL COMMENT '支付转化率',
  `pay_goods` int(11) DEFAULT NULL COMMENT '支付商品件数',
  `shopping_cart_customer_number` int(11) DEFAULT NULL COMMENT '新增购物车人数',
  `shopping_cart_goods_number` int(11) DEFAULT NULL COMMENT '新增购物车宝贝件数',
  `search_uv` int(11) DEFAULT NULL COMMENT '搜索引导访客数',
  `refund_money` decimal(11,2) DEFAULT NULL COMMENT '售中售后成功退款金额',
  `refund_count` int(11) DEFAULT NULL COMMENT '售中售后成功退款笔数',
  `refund_rate` decimal(11,2) DEFAULT NULL COMMENT '退款率',
  `old_uv` int(11) DEFAULT NULL COMMENT '老访客数',
  `old_pay_money` decimal(11,2) DEFAULT NULL COMMENT '老客销售额',
  `old_pay_goods` int(11) DEFAULT NULL COMMENT '成交宝贝数(老客)',
  `old_transaction_number` int(11) DEFAULT NULL COMMENT '老客成交笔数',
  `old_pay_conversion` decimal(11,2) DEFAULT NULL COMMENT '老客销售额',
  PRIMARY KEY (`id`,`data_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品数据主表2019';



----------------
分表 商品信息2020
----------------

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `db_goods_data_2020`;
CREATE TABLE `db_goods_data_2020` (
  `id` varchar(32) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `user_name` varchar(32) DEFAULT NULL COMMENT '导入人',
  `user_id` varchar(32) DEFAULT NULL COMMENT '导入人',
  `shop_id` varchar(32) DEFAULT NULL COMMENT '店铺',
  `merchant_code` varchar(50) DEFAULT NULL COMMENT '商家编码',
  `shop_name` varchar(32) DEFAULT NULL COMMENT '店铺',
  `data_date` datetime NOT NULL COMMENT '数据日期',
  `goods_id` varchar(32) DEFAULT NULL COMMENT '宝贝id',
  `industry_type` varchar(50) DEFAULT NULL COMMENT '行业类目',
  `title` varchar(200) DEFAULT NULL COMMENT '商品标题',
  `url` varchar(500) DEFAULT NULL COMMENT '商品链接',
  `pv` int(11) DEFAULT NULL COMMENT '浏览量',
  `uv` int(11) DEFAULT NULL COMMENT '访客数',
  `transaction_number` int(11) DEFAULT NULL COMMENT '交易笔数',
  `entrance_number` int(11) DEFAULT NULL COMMENT '入口数',
  `exit_number` int(11) DEFAULT NULL COMMENT '出口数',
  `bounce_rate` decimal(11,2) DEFAULT NULL COMMENT '跳失率',
  `avg_stay_time` decimal(11,2) DEFAULT NULL COMMENT '平均停留时长',
  `collection_number` int(11) DEFAULT NULL COMMENT '收藏数',
  `pay_money` decimal(11,2) DEFAULT NULL COMMENT '销售额',
  `pay_conversion` decimal(11,2) DEFAULT NULL COMMENT '支付转化率',
  `pay_goods` int(11) DEFAULT NULL COMMENT '支付商品件数',
  `shopping_cart_customer_number` int(11) DEFAULT NULL COMMENT '新增购物车人数',
  `shopping_cart_goods_number` int(11) DEFAULT NULL COMMENT '新增购物车宝贝件数',
  `search_uv` int(11) DEFAULT NULL COMMENT '搜索引导访客数',
  `refund_money` decimal(11,2) DEFAULT NULL COMMENT '售中售后成功退款金额',
  `refund_count` int(11) DEFAULT NULL COMMENT '售中售后成功退款笔数',
  `refund_rate` decimal(11,2) DEFAULT NULL COMMENT '退款率',
  `old_uv` int(11) DEFAULT NULL COMMENT '老访客数',
  `old_pay_money` decimal(11,2) DEFAULT NULL COMMENT '老客销售额',
  `old_pay_goods` int(11) DEFAULT NULL COMMENT '成交宝贝数(老客)',
  `old_transaction_number` int(11) DEFAULT NULL COMMENT '老客成交笔数',
  `old_pay_conversion` decimal(11,2) DEFAULT NULL COMMENT '老客销售额',
  PRIMARY KEY (`id`,`data_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品数据主表2020';
package com.zee.sharding;

import io.shardingsphere.core.api.algorithm.sharding.PreciseShardingValue;
import io.shardingsphere.core.api.algorithm.sharding.RangeShardingValue;
import io.shardingsphere.core.api.algorithm.sharding.standard.PreciseShardingAlgorithm;
import io.shardingsphere.core.api.algorithm.sharding.standard.RangeShardingAlgorithm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

/**
 * 根据日期格式datetime按照年份分表
 */

public class ShardingAlgorithmYear implements PreciseShardingAlgorithm,RangeShardingAlgorithm {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    public ShardingAlgorithmYear(){

    }

    @Override
    public String doSharding(Collection collection, PreciseShardingValue preciseShardingValue) {
        String tableNode=null;
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Calendar calendar=Calendar.getInstance();
            String dateStr=preciseShardingValue.getValue().toString();
            Date date=format.parse(dateStr);
            calendar.setTime(date);
            String year=calendar.get(Calendar.YEAR)+"";
            for(Object obj:collection){
                String oneNode=obj+"";
                if(oneNode.endsWith(year)){
                    tableNode=oneNode;
                    break;
                }
            }
        } catch (ParseException e) {
            logger.error(e.getMessage(),e);
        }
        return tableNode;
    }

    @Override
    public Collection<String> doSharding(Collection collection, RangeShardingValue rangeShardingValue) {
        Collection<String> collect = new ArrayList<String>();

        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Calendar calendar=Calendar.getInstance();
            String dateUpperStr=rangeShardingValue.getValueRange().upperEndpoint().toString();
            String dateLowerStr=rangeShardingValue.getValueRange().lowerEndpoint().toString();
            Date dateUpper=format.parse(dateUpperStr);
            Date dateLower=format.parse(dateLowerStr);
            calendar.setTime(dateUpper);
            int yearUpper=calendar.get(Calendar.YEAR);
            calendar.setTime(dateLower);
            int yearLower=calendar.get(Calendar.YEAR);

            for(Object obj:collection){
                String tableNoe=obj+"";
                for(int i=yearLower;i<=yearUpper;i++){
                    if(tableNoe.endsWith(i+"")){
                        collect.add(tableNoe);
                        break;
                    }
                }
            }
        } catch (ParseException e)  {
            logger.error(e.getMessage(),e);
        }
        return collect;
    }
}

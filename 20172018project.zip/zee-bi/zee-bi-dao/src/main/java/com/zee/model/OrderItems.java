package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

/**
 * @author : chenxiang
 * @date : 2018/6/25
 */
@Setter
@Getter
@TableName("db_order_items")
public class OrderItems extends BaseModel<OrderItems> {
    /**
     * ERP内部订单
     */
    private  long oId;
    /**
     * 商品编码
     */
    private String skuId;
    /**
     * 数量
     */
    private int  qty;
    /**
     * 基础价格
     */
    private float basePrice;
    /**
     * 价格
     */
    private float price;
    /**
     * 总金额
     */
    private float amount;
    /**
     * 商品名称
     */
    private String name;
    /**
     * 店铺商品编码
     */
    private String shopSkuId;
    /**
     * 颜色规格
     */
    private String propertiesValue;

}

package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.TestModel;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Date;
import java.util.List;

/**
 * @author : chenxiang
 * @date : 2018/6/29
 */
@Mapper
public interface TestDao extends BaseMapper<TestModel> {

    @Insert("<script>insert into test(id,shop_id,datadate)  " +
            "values " +
            "<foreach collection=\"list\" separator=\",\" item=\"i\">\n" +
            " (#{i.id},#{i.shopId},#{i.datadate}" +
            " )" +
            "</foreach>" +
            "</script>")
    void batchInsert(List<TestModel> testModelList);

    @Select("<script>select * from test where datadate &gt;=DATE_FORMAT(#{dateStart},'%Y-%m-%d 00:00:00') and datadate &lt;=DATE_FORMAT(#{dateEnd},'%Y-%m-%d 23:59:59')</script>")
    List<TestModel> getAll(@Param("dateStart")Date dateStart,@Param("dateEnd")Date dateEnd);

}

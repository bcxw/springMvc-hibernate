package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.ReturnGoods;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author : chenxiang
 * @date : 2018/6/25
 * 退款退货dao
 */
@Mapper
public interface ReturnGoodsDao extends BaseMapper<ReturnGoods> {
    /**
     * 批量插入/更新
     *
     * @param result
     */
    @Insert("<script>" +
            "insert into db_returngoods (id,as_id,as_date,outer_as_id,o_id,so_id,type,modified,status,good_status,question_type,warehouse,refund,payment,shop_buyer_id,shop_id,shop_name,receiver_name,logistics_company,l_id)" +
            "values" +
            "<foreach collection=\"list\" item=\"item\" index=\"index\" separator=\",\">" +
            "(#{item.id},#{item.asId},#{item.asDate},#{item.outerAsId},#{item.oId},#{item.soId},#{item.type},#{item.modified},#{item.status},#{item.goodStatus},#{item.questionType},#{item.warehouse},#{item.refund},#{item.payment},#{item.shopBuyerId},#{item.shopId},#{item.shopName},#{item.receiverName},#{item.logisticsCompany},#{item.lId})" +
            "</foreach>" +
            "  ON DUPLICATE KEY UPDATE " +
            " as_id=values(as_id),as_date=values(as_date),outer_as_id=values(outer_as_id),o_id=values(o_id),so_id=values(so_id),type=values(type),modified=values(modified),status=values(status),good_status=values(good_status),question_type=values(question_type),warehouse=values(warehouse),refund=values(refund),payment=values(payment),shop_buyer_id=values(shop_buyer_id),shop_id=values(shop_id),shop_name=values(shop_name),receiver_name=values(receiver_name),logistics_company=values(logistics_company),l_id=values(l_id)" +
            "</script>")
    void batchInsert(List<ReturnGoods> result);
}

package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.Basedata;
import org.apache.ibatis.annotations.Mapper;

/**
 * 基础数据dao
 */

@Mapper
public interface BasedataDao extends BaseMapper<Basedata> {

}

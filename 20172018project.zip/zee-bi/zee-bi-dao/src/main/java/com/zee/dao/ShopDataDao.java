package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.ShopData;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author : chenxiang
 * @date : 2018/6/29
 */
@Mapper
public interface ShopDataDao extends BaseMapper<ShopData> {

    /**
     * 批量插入/更新
     * @param shopDataList
     */
    @Insert("<script>" +
            "insert into db_shop_data (id,user_name,shop_name,shop_id,data_date,uv,pct,old_uv,pv,uv_depth,new_uv,pay_money,pay_customers,pay_goods,pay_conversion," +
            " page_avg_stay_time,avg_stay_time,new_avg_stay_time,old_avg_stay_time,ww_consult_number,inquiry_transaction_conversion,silent_conversion_rate," +
            " goods_collection_customers,refund_amount,refund_count,refund_money_rate,refund_goods_rate,add_shopping_cart_customer," +
            " add_shopping_cart_goods,shop_collection_customers,order_count,old_pay_goods,old_pay_money,old_pay_customers,dsr_describe_score,dsr_describe_number,dsr_server_score," +
            " dsr_server_number,dsr_shipments_score,dsr_shipments_number,dsr_logistics_score,dsr_logistics_number)" +
            "values " +
            " <foreach collection=\"list\" item=\"i\" index=\"index\" separator=\",\" >" +
            " (#{i.id},#{i.userName},#{i.shopName},#{i.shopId},#{i.dataDate},#{i.uv},#{i.pct},#{i.oldUv},#{i.pv},#{i.uvDepth},#{i.newUv},#{i.payMoney},#{i.payCustomers},#{i.payGoods},#{i.payConversion}," +
            " #{i.pageAvgStayTime},#{i.avgStayTime},#{i.newAvgStayTime},#{i.oldAvgStayTime},#{i.wwConsultNumber},#{i.inquiryTransactionConversion},#{i.silentConversionRate}," +
            " #{i.goodsCollectionCustomers},#{i.refundAmount},#{i.refundCount},#{i.refundMoneyRate},#{i.refundGoodsRate},#{i.addShoppingCartCustomer}," +
            " #{i.addShoppingCartGoods},#{i.shopCollectionCustomers},#{i.orderCount},#{i.oldPayGoods},#{i.oldPayMoney},#{i.oldPayCustomers},#{i.dsrDescribeScore},#{i.dsrDescribeNumber},#{i.dsrServerScore}," +
            " #{i.dsrServerNumber},#{i.dsrShipmentsScore},#{i.dsrShipmentsNumber},#{i.dsrLogisticsScore},#{i.dsrLogisticsNumber})" +

            "    </foreach>" +
            "  ON DUPLICATE KEY UPDATE " +
            " user_name=values(user_name),shop_name=values(shop_name),shop_id=values(shop_id),data_date=values(data_date),uv=values(uv),pct=values(pct),old_uv=values(old_uv),pv=values(pv),uv_depth=values(uv_depth),new_uv=values(new_uv),pay_money=values(pay_money),pay_customers=values(pay_customers),new_uv=values(new_uv),pay_money=values(pay_money),pay_goods=values(pay_goods),pay_conversion=values(pay_conversion)," +
            " page_avg_stay_time=values(page_avg_stay_time),avg_stay_time=values(avg_stay_time),new_avg_stay_time=values(new_avg_stay_time),old_avg_stay_time=values(old_avg_stay_time),ww_consult_number=values(ww_consult_number),inquiry_transaction_conversion=values(inquiry_transaction_conversion),silent_conversion_rate=values(silent_conversion_rate)," +
            " goods_collection_customers=values(goods_collection_customers),refund_amount=values(refund_amount),refund_count=values(refund_count),refund_money_rate=values(refund_money_rate),refund_goods_rate=values(refund_goods_rate),add_shopping_cart_customer=values(add_shopping_cart_customer)," +
            " add_shopping_cart_goods=values(add_shopping_cart_goods),shop_collection_customers=values(shop_collection_customers),order_count=values(order_count),old_pay_goods=values(old_pay_goods),old_pay_money=values(old_pay_money),old_pay_customers=values(old_pay_customers),dsr_describe_score=values(dsr_describe_score),dsr_describe_number=values(dsr_describe_number),dsr_server_score=values(dsr_server_score),"+
            " dsr_server_number=values(dsr_server_number),dsr_shipments_score=values(dsr_shipments_score),dsr_shipments_number=values(dsr_shipments_number),dsr_logistics_score=values(dsr_logistics_score),dsr_logistics_number=values(dsr_logistics_number)" +
            "</script>")
    void batchInsert(List<ShopData> shopDataList);

    /**
     * 查询最新的导入时间
     * @return
     */
    @Select("select max(create_time) from db_shop_data")
    String selectMaxDate();

    /**
     * 店铺销售额数据报表
     *
     * @return
     */
    @Select("<script>" +
            " select DATE_FORMAT(data_date,'%m%d') dataDate,pay_money payMoney,uv,refund_goods_rate refundGoodsRate ,pay_conversion payConversion from db_shop_data where shop_id=#{shopId}" +
            " and data_date between #{dateStart} and #{dateEnd}" +
            " order by data_date" +
            "</script>")
    List<Map<String, Object>> shopSalesChart(@Param("dateStart")Date dateStart,@Param("dateEnd")Date dateEnd,@Param("shopId")String shopId);

    /**
     * 获取最大数据日期
     *
     * @return
     */
    @Select("select max(data_date) from db_shop_data")
    String selectMaxDataDate();

    /**
     * 根据数据日期与店铺名称查询
     *
     * @param dataDate
     * @param shopName
     * @return
     */
    @Select("select * from db_shop_data where data_date=#{dataDate} and shop_name=#{shopName}")
    ShopData selectByDataDate(@Param("dataDate") String dataDate, @Param("shopName") String shopName);

    /**
     * 查询平均销售额
     *
     * @param startTime
     * @param endTime
     * @param shopName
     * @return
     */
    @Select("select avg(pay_money) from db_shop_data where data_date <=#{endTime}  and data_date >= #{startTime} and shop_name=#{shopName}")
    Float getAvgPayMoney(@Param("startTime") String startTime, @Param("endTime") String endTime, @Param("shopName") String shopName);
}

package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.GoodsDataPc;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author : chenxiang
 * @date : 2018/7/6
 */
@Mapper
public interface GoodsDataPcDao extends BaseMapper<GoodsDataPc> {
    /**
     * 批量插入/更新
     *
     * @param goodsDataPcList
     */
    @Insert("<script>" +
            "insert into db_goods_data_pc (id,user_name,user_id,shop_id,shop_name,data_date,goods_id," +
            " pc_type_uv,pc_collection_uv,pc_ztc_uv,pc_tbk_uv,pc_pv,pc_uv," +
            " pc_entrance_number,pc_exit_number,pc_bounce_rate,pc_transaction_number," +
            " pc_avg_stay_time,pc_pay_conversion,pc_pay_money,pc_pay_goods,pc_search_uv)" +
            " values " +
            " <foreach collection=\"list\" item=\"i\" index=\"index\" separator=\",\" >" +
            " (#{i.id},#{i.userName},#{i.userId},#{i.shopId},#{i.shopName},#{i.dataDate},#{i.goodsId}," +
            " #{i.pcTypeUv},#{i.pcCollectionUv},#{i.pcZtcUv},#{i.pcTbkUv},#{i.pcPv},#{i.pcUv}," +
            " #{i.pcEntranceNumber},#{i.pcExitNumber},#{i.pcBounceRate},#{i.pcTransactionNumber}," +
            " #{i.pcAvgStayTime},#{i.pcPayConversion},#{i.pcPayMoney},#{i.pcPayGoods},#{i.pcSearchUv}" +
            ")" +
            "</foreach>" +
            "  ON DUPLICATE KEY UPDATE " +
            " user_name=values(user_name),user_id=values(user_id),shop_name=values(shop_name),data_date=values(data_date),goods_id=values(goods_id)," +
            " pc_type_uv=values(pc_type_uv),pc_collection_uv=values(pc_collection_uv),pc_ztc_uv=values(pc_ztc_uv),pc_tbk_uv=values(pc_tbk_uv),pc_pv=values(pc_pv),pc_uv=values(pc_uv)," +
            " pc_entrance_number=values(pc_entrance_number),pc_exit_number=values(pc_exit_number),pc_bounce_rate=values(pc_bounce_rate),pc_transaction_number=values(pc_transaction_number)," +
            " pc_avg_stay_time=values(pc_avg_stay_time),pc_pay_conversion=values(pc_pay_conversion),pc_pay_money=values(pc_pay_money),pc_pay_goods=values(pc_pay_goods),pc_search_uv=values(pc_search_uv)" +
            "</script>")
    void batchInsert(List<GoodsDataPc> goodsDataPcList);
}

package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

/**
 * @author : chenxiang
 * @date : 2018/6/25
 * 订单支付实体
 */
@Getter
@Setter
@TableName("db_order_pays")
public class OrderPays extends BaseModel<OrderPays> {
    /**
     * ERP内部订单号
     */
    private long oId;
    /**
     * 支付账号
     */
    private String outerPayId;
    /**
     * 线上订单号
     */
    private String soId;
    /**
     * 支付日期
     */
    private String payDate;
    /**
     * 总金额
     */
    private float amount;
    /**
     * 是否下单支付
     */
    private String isOrderPay;
    /**
     * 付款方式
     */
    private String payment;
    /**
     * 买家账号
     */
    private String buyerAccount;
    /**
     * 卖家账号
     */
    private String sellerAccount;
}

package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

/**
 * @Auther: chenxiang
 * @Date: 2018/8/13/0013 17:09
 * @Description:
 */
@TableName("db_shop_base_people")
@Getter
@Setter
public class ShopBasePeople extends BaseModel<ShopBasePeople> {
    /**
     * 人员id
     */
    private String userId;
    /**
     * 姓名
     */
    private String username;
    /**
     * 部门id
     */
    private String departmentId;
    /**
     * 部门名称
     */
    private String departmentName;

    /**
     * 人员类型 admin:负责人,participator:参与者
     */
    private String type;
    /**
     * 店铺id
     */
    private String shopId;
}

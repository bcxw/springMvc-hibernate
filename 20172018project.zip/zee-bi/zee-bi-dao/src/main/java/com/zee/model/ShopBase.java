package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @author : chenxiang
 * @date : 2018/6/21
 * 店铺基础
 */
@Getter
@Setter
@TableName("db_shop_base")
public class ShopBase extends BaseModel<ShopBase> {
    /**
     *店铺外部编码
     */
    private String shopId;
    /**
     * 店铺名称
     */
    private String shopName;
    /**
     * 平台
     */
    private String shopSite;
    /**
     * 昵称
     */
    private String nick;
    /**
     * 授权过期时间
     */
    private String sessionExpired;
    /**
     * 店铺创建时间
     */
    private String created;
}

package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.GoodsDataMp;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author : chenxiang
 * @date : 2018/7/6
 */
@Mapper
public interface GoodsDataMpDao extends BaseMapper<GoodsDataMp> {
    /**
     * 批量插入/更新
     *
     * @param goodsDataMpList
     */
    @Insert("<script>" +
            "insert into db_goods_data_mp (id,user_name,user_id,shop_id,shop_name,data_date,goods_id,mp_pv,mp_uv,mp_entrance_number,mp_bounce_rate,mp_exit_number,mp_transaction_number," +
            "mp_avg_stay_time,mp_pay_conversion,mp_pay_money,mp_pay_goods,mp_search_uv)" +
            " values " +
            " <foreach collection=\"list\" item=\"i\" index=\"index\" separator=\",\" >" +
            " (#{i.id},#{i.userName},#{i.userId},#{i.shopId},#{i.shopName},#{i.dataDate},#{i.goodsId},#{i.mpPv},#{i.mpUv},#{i.mpEntranceNumber},#{i.mpBounceRate},#{i.mpExitNumber},#{i.mpTransactionNumber}," +
            " #{i.mpAvgStayTime},#{i.mpPayConversion},#{i.mpPayMoney},#{i.mpPayGoods},#{i.mpSearchUv}" +
            ")" +
            "</foreach>" +
            "  ON DUPLICATE KEY UPDATE " +
            " user_name=values(user_name),user_id=values(user_id),shop_name=values(shop_name),data_date=values(data_date),goods_id=values(goods_id),mp_pv=values(mp_pv),mp_uv=values(mp_uv),mp_entrance_number=values(mp_entrance_number),mp_bounce_rate=values(mp_bounce_rate),mp_exit_number=values(mp_exit_number),mp_transaction_number=values(mp_transaction_number)," +
            " mp_avg_stay_time=values(mp_avg_stay_time),mp_pay_conversion=values(mp_pay_conversion),mp_pay_money=values(mp_pay_money),mp_pay_goods=values(mp_pay_goods),mp_search_uv=values(mp_search_uv)" +
            "</script>")
    void batchInsert(List<GoodsDataMp> goodsDataMpList);
}

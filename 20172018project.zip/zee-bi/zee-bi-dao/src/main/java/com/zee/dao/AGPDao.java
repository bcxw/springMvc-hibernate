package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.AGP;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @Auther: chenxiang
 * @Date: 2018/7/16/0016 15:08
 * @Description:
 */
@Mapper
public interface AGPDao extends BaseMapper<AGP> {
    /**
     * 插入/更新agp
     *
     * @param agpList
     */
    @Insert("<script>" +
            "insert into db_agp (id,shop_name,yesterday_agp,last_month_agp,turnover,store_owner," +
            "store_participants,compared_to_last_week,compared_to_last_year,data_date)" +
            " values" +
            " <foreach collection=\"list\" item=\"item\" index=\"index\" separator=\",\" >" +
            "(#{item.id},#{item.shopName},#{item.yesterdayAgp},#{item.lastMonthAgp},#{item.turnover},#{item.storeOwner}" +
            ",#{item.storeParticipants},#{item.comparedToLastWeek},#{item.comparedToLastYear},#{item.dataDate})" +
            "</foreach>" +
            "  ON DUPLICATE KEY UPDATE " +
            " shop_name=values(shop_name),yesterday_agp=values(yesterday_agp),last_month_agp=values(last_month_agp),turnover=values(turnover),store_owner=values(store_owner)," +
            " store_participants=values(store_participants),compared_to_last_week=values(compared_to_last_week),compared_to_last_year=values(compared_to_last_year),data_date=values(data_date)" +
            "</script>")
    void batchInsert(List<AGP> agpList);

}

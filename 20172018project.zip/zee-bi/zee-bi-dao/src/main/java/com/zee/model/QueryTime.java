package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

/**
 * @author : chenxiang
 * @date : 2018/7/11
 */
@Getter
@Setter
@TableName("db_query_time")
public class QueryTime extends BaseModel<QueryTime> {
    /**
     * 每次查询结束时间
     */
    private String endTime;
    /**
     * 查询类型
     */
    private String queryType;
}

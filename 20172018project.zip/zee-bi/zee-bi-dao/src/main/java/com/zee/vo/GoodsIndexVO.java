package com.zee.vo;

import com.zee.model.GoodsData;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @Auther: chenxiang
 * @Date: 2018/8/8/0008 13:36
 * @Description:商品指标vo类
 */
@Getter
@Setter
public class GoodsIndexVO {
    /**
     * 店铺id
     */
    private String shopId;
    /**
     * 店铺名称
     */
    private String shopName;
    /**
     * 数据日期
     */
    private Date dataDate;
    /**
     * 商品Id
     */
    private String goodsId;
    /**
     * 商家编码
     */
    private String merchantCode;
    /**
     * 行业类目
     */
    private String industryType;
    /**
     * 商品标题
     */
    private String title;

    /**
     * 商品链接
     */
    private String url;
    /**
     * 浏览量
     */
    private Integer pv;
    /**
     * 访客数
     */
    private int uv;
    /**
     * 交易笔数
     */
    private int transactionNumber;
    /**
     * 入口数
     */
    private int entranceNumber;
    /**
     * 出口数
     */
    private int exitNumber;
    /**
     * 跳失率
     */
    private float bounceRate;
    /**
     * 平均停留时长
     */
    private float avgStayTime;
    /**
     * 收藏数
     */
    private int collectionNumber;
    /**
     * 新增购物车人数
     */
    private int shoppingCartCustomerNumber;
    /**
     * 新增购物车宝贝件数
     */
    private int ShoppingCartGoodsNumber;
    /**
     * 退款金额
     */
    private float refundMoney;
    /**
     * 退货量
     */
    private int refundCount;
    /**
     * 退货率
     */
    private float refundRate;
    /**
     * 支付转化率
     */
    private float payConversion;
    /**
     * 支付金额
     */
    private float payMoney;
    /**
     * 支付商品件数
     */
    private int payGoods;

    /**
     * 搜索引导访客数
     */
    private int searchUv;
    /**
     * 老访客数
     */
    private int oldUv;
    /**
     * 老客销售额
     */
    private int oldPayMoney;
    /**
     * 成交宝贝数(老客)
     */
    private int oldPayGoods;
    /**
     * 老客成交笔数
     */
    private int oldTransactionNumber;
    /**
     * 老客销售额
     */
    private int oldPayConversion;
    /**
     * 手机端交易笔数
     */
    private int mpTransactionNumber;
    /**
     * 手机端入口数
     */
    private int mpEntranceNumber;
    /**
     * 手机端出口数
     */
    private int mpExitNumber;
    /**
     * 手机端跳失率
     */
    private float mpBounceRate;
    /**
     * 手机端浏览量
     */
    private int mpPv;
    /**
     * 手机端访客数
     */
    private int mpUv;
    /**
     * 手机端平均停留时长
     */
    private float mpAvgStayTime;
    /**
     * 无线支付转化率
     */
    private float mpPayConversion;
    /**
     * 手机端支付金额
     */
    private float mpPayMoney;
    /**
     * 手机端支付商品件数
     */
    private int mpPayGoods;
    /**
     * 手机端搜索引导访客数
     */
    private int mpSearchUv;
    /**
     * pc端类目uv
     */
    private int pcTypeUv;
    /**
     * pc端收藏uv
     */
    private int pcCollectionUv;
    /**
     * pc端直通车uv
     */
    private int pcZtcUv;
    /**
     * pc端淘宝客uv
     */
    private int pcTbkUv;
    /**
     * pc浏览量
     */
    private int pcPv;
    /**
     * pc访客数
     */
    private int pcUv;
    /**
     * pc交易笔数
     */
    private int pcTransactionNumber;
    /**
     * pc入口数
     */
    private int pcEntranceNumber;
    /**
     * pc出口数
     */
    private int pcExitNumber;
    /**
     * pc跳失率
     */
    private float pcBounceRate;
    /**
     * pc平均停留时长
     */
    private float pcAvgStayTime;
    /**
     * pc详情页跳出率
     */
    private float pcDetailHoppingRate;
    /**
     * pc支付转化率
     */
    private float pcPayConversion;
    /**
     * pc支付金额
     */
    private float pcPayMoney;
    /**
     * pc支付商品件数
     */
    private int pcPayGoods;
    /**
     * pc搜索引导访客数
     */
    private int pcSearchUv;
    /**
     * 款号id
     */
    private String iId;
    /**
     * 商品Id
     */
    private String skuId;
    /**
     * 店铺款号id
     */
    private String shopIId;
    /**
     * 店铺商品id
     */
    private String shopSkuId;

}

package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.ShopDataPc;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author : chenxiang
 * @date : 2018/6/29
 */
@Mapper
public interface ShopDataPcDao extends BaseMapper<ShopDataPc> {
    /**
     * 批量插入/更新
     * @param shopDataPcList
     */
    @Insert("<script>" +
            "insert into db_shop_data_pc (id,user_name,shop_name,shop_id,data_date,pc_uv,pc_new_uv,pc_old_uv,pc_pct,pc_pv,pc_old_pv,pc_new_pv," +
            " pc_pay_money,pc_pay_goods,pc_pay_customers,pc_pay_conversion,pc_order_count,pc_six_back,pc_refund_goods_rate,pc_refund_money_rate," +
            " pc_refund_amount,pc_refund_count" +
            ")" +
            "values " +
            " <foreach collection=\"list\" separator=\",\" item=\"i\">\n" +
            " (#{i.id},#{i.userName},#{i.shopName},#{i.shopId},#{i.dataDate},#{i.pcUv},#{i.pcNewUv},#{i.pcOldUv},#{i.pcPct},#{i.pcPv},#{i.pcOldPv},#{i.pcNewPv}," +
            " #{i.pcPayMoney},#{i.pcPayGoods},#{i.pcPayCustomers},#{i.pcPayConversion},#{i.pcOrderCount},#{i.pcSixBack},#{i.pcRefundGoodsRate},#{i.pcRefundMoneyRate}," +
            " #{i.pcRefundAmount},#{i.pcRefundCount}" +
            ")" +
            "    </foreach>" +
            "  ON DUPLICATE KEY UPDATE " +
            " user_name=values(user_name),shop_name=values(shop_name),shop_id=values(shop_id),data_date=values(data_date),pc_uv=values(pc_uv),pc_new_uv=values(pc_new_uv),pc_old_uv=values(pc_old_uv),pc_pct=values(pc_pct),pc_pv=values(pc_pv),pc_old_pv=values(pc_old_pv),pc_new_pv=values(pc_new_pv)," +
            " pc_pay_money=values(pc_pay_money),pc_pay_goods=values(pc_pay_goods),pc_pay_customers=values(pc_pay_customers),pc_pay_conversion=values(pc_pay_conversion),pc_order_count=values(pc_order_count),pc_six_back=values(pc_six_back),pc_refund_goods_rate=values(pc_refund_goods_rate),pc_refund_money_rate=values(pc_refund_money_rate)," +
            " pc_refund_amount=values(pc_refund_amount),pc_refund_count=values(pc_refund_count)" +
            "</script>")
    void batchInsert(List<ShopDataPc> shopDataPcList);
}

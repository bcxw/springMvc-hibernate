package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.OrderItems;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author : chenxiang
 * @date : 2018/6/25
 * 订单详情dao
 */
@Mapper
public interface OrderItemsDao extends BaseMapper<OrderItems> {
    /**
     * 批量插入/更新
     *
     * @param rgiList
     */
    @Insert("<script>"
            + "insert into db_order_items (id,o_id,sku_id,qty,base_price,price,amount,name,shop_sku_id,properties_value)"
            + "values"
            + " <foreach collection=\"list\" item=\"item\" index=\"index\" separator=\",\" >"
            + "(#{item.id},#{item.oId},#{item.skuId},#{item.qty},#{item.basePrice},#{item.price},#{item.amount},#{item.name},#{item.shopSkuId},#{item.propertiesValue})"
            + "</foreach>" +
            "</script>")
    void batchInsert(List<OrderItems> rgiList);
}

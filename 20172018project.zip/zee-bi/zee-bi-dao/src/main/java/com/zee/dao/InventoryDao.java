package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.Inventory;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author : chenxiang
 * @date : 2018/6/25
 * 库存dao
 */
@Mapper
public interface InventoryDao extends BaseMapper<Inventory> {
    /**
     * 批量插入/更新
     *
     * @param result
     */
    @Insert("<script>" +
            "insert into db_inventory (id,sku_id,i_id,qty,order_lock,virtual_qty,purchase_qty,modified,residue_days)" +
            "values" +
            "<foreach collection=\"list\" item=\"item\" index=\"index\" separator=\",\">" +
            "(#{item.id},#{item.skuId},#{item.iId},#{item.qty},#{item.orderLock},#{item.virtualQty},#{item.purchaseQty},#{item.modified},#{item.residueDays})" +
            "</foreach>" +
            "  ON DUPLICATE KEY UPDATE " +
            "sku_id=values(sku_id),i_id=values(i_id),qty=values(qty),order_lock=values(order_lock),virtual_qty=values(virtual_qty),purchase_qty=values(purchase_qty),modified=values(modified),residue_days=values(residue_days)" +
            "</script>")
    void batchInsert(List<Inventory> result);


}

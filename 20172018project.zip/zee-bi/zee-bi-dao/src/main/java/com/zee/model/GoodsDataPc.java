package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @author : chenxiang
 * @date : 2018/7/6
 */
@Getter
@Setter
@TableName("db_goods_data_pc")
public class GoodsDataPc extends BaseModel<GoodsDataPc> {
    /**
     * 导入人
     */
    private String userName;
    /**
     * 导入人id
     */
    private String userId;
    /**
     * 店铺id
     */
    private String shopId;
    /**
     * 店铺名称
     */
    private String shopName;
    /**
     * 数据日期
     */
    private Date dataDate;
    /**
     * 商品Id
     */
    private String goodsId;
    /**
     * pc端类目uv
     */
    private int pcTypeUv;
    /**
     * pc端收藏uv
     */
    private int pcCollectionUv;
    /**
     * pc端直通车uv
     */
    private int pcZtcUv;
    /**
     * pc端淘宝客uv
     */
    private int pcTbkUv;
    /**
     * pc浏览量
     */
    private int pcPv;
    /**
     * pc访客数
     */
    private int pcUv;
    /**
     * pc交易笔数
     */
    private int pcTransactionNumber;
    /**
     * pc入口数
     */
    private int pcEntranceNumber;
    /**
     * pc出口数
     */
    private int pcExitNumber;
    /**
     * pc跳失率
     */
    private float pcBounceRate;
    /**
     * pc平均停留时长
     */
    private float pcAvgStayTime;
    /**
     * pc支付转化率
     */
    private float pcPayConversion;
    /**
     * pc支付金额
     */
    private float pcPayMoney;
    /**
     * pc支付商品件数
     */
    private int pcPayGoods;
    /**
     * pc搜索引导访客数
     */
    private int pcSearchUv;


}

package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;


/**
 * @author : chenxiang
 * @date : 2018/6/25
 */
@Getter
@Setter
@TableName("db_inventory")
public class Inventory extends BaseModel<Inventory> {
    /**
     * 商品编码
     */
    private String skuId;
    /**
     * 款式编码
     */
    private String iId;
    /**
     * 数量
     */
    private int qty;
    /**
     * 订单锁定数
     */
    private int orderLock;
    /**
     * 虚拟库存
     */
    private int virtualQty;
    /**
     * 采购在途数
     */
    private int purchaseQty;
    /**
     * 修改时间
     */
    private String modified;
    /**
     * 剩余可售时间(day)
     */
    private float residueDays;
    /**
     * 7天平均销量
     */
    private float avgSale;
    /**
     * 7天平均访客数
     */
    private float avgUv;
    /**
     * 7天平均浏览量
     */
    private float avgPv;
}

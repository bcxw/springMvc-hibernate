package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

/**
 * @author : chenxiang
 * @date : 2018/6/25
 * 订单主表实体
 */

@Setter
@Getter
@TableName("db_order")
public class Order extends BaseModel<Order> {
    /**
     * ERP内部订单号
     */
    private long oId;
    /**
     * 类型
     */
    private String type;
    /**
     * 下单时间
     */
    private String orderDate;
    /**
     * 买家id
     */
    private String shopBuyerId;
    /**
     * 店铺编码
     */
    private String shopId;
    /**
     * 平台
     */
    private String shopSite;
    /**
     * 线上订单号
     */
    private String soId;
    /**
     * 总金额
     */
    private float amount;
    /**
     * 支付金额
     */
    private float payAmount;
    /**
     * 已支付金额
     */
    private float paidAmount;
    /**
     * 优惠金额
     */
    private float freeAmount;
    /**
     * 折扣
     */
    private float discountRate;
    /**
     * 问题类型
     */
    private String questionType;
    /**
     * 问题排序
     */
    private String questionDesc;
    /**
     * 状态
     */
    private String status;
    /**
     * 店铺状态
     */
    private String shopStatus;
    /**
     * 发票抬头
     */
    private String invoiceTitle;
    /**
     * 修改时间
     */
    private String modified;
    /**
     * 收货地址 省份
     */
    private String receiverState;
    /**
     * 收获城市
     */
    private String receiverCity;
    /**
     * 收货区域
     */
    private String receiverDistrict;
    /**
     * 邮编
     */
    private String receiverZip;
    /**
     * 收货详细地址
     */
    private String receiverAddress;
    /**
     * 收件人姓名
     */
    private String receiverName;
    /**
     * 收件人电话
     */
    private String receiverPhone;
    /**
     * 收件人手机号
     */
    private String receiverMobile;
    /**
     * 买家消息
     */
    private String buyerMessage;
    /**
     * 运送方式
     */
    private String freight;
    /**
     * 备注
     */
    private String remark;
    /**
     * 发货日期
     */
    private String sendDate;
    /**
     * ???
     */
    private String isCod;
    /**
     * 订单来源
     */
    private String orderFrom;
    /**
     * 卖家可能率
     */
    private String sellerCanRate;
    /**
     * 销售率?
     */
    private String sellerRate;


}

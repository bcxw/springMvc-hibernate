package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.ShopDataMp;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author : chenxiang
 * @date : 2018/6/29
 */
@Mapper
public interface ShopDataMpDao extends BaseMapper<ShopDataMp> {
    /**
     * 批量插入/更新
     *
     * @param shopDataMpList
     */
    @Insert("<script>" +
            "insert into db_shop_data_mp (id,user_name,shop_name,shop_id,data_date,mp_uv,mp_new_uv,mp_old_uv,mp_pct,mp_pv,mp_old_pv,mp_new_pv," +
            " mp_pay_money,mp_pay_goods,mp_pay_customers,mp_pay_conversion,mp_order_count,mp_six_back,mp_refund_goods_rate,mp_refund_money_rate," +
            " mp_refund_amount,mp_refund_count" +
            ")" +
            "values " +
            " <foreach collection=\"list\" separator=\",\" item=\"i\">\n" +
            " (#{i.id},#{i.userName},#{i.shopName},#{i.shopId},#{i.dataDate},#{i.mpUv},#{i.mpNewUv},#{i.mpOldUv},#{i.mpPct},#{i.mpPv},#{i.mpOldPv},#{i.mpNewPv}," +
            " #{i.mpPayMoney},#{i.mpPayGoods},#{i.mpPayCustomers},#{i.mpPayConversion},#{i.mpOrderCount},#{i.mpSixBack},#{i.mpRefundGoodsRate},#{i.mpRefundMoneyRate}," +
            " #{i.mpRefundAmount},#{i.mpRefundCount}" +
            ")" +

            "    </foreach>" +
            "  ON DUPLICATE KEY UPDATE " +
            " user_name=values(user_name),shop_name=values(shop_name),shop_id=values(shop_id),data_date=values(data_date),mp_uv=values(mp_uv),mp_new_uv=values(mp_new_uv),mp_old_uv=values(mp_old_uv),mp_pct=values(mp_pct),mp_pv=values(mp_pv),mp_old_pv=values(mp_old_pv),mp_new_pv=values(mp_new_pv)," +
            " mp_pay_money=values(mp_pay_money),mp_pay_goods=values(mp_pay_goods),mp_pay_customers=values(mp_pay_customers),mp_pay_conversion=values(mp_pay_conversion),mp_order_count=values(mp_order_count),mp_six_back=values(mp_six_back),mp_refund_goods_rate=values(mp_refund_goods_rate),mp_refund_money_rate=values(mp_refund_money_rate)," +
            " mp_refund_amount=values(mp_refund_amount),mp_refund_count=values(mp_refund_count)" +
            "</script>")
    void batchInsert(List<ShopDataMp> shopDataMpList);
}

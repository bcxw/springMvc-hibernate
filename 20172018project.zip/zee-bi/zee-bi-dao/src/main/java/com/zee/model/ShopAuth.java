package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

/**
 * 店铺权限
 */
@Getter
@Setter
@TableName("db_shop_auth")
public class ShopAuth extends BaseModel<ShopAuth> {

    //店铺id
    private String shopId;
    //店铺名称
    private String shopName;
    //用户id
    private String userId;
    //用户名
    private String userName;

}

package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.OrderPays;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author : chenxiang
 * @date : 2018/6/25
 * 订单支付dao
 */
@Mapper
public interface OrderPaysDao extends BaseMapper<OrderPays> {
    /**
     * 批量插入/更新
     *
     * @param paysList
     */
    @Insert("<script>"
            + "insert into db_order_pays (id,o_id,outer_pay_id,so_id,pay_date,amount,is_order_pay,payment,buyer_account,seller_account)"
            + "values"
            + " <foreach collection=\"list\" item=\"item\" index=\"index\" separator=\",\" >"
            + "(#{item.id},#{item.oId},#{item.outerPayId},#{item.soId},#{item.payDate},#{item.amount},#{item.isOrderPay},#{item.payment},#{item.buyerAccount},#{item.sellerAccount})"
            + "</foreach>" +
            "</script>")
    void batchInsert(List<OrderPays> paysList);
}

package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @author : chenxiang
 * @date : 2018/6/29
 */
@Getter
@Setter
@TableName("db_shop_data")
public class ShopData extends BaseModel<ShopData> {
    /**
     * 导入人
     */
    private String userName;
    /**
     * 店铺名称
     */
    private String shopName;
    /**
     * 店铺id
     */
    private String shopId;
    /**
     * 统计日期
     */
    private Date dataDate;
    /**
     * 访问深度
     */
    private float uvDepth;
    /**
     * 客单价
     */
    private float pct;
    /**
     * 访客数
     */
    private int uv;
    /**
     * 老访客数
     */
    private int oldUv;
    /**
     * 新访客数
     */
    private int newUv;
    /**
     * 浏览量
     */
    private int pv;

    /**
     * 支付金额
     */
    private float payMoney;
    /**
     * 支付买家数
     */
    private int payCustomers;
    /**
     * 支付商品数
     */
    private int payGoods;
    /**
     * 支付转化率
     */
    private float payConversion;
    /**
     * 页面平均停留时长
     */
    private float pageAvgStayTime;
    /**
     * 人均停留时长
     */
    private float avgStayTime;
    /**
     * 新客人均停留时长
     */
    private float newAvgStayTime;
    /**
     * 老客人均停留时长
     */
    private float oldAvgStayTime;
    /**
     * 旺旺咨询人数
     */
    private int wwConsultNumber;
    /**
     * 询盘-成交转化率
     */
    private float inquiryTransactionConversion;
    /**
     * 静默转化率
     */
    private float silentConversionRate;
    /**
     * 退款金额
     */
    private float refundAmount;
    /**
     * 退款数量
     */
    private float refundCount;
    /**
     * 退款率
     */
    private float refundMoneyRate;
    /**
     * 退货率
     */
    private float refundGoodsRate;
    /**
     * 店铺收藏买家数
     */
    private float shopCollectionCustomers;
    /**
     * 下单件数
     */
    private int orderCount;
    /**
     * 新增购物车人数
     */
    private int addShoppingCartCustomer;
    /**
     * 新增购物车宝贝件数
     */
    private int addShoppingCartGoods;
    /**
     * 宝贝收藏数
     */
    private int goodsCollectionCustomers;
    /**
     * 老客销售额
     */
    private float oldPayMoney;
    /**
     * 老客销售量
     */
    private int oldPayGoods;

    /**
     * 老客成交用户数
     */
    private int oldPayCustomers;
    /**
     * DSR得分（描述相符）
     */
    private float dsrDescribeScore;
    /**
     * DSR评分次数（描述相符）
     */
    private int dsrDescribeNumber;
    /**
     * DSR得分（服务态度）
     */
    private float dsrServerScore;
    /**
     * DSR评分次数（服务态度）
     */
    private int dsrServerNumber;
    /**
     * DSR得分（发货速度）
     */
    private float dsrShipmentsScore;
    /**
     * DSR评分次数（发货速度）
     */
    private int dsrShipmentsNumber;
    /**
     * DSR得分（物流速度）
     */
    private float dsrLogisticsScore;
    /**
     * DSR评分次数（物流速度）
     */
    private int dsrLogisticsNumber;

}

package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

/**
 * 基础数据
 */

@Getter
@Setter
@TableName("sys_basedata")
public class Basedata extends BaseModel<Basedata> {

    //上级id
    private String parentId;
    //名称
    private String name;
    //编码
    private String code;
    //值
    private String value;
    //扩展数据
    private String extendJson;
    //描述
    private String description;
    //排序编号
    private Integer sortorder;
    //状态
    private String status;

}

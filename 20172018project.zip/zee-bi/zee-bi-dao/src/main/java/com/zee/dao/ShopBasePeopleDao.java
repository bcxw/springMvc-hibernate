package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.ShopBasePeople;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Auther: chenxiang
 * @Date: 2018/8/13/0013 17:12
 * @Description:
 */
@Mapper
public interface ShopBasePeopleDao extends BaseMapper<ShopBasePeople> {
}

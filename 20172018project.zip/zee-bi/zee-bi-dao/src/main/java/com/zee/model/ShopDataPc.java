package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @author : chenxiang
 * @date : 2018/6/29
 * 店铺数据pc端
 */
@Getter
@Setter
@TableName("db_shop_data_pc")
public class ShopDataPc extends BaseModel<ShopDataPc> {
    /**
     * 导入人
     */
    private String userName;
    /**
     * 店铺名称
     */
    private String shopName;
    /**
     * 店铺id
     */
    private String shopId;
    /**
     * 统计日期
     */
    private Date dataDate;
    /**
     * PC端访客数
     */
    private int pcUv;
    /**
     * PC端客单价
     */
    private float pcPct;
    /**
     * PC端老访客数
     */
    private int pcOldUv;
    /**
     * PC端新访客数
     */
    private int pcNewUv;
    /**
     * PC端浏览量
     */
    private int pcPv;
    /**
     * PC端新客浏览量
     */
    private int pcNewPv;
    /**
     * PC端老客浏览量
     */
    private int pcOldPv;
    /**
     * PC端支付金额
     */
    private float pcPayMoney;
    /**
     * PC端交易买家数
     */
    private int pcPayCustomers;
    /**
     * PC端销售量
     */
    private int pcPayGoods;
    /**
     * PC端支付转化率
     */
    private float pcPayConversion;
    /**
     * PC端下单件数
     */
    private int pcOrderCount;
    /**
     * pc端退款金额
     */
    private float pcRefundAmount;
    /**
     * pc端退款数量
     */
    private int pcRefundCount;
    /**
     * pc端退款率
     */
    private float pcRefundMoneyRate;
    /**
     * pc端退货率
     */
    private float pcRefundGoodsRate;
    /**
     * pc端6日回访客数
     */
    private int pcSixBack;
}

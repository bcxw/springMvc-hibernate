package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @author : chenxiang
 * @date : 2018/7/6
 * 商品数据
 */
@Getter
@Setter
@TableName("db_goods_data")
public class GoodsData extends BaseModel<GoodsData> {
    /**
     * 导入人
     */
    private String userName;
    /**
     * 导入人id
     */
    private String userId;
    /**
     * 店铺id
     */
    private String shopId;
    /**
     * 店铺名称
     */
    private String shopName;
    /**
     * 数据日期
     */
    private Date dataDate;
    /**
     * 商品Id
     */
    private String goodsId;
    /**
     * 商家编码
     */
    private String merchantCode;
    /**
     * 行业类目
     */
    private String industryType;
    /**
     * 商品标题
     */
    private String title;

    /**
     * 商品链接
     */
    private String url;
    /**
     * 浏览量
     */
    private Integer pv;
    /**
     * 访客数
     */
    private int uv;
    /**
     * 交易笔数
     */
    private int transactionNumber;
    /**
     * 入口数
     */
    private int entranceNumber;
    /**
     * 出口数
     */
    private int exitNumber;
    /**
     * 跳失率
     */
    private float bounceRate;
    /**
     * 平均停留时长
     */
    private float avgStayTime;
    /**
     * 收藏数
     */
    private int collectionNumber;
    /**
     * 新增购物车人数
     */
    private int shoppingCartCustomerNumber;
    /**
     * 新增购物车宝贝件数
     */
    private int ShoppingCartGoodsNumber;
    /**
     * 退款金额
     */
    private float refundMoney;
    /**
     * 退货量
     */
    private int refundCount;
    /**
     * 退货率
     */
    private float refundRate;
    /**
     * 支付转化率
     */
    private float payConversion;
    /**
     * 支付金额
     */
    private float payMoney;
    /**
     * 支付商品件数
     */
    private int payGoods;

    /**
     * 搜索引导访客数
     */
    private int searchUv;
    /**
     * 老访客数
     */
    private int oldUv;
    /**
     * 老客销售额
     */
    private int oldPayMoney;
    /**
     * 成交宝贝数(老客)
     */
    private int oldPayGoods;
    /**
     * 老客成交笔数
     */
    private int oldTransactionNumber;
    /**
     * 老客销售额
     */
    private int oldPayConversion;
}

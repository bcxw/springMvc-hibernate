package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;


@Getter
@Setter
@TableName("test")
public class TestModel extends BaseModel<TestModel> {

    private Integer shopId;

    private Date datadate;

}

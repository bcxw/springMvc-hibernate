package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

/**
 * @Auther: chenxiang
 * @Date: 2018/7/18/0018 16:10
 * @Description:
 */
@Setter
@Getter
@TableName("db_shop_agp")
public class ShopAgp extends BaseModel<ShopAgp> {
    /**
     * 月份
     */
    private String agpMonth;
    /**
     * agp率
     */
    private float agpRate;
    /**
     * 店铺id
     */
    private String shopId;
    /**
     * 店铺名称
     */
    private String shopName;
}

package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

/**
 * @author : chenxiang
 * @date : 2018/6/25
 * 退货退款子表实体
 */
@Getter
@Setter
@TableName("db_returngoods_items")
public class ReturnGoodsItems extends BaseModel<ReturnGoodsItems> {
    /**
     * 售后单号
     */
    private long asId;
    /**
     * 售后子单号
     */
    private long asiId;
    /**
     * 商品编码
     */
    private String skuId;
    /**
     * 数量
     */
    private int qty;
    /**
     * 价格
     */
    private float price;
    /**
     * 商品名称
     */
    private String name;
    /**
     * 图片地址
     */
    private String pic;
    /**
     * 类型（退货，换货等）
     */
    private String type;
    /**
     * 颜色规格
     */
    private String propertiesValue;
    /**
     * 实收退货数量
     */
    private String rQty;

}

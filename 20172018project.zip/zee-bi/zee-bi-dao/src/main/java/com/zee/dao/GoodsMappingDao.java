package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.GoodsMapping;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author : chenxiang
 * @date : 2018/6/25
 * 商品映射dao
 */
@Mapper
public interface GoodsMappingDao extends BaseMapper<GoodsMapping> {
    /**
     * 批量插入/更新
     *
     * @param result
     */
    @Insert("<script>" +
            "insert into db_goods_mapping (id,shop_id,channel,i_id,sku_id,shop_i_id,modified,enabled,shop_sku_id)" +
            "values" +
            "<foreach collection=\"list\" item=\"item\" index=\"index\" separator=\",\">" +
            "(#{item.id},#{item.shopId},#{item.channel},#{item.iId},#{item.skuId},#{item.shopIId},#{item.modified},#{item.enabled},#{item.shopSkuId})" +
            "</foreach>" +
            "  ON DUPLICATE KEY UPDATE " +
            "shop_id=values(shop_id),channel=values(channel),i_id=values(i_id),sku_id=values(sku_id),shop_i_id=values(shop_i_id),modified=values(modified),enabled=values(enabled),shop_sku_id=values(shop_sku_id)" +
            "</script>")
    void batchInsert(List<GoodsMapping> result);
}

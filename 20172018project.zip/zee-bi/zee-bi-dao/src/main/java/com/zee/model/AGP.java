package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @Auther: chenxiang
 * @Date: 2018/7/16/0016 14:56
 * @Description:
 */
@Getter
@Setter
@TableName("db_agp")
public class AGP extends BaseModel<AGP> {
    /**
     * 店铺名称
     */
    private String shopName;
    /**
     * 营业额
     */
    private float turnover;
    /**
     * 昨日AGP
     */
    private int yesterdayAgp;
    /**
     * 上月AGP率
     */
    private float lastMonthAgp;
    /**
     * 店铺负责人
     */
    private String storeOwner;
    /**
     * 店铺参与人
     */
    private String storeParticipants;
    /**
     * 上周同比(%)
     */
    private float comparedToLastWeek;
    /**
     * 去年同比(%)
     */
    private float comparedToLastYear;
    /**
     * 数据日期
     */
    private Date dataDate;

}

package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.ShopAuth;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 店铺权限
 */
@Mapper
public interface ShopAuthDao extends BaseMapper<ShopAuth> {
    /**
     * 批量插入用户
     * @param shopAuthList
     */
    @Insert("<script>" +
            "insert into db_shop_auth (id,shop_id,shop_name,user_id,user_name)"
            + "values"
            + " <foreach collection=\"shopAuthList\" item=\"item\" index=\"index\" separator=\",\" >"
            + "(REPLACE(UUID(),'-',''),#{item.shopId},#{item.shopName},#{item.userId},#{item.userName})"
            + "</foreach>"
            + "</script>")
    void batchInsert(@Param("shopAuthList") List<ShopAuth> shopAuthList);

}

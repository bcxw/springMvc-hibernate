package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @author : chenxiang
 * @date : 2018/7/6
 */
@Getter
@Setter
@TableName("db_goods_data_mp")
public class GoodsDataMp extends BaseModel<GoodsDataMp> {
    /**
     * 导入人
     */
    private String userName;
    /**
     * 导入人id
     */
    private String userId;
    /**
     * 店铺id
     */
    private String shopId;
    /**
     * 店铺名称
     */
    private String shopName;
    /**
     * 数据日期
     */
    private Date dataDate;
    /**
     * 商品Id
     */
    private String goodsId;
    /**
     * 手机端交易笔数
     */
    private int mpTransactionNumber;
    /**
     *手机端入口数
     */
    private  int mpEntranceNumber;
    /**
     *手机端出口数
     */
    private  int mpExitNumber;
    /**
     *手机端跳失率
     */
    private  float mpBounceRate;
    /**
     * 手机端浏览量
     */
    private int mpPv;
    /**
     * 手机端访客数
     */
    private int mpUv;
    /**
     * 手机端平均停留时长
     */
    private float mpAvgStayTime;
    /**
     * 无线支付转化率
     */
    private float mpPayConversion;
    /**
     * 手机端支付金额
     */
    private float mpPayMoney;
    /**
     * 手机端支付商品件数
     */
    private int mpPayGoods;
    /**
     * 手机端搜索引导访客数
     */
    private int mpSearchUv;


}

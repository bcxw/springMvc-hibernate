package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

/**
 * @author : chenxiang
 * @date : 2018/6/25
 */
@Getter
@Setter
@TableName("db_goods_mapping")
public class GoodsMapping extends BaseModel<GoodsMapping> {
    /**
     * 店铺编码
     */
    private int shopId;
    /**
     * 平台
     */
    private String channel;
    /**
     * 款号id
     */
    private String iId;
    /**
     * 商品Id
     */
    private String skuId;
    /**
     * 店铺款号id
     */
    private String shopIId;
    /**
     * 店铺商品id
     */
    private  String shopSkuId;
    /**
     * 修改时间
     */
    private String modified;
    /**
     * 是否在售
     */
    private String enabled;
}

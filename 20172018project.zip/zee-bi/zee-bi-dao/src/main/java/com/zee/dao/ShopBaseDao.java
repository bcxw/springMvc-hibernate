package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.ShopBase;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * @author : chenxiang
 * @date : 2018/6/21
 * 店铺基础dao
 */
@Mapper
public interface ShopBaseDao extends BaseMapper<ShopBase> {
    /**
     * 批量插入/更新
     *
     * @param result
     */
    @Insert("<script>" +
            "insert into db_shop_base (id,shop_id,shop_name,shop_site,nick,session_expired,created)"
            + "values"
            + " <foreach collection=\"list\" item=\"item\" index=\"index\" separator=\",\" >"
            + "(#{item.id},#{item.shopId},#{item.shopName},#{item.shopSite},#{item.nick},#{item.sessionExpired},#{item.created})"
            + "</foreach>"
            + "</script>")
    void batchInsert(List<ShopBase> result);

    /**
     * 分页查询
     *
     * @param start
     * @param limit
     * @return
     */
    @Select("<script> " +
            "select sb.*,sa.userIds,sa.userNames from " +
            "(select id,shop_id shopId,shop_name shopName,shop_site shopSite,nick from db_shop_base limit #{start},#{limit} ) sb " +
            "," +
            "(select shop_id,group_concat(user_id) userIds,group_concat(user_name) userNames from db_shop_auth group by shop_id) sa" +
            " where sb.shopId=sa.shop_id  " +
            "</script>")
    List<Map<String, String>> list(@Param("start") int start, @Param("limit") int limit);

    /**
     * 获取总条数
     *
     * @return
     */
    @Select("select count(1) from db_shop_base")
    int count();

}

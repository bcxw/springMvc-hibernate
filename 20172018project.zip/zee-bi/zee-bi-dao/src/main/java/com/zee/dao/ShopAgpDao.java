package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.ShopAgp;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * @Auther: chenxiang
 * @Date: 2018/7/18/0018 16:14
 * @Description:
 */
@Mapper
public interface ShopAgpDao extends BaseMapper<ShopAgp> {


    /**
     * 根据店铺名称与agp月份查询
     *
     * @param shopName
     * @param agpMonth
     * @return
     */
    @Select("select * from db_shop_agp where shop_name=#{shopName} and agp_month=#{agpMonth}")
    ShopAgp selectByCondition(@Param("shopName") String shopName, @Param("agpMonth") String agpMonth);

    /**
     * agp设置详情
     *
     * @param shopId
     * @return
     */
    @Select("select * from db_shop_agp where agp_month= (select max(agp_month) from db_shop_agp where shop_id=#{shopId}) and shop_id=#{shopId}")
    ShopAgp detail(String shopId);
}

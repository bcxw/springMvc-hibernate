package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @author : chenxiang
 * @date : 2018/6/29
 */
@Getter
@Setter
@TableName("db_shop_data_mp")
public class ShopDataMp extends BaseModel<ShopDataMp> {
    /**
     * 导入人
     */
    private String userName;
    /**
     * 店铺名称
     */
    private String shopName;
    /**
     * 店铺id
     */
    private String shopId;
    /**
     * 统计日期
     */
    private Date dataDate;
    /**
     * /**
     * 手机端访客数
     */
    private int mpUv;
    /**
     * 手机端新访客数
     */
    private int mpNewUv;
    /**
     * 手机端老访客数
     */
    private int mpOldUv;
    /**
     * 手机端客单价
     */
    private float mpPct;

    /**
     * 手机端浏览量
     */
    private int mpPv;
    /**
     * 手机端新客浏览量
     */
    private int mpNewPv;
    /**
     * 手机端老客浏览量
     */
    private int mpOldPv;
    /**
     * 手机端下单金额
     */
    private float mpOrderMoney;
    /**
     * 手机端支付金额
     */
    private float mpPayMoney;
    /**
     * 手机端成交用户数
     */
    private int mpPayCustomers;
    /**
     * 手机端支付商品数
     */
    private int mpPayGoods;
    /**
     * 手机端支付转化率
     */
    private float mpPayConversion;
    /**
     * 手机端订单数量
     */
    private int mpOrderCount;

    /**
     * 手机端退款数量
     */
    private int mpRefundCount;
    /**
     * 手机端退款额
     */
    private float mpRefundAmount;
    /**
     * 手机端退款率
     */
    private float mpRefundMoneyRate;
    /**
     * 手机端退货率
     */
    private float mpRefundGoodsRate;
    /**
     * 手机端6日回访客数
     */
    private int mpSixBack;
}

package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.GoodsData;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author : chenxiang
 * @date : 2018/7/6
 */
@Mapper
public interface GoodsDataDao extends BaseMapper<GoodsData> {
    @Insert("<script>" +
            "insert into db_goods_data (id,user_name,user_id,shop_id,merchant_code,shop_name,data_date,goods_id,industry_type,title,url,pv,uv,transaction_number,entrance_number,exit_number,bounce_rate," +
            "avg_stay_time,collection_number,pay_money,pay_conversion,pay_goods,shopping_cart_customer_number,shopping_cart_goods_number,search_uv,refund_money,refund_count,refund_rate," +
            "old_uv,old_pay_money,old_pay_goods,old_transaction_number,old_pay_conversion)" +
            " values " +
            " <foreach collection=\"list\" item=\"i\" index=\"index\" separator=\",\" >" +
            " (#{i.id},#{i.userName},#{i.userId},#{i.shopId},#{i.merchantCode},#{i.shopName},#{i.dataDate},#{i.goodsId},#{i.industryType},#{i.title},#{i.url},#{i.pv},#{i.uv},#{i.transactionNumber},#{i.entranceNumber},#{i.exitNumber},#{i.bounceRate}," +
            " #{i.avgStayTime},#{i.collectionNumber},#{i.payMoney},#{i.payConversion},#{i.payGoods},#{i.shoppingCartCustomerNumber},#{i.shoppingCartGoodsNumber},#{i.searchUv},#{i.refundMoney},#{i.refundCount},#{i.refundRate}," +
            " #{i.oldUv},#{i.oldPayMoney},#{i.oldPayGoods},#{i.oldTransactionNumber},#{i.oldPayConversion}" +
            ")" +
            "</foreach>" +
            "  ON DUPLICATE KEY UPDATE " +
            " user_name=values(user_name),user_id=values(user_id),shop_id=values(shop_id),merchant_code=values(merchant_code),shop_name=values(shop_name),data_date=values(data_date),goods_id=values(goods_id),industry_type=values(industry_type),title=values(title),url=values(url),pv=values(pv),uv=values(uv),transaction_number=values(transaction_number),entrance_number=values(entrance_number),exit_number=values(exit_number),bounce_rate=values(bounce_rate)," +
            " avg_stay_time=values(avg_stay_time),collection_number=values(collection_number),pay_money=values(pay_money),pay_conversion=values(pay_conversion),pay_goods=values(pay_goods),shopping_cart_customer_number=values(shopping_cart_customer_number),shopping_cart_goods_number=values(shopping_cart_goods_number),search_uv=values(search_uv),refund_money=values(refund_money),refund_rate=values(refund_rate)," +
            " old_uv=values(old_uv),old_pay_money=values(old_pay_money),old_pay_goods=values(old_pay_goods),old_transaction_number=values(old_transaction_number),old_pay_conversion=values(old_pay_conversion)" +
            "</script>")
    void batchInsert(List<GoodsData> goodsDataList);


    /**
     * 查询平均销量
     *
     * @param paramMap
     * @return
     */
    @Select("select AVG(gd.pv) avgPv,AVG(gd.uv)avgUv,AVG(gd.pay_goods) avgPayGoods from db_goods_data gd LEFT JOIN db_goods_mapping gm on gd.goods_id=gm.shop_i_id where gm.sku_id=#{skuId} and " +
            " gd.data_date between #{beginTime} and #{endTime} ")
    Map<String, Object> selectResidueDays(Map<String, Object> paramMap);

    /**
     * 查询数据最早时间
     *
     * @return
     */
    @Select("select min(data_date) from db_goods_data where shop_id=#{shopId} and data_date between #{startTime} and #{endTime}")
    Date findMinDataDate(Map<String, Object> paramMap);

    /**
     * 查询最小数据时间到当前时间所有数据时间
     *
     * @param shopId
     * @param minDataDate
     * @param maxDataDate
     * @return
     */
    @Select("select data_date  from db_goods_data where shop_id=#{shopId} and data_date between #{minDataDate} and #{maxDataDate} group by data_date")
    List<Date> selectDataDateByShopId(@Param("shopId") String shopId, @Param("minDataDate") Date minDataDate, @Param("maxDataDate") Date maxDataDate);

    /**
     * 根据日期统计销售额和销量
     * @param goodsIds
     * @param dateStart
     * @param dateEnd
     * @return
     */
    @Select("<script>" +
            " select shop_id,goods_id,sum(pay_goods) pay_goods,sum(pay_money) pay_money from db_goods_data where 1=1" +
            " <if test=\"goodsIds!=null and goodsIds!=''\"> and goods_id in (#{goodsIds}) </if>" +
            " <if test=\"dateStart!=null and dateEnd!=null\"> and data_date between #{dateStart} and  #{dateEnd}</if>" +
            " group by shop_id,goods_id" +
            "</script>")
    List<GoodsData> amountByDate(@Param("goodsIds") String goodsIds,@Param("dateStart")Date dateStart,@Param("dateEnd")Date dateEnd);

}

package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @Auther: chenxiang
 * @Date: 2018/7/27/0027 09:30
 * @Description:
 */
@Getter
@Setter
@TableName("db_goods_keyword")
public class GoodsKeyword extends BaseModel<GoodsKeyword> {
    /**
     * 宝贝id
     */
    private String goodsId;
    /**
     * 宝贝标题
     */
    private String title;
    /**
     * 宝贝链接
     */
    private String url;
    /**
     * 搜索类型
     */
    private String searchType;
    /**
     * 关键词
     */
    private String keyWord;
    /**
     * 直接访客数
     */
    private int directUv;
    /**
     * 跳失率
     */
    private float bounceRate;
    /**
     * 直接销售量
     */
    private int directPayGoods;
    /**
     * 直接转化率
     */
    private float directPayConversion;
    /**
     * 间接销售量
     */
    private int indirectPayGoods;
    /**
     * 直接订单数
     */
    private int directOrderCount;
    /**
     * 导入人姓名
     */
    private String userName;
    /**
     * 导入人id
     */
    private String userId;

    /**
     * 店铺名称
     */
    private String shopName;

    /**
     * 店铺id
     */
    private String shopId;

    /**
     * 数据日期
     */
    private Date dataDate;
}

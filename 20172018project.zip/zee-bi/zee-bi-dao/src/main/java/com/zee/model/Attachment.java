package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;

/**
 * 基础数据
 */

@Getter
@Setter
@TableName("sys_attachment")
public class Attachment extends BaseModel<Attachment> {

    //附件名称
    private String name;
    //附件路径
    private String url;


}

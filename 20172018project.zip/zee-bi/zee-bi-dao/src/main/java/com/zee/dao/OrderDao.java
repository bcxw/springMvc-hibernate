package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.Order;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author : chenxiang
 * @date : 2018/6/25
 * 订单dao
 */
@Mapper
public interface OrderDao extends BaseMapper<Order> {
    /**
     * 批量插入/更新
     *
     * @param result
     */
    @Insert("<script>"
            + "insert into db_order (id,o_id,type,order_date,shop_buyer_id,shop_id,shop_site,so_id,amount,pay_amount,paid_amount,free_amount,discount_rate,question_type,question_desc,status,shop_status,invoice_title,modified,receiver_state,"
            + "receiver_city,receiver_district,receiver_zip,receiver_address,receiver_name,receiver_phone,receiver_mobile,buyer_message,freight,remark,send_date,is_cod,order_from,seller_can_rate,seller_rate)"
            + "values"
            + " <foreach collection=\"list\" item=\"item\" index=\"index\" separator=\",\" >"
            + "(#{item.id},#{item.oId},#{item.type},#{item.orderDate},#{item.shopBuyerId},#{item.shopId},#{item.shopSite},#{item.soId},#{item.amount},#{item.payAmount},#{item.paidAmount},#{item.freeAmount},#{item.discountRate},#{item.questionType},#{item.questionDesc},#{item.status},#{item.shopStatus},#{item.invoiceTitle},#{item.modified},#{item.receiverState}," +
            "#{item.receiverCity},#{item.receiverDistrict},#{item.receiverZip},#{item.receiverAddress},#{item.receiverName},#{item.receiverPhone},#{item.receiverMobile},#{item.buyerMessage},#{item.freight},#{item.remark},#{item.sendDate},#{item.isCod},#{item.orderFrom},#{item.sellerCanRate},#{item.sellerRate})"
            + "</foreach>"
            + "  ON DUPLICATE KEY UPDATE "
            + "o_id=values(o_id),type=values(type),order_date=values(order_date),shop_buyer_id=values(shop_buyer_id),shop_id=values(shop_id),shop_site=values(shop_site),so_id=values(so_id),amount=values(amount),pay_amount=values(pay_amount),paid_amount=values(paid_amount),free_amount=values(free_amount),discount_rate=values(discount_rate),question_type=values(question_type),question_desc=values(question_desc),status=values(status),shop_status=values(shop_status),invoice_title=values(invoice_title),modified=values(modified),receiver_state=values(receiver_state),"
            + "receiver_city=values(receiver_city),receiver_district=values(receiver_district),receiver_zip=values(receiver_zip),receiver_address=values(receiver_address),receiver_name=values(receiver_name),receiver_phone=values(receiver_phone),receiver_mobile=values(receiver_mobile),buyer_message=values(buyer_message),freight=values(freight),remark=values(remark),send_date=values(send_date),is_cod=values(is_cod),order_from=values(order_from),seller_can_rate=values(seller_can_rate),seller_rate=values(seller_rate)"
            + "</script>")
    void batchInsert(List<Order> result);
}

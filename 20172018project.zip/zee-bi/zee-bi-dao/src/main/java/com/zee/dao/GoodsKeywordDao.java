package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.GoodsKeyword;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Auther: chenxiang
 * @Date: 2018/7/27/0027 09:34
 * @Description:
 */
@Mapper
public interface GoodsKeywordDao extends BaseMapper<GoodsKeyword> {
    @Insert("<script>" +
            "insert into db_goods_keyword (id,user_name,user_id,shop_id,shop_name,data_date,goods_id," +
            " title,url,search_type,key_word,direct_uv,bounce_rate," +
            " direct_pay_goods,direct_pay_conversion,indirect_pay_goods,direct_order_count" +
            ")" +
            " values " +
            " <foreach collection=\"list\" item=\"i\" index=\"index\" separator=\",\" >" +
            " (#{i.id},#{i.userName},#{i.userId},#{i.shopId},#{i.shopName},#{i.dataDate},#{i.goodsId}," +
            " #{i.title},#{i.url},#{i.searchType},#{i.keyWord},#{i.directUv},#{i.bounceRate}," +
            " #{i.directPayGoods},#{i.directPayConversion},#{i.indirectPayGoods},#{i.directOrderCount}" +
            ")" +
            "</foreach>"
            +
            "  ON DUPLICATE KEY UPDATE " +
            " user_name=values(user_name),user_id=values(user_id),shop_id=values(shop_id),shop_name=values(shop_name),data_date=values(data_date),goods_id=values(goods_id)," +
            " title=values(title),url=values(url),search_type=values(search_type),key_word=values(key_word),direct_uv=values(direct_uv),bounce_rate=values(bounce_rate)," +
            " direct_pay_goods=values(direct_pay_goods),direct_pay_conversion=values(direct_pay_conversion),indirect_pay_goods=values(indirect_pay_goods),direct_order_count=values(direct_order_count)" +
            "</script>"
    )
    void batchInsert(List<GoodsKeyword> goodsKeywordList);


    /**
     * 查询数据最早时间
     *
     * @return
     */
    @Select("select min(data_date) from db_goods_keyword where shop_id=#{shopId} and data_date between #{startTime} and #{endTime}")
    Date findMinDataDate(Map<String, Object> paramMap);

    /**
     * 查询数据最小时间到当前时间的所有时间集合
     * @param shopId
     * @param minDataDate
     * @param maxDataDate
     * @return
     */
    @Select("select data_date from db_goods_keyword where shop_id=#{shopId} and data_date between #{minDataDate} and #{maxDataDate}")
    List<Date> selectDataDateByShopId(@Param("shopId") String shopId, @Param("minDataDate")Date minDataDate, @Param("maxDataDate")Date maxDataDate );
}

package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.QueryTime;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

/**
 * @author : chenxiang
 * @date : 2018/7/11
 */
@Mapper
public interface QueryTimeDao extends BaseMapper<QueryTime> {
    /**
     * 查询上次获取聚水潭数据的结束时间
     *
     * @param queryType
     * @return
     */
    @Select("select max(end_time) from db_query_time where query_type=#{queryType}")
    String selectLastTime(String queryType);
}

package com.zee.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.zee.model.ReturnGoodsItems;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * @author : chenxiang
 * @date : 2018/6/25
 * 退货退款子项dao
 */
@Mapper
public interface ReturnGoodsItemsDao extends BaseMapper<ReturnGoodsItems> {
    @Insert("<script>"
            + "insert into db_returngoods_items (id,as_id,asi_id,sku_id,qty,price,name,pic,type,properties_value,r_qty)"
            + "values"
            + " <foreach collection=\"list\" item=\"item\" index=\"index\" separator=\",\" >"
            + "(#{item.id},#{item.asId},#{item.asiId},#{item.skuId},#{item.qty},#{item.price},#{item.name},#{item.pic},#{item.type},#{item.propertiesValue},#{item.rQty})"
            + "</foreach>" +
            "</script>")
    void batchInsert(List<ReturnGoodsItems> rgiList);

    /**
     * count
     * @param paramMap
     * @return
     */
    @Select("<script>" +
            " select count(distinct gm.i_id) from db_returngoods_items ri,db_returngoods rg,db_goods_mapping gm" +
            " where ri.as_id=rg.as_id and ri.sku_id=gm.sku_id" +
            " <if test=\"dateStart!=null and dateStart!=''\"> and rg.as_date &gt;=DATE_FORMAT(#{dateStart},'%Y-%m-%d 00:00:00') </if>" +
            " <if test=\"dateEnd!=null and dateEnd!=''\"> and rg.as_date &lt;=DATE_FORMAT(#{dateEnd},'%Y-%m-%d 23:59:59') </if>" +
            " <if test=\"shopId!=null and shopId!=''\"> and rg.shop_id = #{shopId} </if>" +
            " <if test=\"sku!=null and sku!=''\"> and gm.i_id like concat('%',#{sku},'%')</if>" +
            " <if test=\"type!=null and type!=''\"> and rg.type like concat('%',#{type},'%')</if>" +
            " <if test=\"reason!=null and reason!=''\"> and rg.question_type like concat('%',#{reason},'%')</if>" +
            "</script>")
    int count(Map<String, Object> paramMap);

    /**
     * list
     * @param paramMap
     * @return
     */
    @Select("<script>" +
            "    select sb.shop_name shopName,gm.shop_i_id goods_id,rg.shop_id,gm.sku_id,gm.i_id sku,sum(ri.qty) refundNum,sum(ri.qty*ri.price) refundAmount,sum(if(length(rg.l_id) >1,ri.qty, 0)) refundNumSend ,sb.shop_name shopName" +
            "    from db_returngoods_items ri,db_returngoods rg,db_goods_mapping gm,db_shop_base sb" +
            "    where ri.as_id=rg.as_id and ri.sku_id=gm.sku_id and sb.shop_id=gm.shop_id" +
            "    <if test=\"dateStart!=null and dateStart!=''\"> and rg.as_date &gt;=DATE_FORMAT(#{dateStart},'%Y-%m-%d 00:00:00') </if>" +
            "    <if test=\"dateEnd!=null and dateEnd!=''\"> and rg.as_date &lt;=DATE_FORMAT(#{dateEnd},'%Y-%m-%d 23:59:59') </if>" +
            "    <if test=\"shopId!=null and shopId!=''\"> and rg.shop_id = #{shopId} </if>" +
            "    <if test=\"sku!=null and sku!=''\"> and ri.sku_id like concat('%',#{sku},'%')</if>" +
            "    <if test=\"type!=null and type!=''\"> and rg.type like concat('%',#{type},'%')</if>" +
            "    <if test=\"reason!=null and reason!=''\"> and rg.question_type like concat('%',#{reason},'%')</if>" +
            "    group by gm.shop_i_id " +
            "    order by refundNum desc" +
            "    limit ${start},${limit} " +
            "</script>")
    List<Map<String,Object>> list(Map<String, Object> paramMap);

}

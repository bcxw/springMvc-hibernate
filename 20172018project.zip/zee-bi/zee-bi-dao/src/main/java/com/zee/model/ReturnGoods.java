package com.zee.model;

import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Getter;
import lombok.Setter;


/**
 * @author : chenxiang
 * @date : 2018/6/25
 * 退款退货实体
 */
@Getter
@Setter
@TableName("db_returngoods")
public class ReturnGoods extends BaseModel<ReturnGoods> {
    /**
     * 售后单号
     */
    private long asId;
    /**
     * 登记时间
     */
    private String asDate;
    /**
     * 平台退货退款单号
     */
    private String outerAsId;
    /**
     * ERP内部订单号
     */
    private long oId;
    /**
     * 线上订单号
     */
    private String soId;
    /**
     * 售后类型（普通退货，换货等）
     */
    private String type;
    /**
     * 修改时间
     */
    private String modified;
    /**
     * 状态
     */
    private String status;
    /**
     * 货物状态
     */
    private String goodStatus;
    /**
     * 问题类型
     */
    private String questionType;
    /**
     * 仓库
     */
    private String warehouse;
    /**
     * 退款金额
     */
    private float refund;
    /**
     * 补偿金额
     */
    private float payment;
    /**
     * 买家账号
     */
    private String shopBuyerId;
    /**
     * 店铺编号
     */
    private String shopId;
    /**
     * 店铺名称
     */
    private String shopName;
    /**
     * 收件人
     */
    private String receiverName;
    /**
     * 物流公司
     */
    private String logisticsCompany;
    /**
     * 物流单号
     */
    private String lId;
}

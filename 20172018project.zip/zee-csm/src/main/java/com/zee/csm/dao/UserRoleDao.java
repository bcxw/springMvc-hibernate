package com.zee.csm.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.zee.csm.entity.Role;
import com.zee.csm.entity.UserRole;

public interface UserRoleDao {
	/**
	 * select * from auth_user_role where id = ? 
	 * @param id
	 * @return
	 */
	public UserRole findUserRoleById(Long id) ; 
	/**
	 * insert into auth_user_role(id,role_id,user_id) values (?,?,?) 
	 * @param id
	 * @return
	 */
	public void saveUserRole(UserRole userRole) ; 
	/**
	 * delete from auth_user_role where user_id = ? 
	 * @param id
	 * @return
	 */
	public void deleteByUserId(Long userId) ; 
	
	/**
	 * delete from auth_user_role where role_id = ? 
	 * @param id
	 * @return
	 */
	public void deleteByRoleIds(List<Long> delIds) ;
	/**
	 * select * from auth_user_role order by user_id limit ?,?
	 * @param id
	 * @return
	 */
	public List<UserRole> findUserRoles(@Param("page")int page, @Param("size")int size,@Param("userId")Long userId,@Param("roleId")Long roleId) ; 
	
	/**
	 * select * from auth_user_role where user_id = ? 
	 * @param id
	 * @return
	 */
	public List<UserRole> findUserRoleByUserId(Long userId) ; 
	
	/**
	 * insert into auth_user_role(user_id,role_id) values (?,?,?) 
	 * 批量保存,一个用户对应多个角色,给用户分配角色时，是一个多选
	 * @return
	 */
	public void saveUserRoles(List<UserRole> userRoles) ;
	/**
	 * 删除用户角色对应关系
	 * @param id
	 */
	public void deleteUserRoleById(Long id);
	/**
	 * 根据条件查询用户角色总数
	 * @param userId
	 * @param roleId
	 * @return
	 */
	public int getUserRoleRecordTotal(@Param("userId")Long userId, @Param("roleId")Long roleId);
	public void deleteByUserIds(List<Long> delIds);
	public void updateUserRoleByRole(Role role);
}

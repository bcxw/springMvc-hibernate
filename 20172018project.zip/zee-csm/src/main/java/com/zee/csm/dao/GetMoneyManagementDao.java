package com.zee.csm.dao;

import java.util.Date;
import java.util.List;

import com.zee.csm.entity.GetMoneyManagementOperation;
import org.apache.ibatis.annotations.Param;

import com.zee.csm.entity.GetMoneyManagement;

public interface GetMoneyManagementDao {
	
	/**
	 * 新增打款单
	 * @param getMoneyManagement
	 * @return
	 */
	public int insert(GetMoneyManagement getMoneyManagement);

	/**
	 * 插入历史记录
	 * @param getMoneyManagementHistory
	 * @return
	 */
	public int insertHistory(GetMoneyManagementOperation getMoneyManagementOperation);

	/**
	 * 修改打款单
	 * @param getMoneyManagement
	 * @return
	 */
	public int update(GetMoneyManagement getMoneyManagement);
	
	
	/**
	 * 查询打款单分页列表
	 * @param getMoneyManagement
	 * @param page
	 * @param size
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<GetMoneyManagement> getGetMoneyManagementPage(@Param("getMoneyManagement")GetMoneyManagement getMoneyManagement,@Param("page")Integer page,@Param("size")Integer size,@Param("startDate")Date startDate,@Param("endDate")Date endDate);
	
	
	/**
	 * 查询打款单总数
	 * @param getMoneyManagement
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public int getGetMoneyManagementTotal(@Param("getMoneyManagement")GetMoneyManagement getMoneyManagement,@Param("startDate")Date startDate,@Param("endDate")Date endDate);

	/**
	 * 查询收款单历史记录
	 * @param getMoneyId
	 * @return
	 */
	public List<GetMoneyManagementOperation> getGetMoneyManagementHistory(@Param("getMoneyId")Long getMoneyId);

	/**
	 * 获取收款单
	 * @param id
	 * @return
	 */
	public List<GetMoneyManagement> getGetMoneyManagement(@Param("id")Long id);
}

package com.zee.csm.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.zee.csm.common.CookieUtil;
import com.zee.csm.common.MD5Utils;
import com.zee.csm.entity.User;
import com.zee.csm.service.UserService;
import com.zee.framework.aspect.autolog.annotation.ZcyAutoLog;
import com.zee.framework.model.Result;
import com.zee.framework.util.ResultUtil;

@Controller
@RequestMapping("/user")
@ZcyAutoLog(module="用户管理",tag="UserController")
public class UserController {
	private static final Logger logger = LoggerFactory.getLogger(UserController.class) ;
	
	@Resource
	private UserService userService ; 
	/**
	 * 用户首页
	 * @return
	 */
	@RequestMapping(value="/index")
	public String userList(){
		logger.info(">>>>>>>>UserController userList");
		return "/security/user/userManage" ;
	}
	
	/**
	 * 新建,修改用户信息
	 * @param user
	 * @return
	 */
	@RequestMapping(value="/addEditUser",method=RequestMethod.POST)
	@ResponseBody
	public Result addEditUser(User user,Long supplierId,String supplierName,Long repertoryId,String repertoryName){
		logger.info(">>>>>>>>UserController addEditUser begin " + user);
		//MD5加密
		user.setPassword(MD5Utils.MD5(user.getPassword()));
		if(null == user.getId()){
			int count = userService.getUserByUserName(user.getUserName());
			if(count > 0){
				return ResultUtil.error(-1, "用户名已经存在") ;
			}
			userService.addUser(user);
		}else{
			userService.updateUser(user);
		}
		if(supplierId!=null&&supplierId>0){
			userService.addUserSupplier(user.getId(), supplierId,supplierName);
		}
		if(repertoryId!=null&&repertoryId>0){
			userService.addUserRepertory(user.getId(), repertoryId,repertoryName);
		}
		
		logger.info(">>>>>>>>UserController addEditUser end " + user);
		return ResultUtil.success() ;
	}
	/**
	 * 修改用户密码信息
	 * @param user
	 * @return
	 */
	@RequestMapping(value="/updateUserPassword",method=RequestMethod.POST)
	@ResponseBody
	public Result updateUserPassword(HttpServletRequest request , User user){
		logger.info(">>>>>>>>UserController updateUserPassword begin " + user);
		User oldUser = userService.getUser(user.getUserName(), MD5Utils.MD5(user.getPassword())) ;
		if(null == oldUser){
			return ResultUtil.error(-1,"用户名或密码输入错误！") ;//ResultUtil.passwordError() ;
		}
		user.setNewPassword(MD5Utils.MD5(user.getNewPassword()));
		userService.updateUserPassword(user);
		//更新cookie信息
		user.setPassword(MD5Utils.MD5(user.getNewPassword()));
		CookieUtil.setCookie(request, user);
		logger.info(">>>>>>>>UserController updateUserPassword end " + user);
		return ResultUtil.success() ;
	}
	/**
	 * 根据用户ID删除用户信息
	 * @param id
	 * @return
	 */
	@RequestMapping(value="/deleteUser",method=RequestMethod.POST)
	@ResponseBody
	public Result deleteUser(@RequestParam(value = "delIds[]")List<Long> delIds){
		logger.info(">>>>>>>>UserController deleteUser delIds " + delIds);
		userService.deleteUserByIds(delIds);
		return ResultUtil.success() ;
	}
	
	/**
	 * 分页按条件查询用户信息
	 * @param page
	 * @param size
	 * @return
	 */
	@RequestMapping(value="/getUsers",method = RequestMethod.POST,produces="text/json;charset=UTF-8")
	@ResponseBody
	public String getUsers(Integer page,Integer rows,String userName,Long roleId){
		logger.info(">>>>>>>>UserController getUsers userName " + userName + ">>>>roleId " + roleId);
		Map<String, Object> resultMap = new HashMap<String, Object>() ; 
		List<User> users = new ArrayList<User>() ;
		if(null == rows || null == page){
			users = userService.getUsers(0, 10,userName,roleId) ;
		}else{ //easyUI分页默认是从1开始
			users = userService.getUsers(page == 1 ? (page-1) : (page-1)*rows, rows,userName,roleId) ; 
		}
		resultMap.put("rows", users) ;
		resultMap.put("total", userService.getUserRecordTotal(userName,roleId)) ;
		return JSON.toJSONString(resultMap) ;
	}
}

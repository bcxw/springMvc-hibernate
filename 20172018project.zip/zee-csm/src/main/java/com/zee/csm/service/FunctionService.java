package com.zee.csm.service;

import java.util.List;

import com.zee.csm.dto.FunctionDTO;
import com.zee.csm.entity.Function;

public interface FunctionService {
	//增加功能菜单
	public void addFunction(Function function) ;
	//根据功能ID更新URL信息
	public void updateUrl(Long id,String url,Integer accordion,String name) ;
	//分页查询指定父节点的子节点集合
	public List<Function> getFunctions(int page,int size,Long parentId) ;
	//根据ID删除功能
	public void deleteFunctionById(Long id) ;
	//查询全部功能信息
	public List<Function> getAllFunctions() ;
	//根据ID查询功能信息
	public Function findFunctionById(Long id) ;
	
	public List<FunctionDTO> getAuthsByParentId(Long parentId, List<Long> functionIds);
	public List<FunctionDTO> getAllFunctionsByParentId(Long parentId);
	public void updateFunction(Function function);
	public boolean hasChildrenByParentId(Long parentId);
	public List<FunctionDTO> getCheckedByParentId(Long parentId, List<Long> functionIds);
}

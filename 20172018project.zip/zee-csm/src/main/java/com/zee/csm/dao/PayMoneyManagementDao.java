package com.zee.csm.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.zee.csm.entity.PayMoneyManagement;
import com.zee.csm.entity.PayMoneyManagementOperation;

public interface PayMoneyManagementDao {
	
	/**
	 * 新增打款单
	 * @param payMoneyManagement
	 * @return
	 */
	public int insert(PayMoneyManagement payMoneyManagement);
	
	/**
	 * 保存打款单历史快照
	 * @param payMoneyManagementHistory
	 * @return
	 */
	public int insertHistory(PayMoneyManagementOperation payMoneyManagementHistory);
	
	/**
	 * 修改打款单
	 * @param payMoneyManagement
	 * @return
	 */
	public int update(PayMoneyManagement payMoneyManagement);
	
	/**
	 * 查询是否存在给客户打过款
	 * @param payMoneyManagement
	 * @return
	 */
	public int existCustomId(PayMoneyManagement payMoneyManagement);
	
	/**
	 * 查询打款单分页列表
	 * @param payMoneyManagement
	 * @param page
	 * @param size
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<PayMoneyManagement> getPayMoneyManagementPage(@Param("payMoneyManagement")PayMoneyManagement payMoneyManagement,@Param("page")Integer page,@Param("size")Integer size,@Param("startDate")Date startDate,@Param("endDate")Date endDate);
	
	
	/**
	 * 查询打款单总数
	 * @param payMoneyManagement
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public int getPayMoneyManagementTotal(@Param("payMoneyManagement")PayMoneyManagement payMoneyManagement,@Param("startDate")Date startDate,@Param("endDate")Date endDate);
	
	/**
	 * 查询打款历史记录
	 * @param payMoneyId
	 * @return
	 */
	public List<PayMoneyManagementOperation> getPayMoneyManagementHistory(@Param("payMoneyId")Long payMoneyId);
	
	/**
	 * 关闭打款单
	 * @param payMoneyManagement
	 * @return
	 */
	public int updatePayMoneyManagementStatus(PayMoneyManagement payMoneyManagement);

	/**
	 * 关闭打款单
	 * @param payMoneyManagement
	 * @return
	 */
	public int closePayMoneyManagement(PayMoneyManagement payMoneyManagement);
	
	/**
	 * 获取打款单
	 * @param id
	 * @return
	 */
	public List<PayMoneyManagement> getPayMoneyManagement(@Param("id")Long id);
	
	/**
	 * 获取超时但是没有消息提醒的打款单
	 * @param date
	 * @return
	 */
	public List<PayMoneyManagement> getPayMoneyManagementOvertimeAndNoMessage(@Param("date")String date);
	
	/**
	 * 获取重复打款过的客户
	 * @return
	 */
	public List<Map<String,Object>> findRepetByCustomId();
	
}

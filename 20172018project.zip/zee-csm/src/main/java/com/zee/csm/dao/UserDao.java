package com.zee.csm.dao;

import java.util.Collection;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.zee.csm.entity.User;

public interface UserDao {
	//通过用户名和密码获得用户信息,用于登录
	/**
	 * @param name
	 * @param pwd
	 * @return
	 */
	public User findUser(@Param("name") String name,@Param("pwd") String pwd)  ;
	/**
	 * 通过UserId查询用户信息
	 * @param id
	 * @return
	 */
	public User getUser(Long id)  ;
	//根据ID删除用户信息
	/**
	 * delete from auth_user where id = ? 
	 * @param id
	 */
	public void deleteById(Long id)  ;
	//保存用户信息
	/**
	 * insert into auth_user(id,name,pwd)values(?,?,?)
	 * @param user
	 * @return
	 */
	public int save(User user) ; 
	//修改用户信息
	/**
	 * update auth_user set name = ? ,pwd = ? where id = ?
	 * @param user
	 * @return
	 */
	public int update(User user) ; 
	//根据ID查询用户信息
	/**
	 * select * from auth_user where id = ? 
	 * @param id
	 * @return
	 */
	public User findById(Long id) ; 
	//根据ID集合批量获取用户信息
	/**
	 * select * from auth_user where id in ()  
	 * @param ids
	 * @return
	 */
	public List<User> findUsersByIds(Collection<Long> ids) ; 
	//分页查询用户信息
	/**
	 * select * from auth_user limit ?,?
	 * @param page
	 * @param size
	 * @return
	 */
	public List<User> findUsers(@Param("page")int page, @Param("size")int size,@Param("name")String name,@Param("roleId")Long roleId) ; 
	/**
	 * select count(1) from auth_user
	 * @return
	 */
	public int getUserRecordTotal(@Param("name")String name,@Param("roleId")Long roleId) ;
	/**
	 * 查询所有用户列表
	 * @return
	 */
	public List<User> getAllUsers();
	
	public int getUserByUserName(String userName);
	public void deleteUserByIds(List<Long> delIds);
	public void updateUserPassword(User user);
	
	
	/**
	 * 删除用户对应供应商
	 * @param userId
	 * @return
	 */
	public int deleteUserSupplier(@Param("userId")Long userId);
	
	/**
	 * 删除用户对应仓库
	 * @param userId
	 * @return
	 */
	public int deleteUserRepertory(@Param("userId")Long userId);
	
	/**
	 * 添加用户对应供应商
	 * @param userId
	 * @param supplierId
	 * @return
	 */
	public int addUserSupplier(@Param("userId")Long userId,@Param("supplierId")Long supplierId,@Param("supplierName")String supplierName);
	
	/**
	 * 添加用户对应仓库
	 * @param userId
	 * @param repertoryId
	 * @return
	 */
	public int addUserRepertory(@Param("userId")Long userId,@Param("repertoryId")Long repertoryId,@Param("repertoryName")String repertoryName);
}

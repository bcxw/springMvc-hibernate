package com.zee.csm.context;

import com.zee.csm.entity.User;

public class UserContext {
	private static final ThreadLocal<User> tl = new ThreadLocal<User>() ;
 
	public static void setCurrentUser(User user){
		tl.set(user);
	}
	
	public static User getCurrentUser(){
		return tl.get() ;
	}
	 
}

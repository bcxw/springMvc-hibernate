package com.zee.csm.service;

import java.util.Date;
import java.util.List;

import com.zee.csm.entity.*;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.zee.csm.dto.GetMoneyManagementDTO;
import com.zee.csm.dto.PayMoneyManagementDTO;
import com.zee.framework.model.Result;

public interface GetmoneyManagementService {

	/**
	 * 保存打款单
	 * @param supplierDTO
	 * @return
	 */
	public Result saveGetmoneyManagement(GetMoneyManagementDTO getMoneyManagementDTO,User user);
	
	/**
	 * 获取打款单总数
	 * @param payMoneyManagementDTO
	 * @return
	 */
	public int getGetMoneyManagementTotal(GetMoneyManagementDTO getMoneyManagementDTO,Date startDate,Date endDate);
	
	/**
	 * 获取打款单分页
	 * @param payMoneyManagementDTO
	 * @param page
	 * @param size
	 * @return
	 */
	public List<GetMoneyManagement> getGetMoneyManagementPage(GetMoneyManagementDTO getMoneyManagementDTO,int page,int size,Date startDate,Date endDate);
	
	/**
	 * 导出excel 
	 * @param payMoneyManagementDTO
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public HSSFWorkbook exportGetMoneyManagement(GetMoneyManagementDTO getMoneyManagementDTO, Date startDate, Date endDate);

	public List<GetMoneyManagementOperation> getPayMoneyManagementHistory(Long getMoneyId);

}

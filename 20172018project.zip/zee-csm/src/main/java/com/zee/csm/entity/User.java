package com.zee.csm.entity;

import java.util.Arrays;

import com.zee.csm.common.BaseEntity;
/**
 * 用户信息
 * @author rygao
 */
public class User extends BaseEntity{
	private String userName ; 
	private String password ; 
	private String newPassword ;
	private Integer userType = 2 ;
	private Long roleId ; 
	private String roleName ; 
	private Integer status = 1 ;
	
	private String userDescription ;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	public Long getRoleId() {
		return roleId;
	}
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}
	
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getUserType() {
		return userType;
	}
	public void setUserType(Integer userType) {
		this.userType = userType;
	}
	
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getUserDescription() {
		return userDescription;
	}
	public void setUserDescription(String userDescription) {
		this.userDescription = userDescription;
	}
	
	
	@Override
	public String toString() {
		return "User [userName=" + userName + ", password=" + password + ", newPassword=" + newPassword + ", userType="
				+ userType + ", roleId=" + roleId + ", roleName=" + roleName + ", status=" + status + ", userDescription=" + userDescription + "]";
	}
}

package com.zee.csm.common;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public abstract class BaseEntity {
	private Long id ;
	private Date createTime ;
	private Date updateTime ;
	private int version;
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	} 
	
	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	
	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public static <T extends BaseEntity> Map<Long, T> idEntityMap(Collection<T> list){
		Map<Long, T> map = new HashMap<Long, T>() ; 
		if(null == list || 0 == list.size()){
			return map ; 
		}
		for (T entity : list) {
			map.put(entity.getId(), entity) ; 
		}
		return map ;
	}
}

package com.zee.csm.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import com.zee.csm.common.StringUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zee.csm.dao.ExpressExceptionDao;
import com.zee.csm.dto.ExpressExceptionDTO;
import com.zee.csm.entity.ExpressException;
import com.zee.csm.entity.ExpressExceptionOperation;
import com.zee.csm.entity.User;
import com.zee.csm.service.ExpressExceptionService;
import com.zee.framework.model.Result;
import com.zee.framework.util.ResultUtil;

@Service
public class ExpressExceptionServiceImpl implements ExpressExceptionService{
	
	private static final Logger logger = LoggerFactory.getLogger(ExpressExceptionServiceImpl.class) ;
	
	
	@Resource
	private ExpressExceptionDao expressExceptionDao;
	

	@Override
	@Transactional
	public Result saveExpressException(ExpressExceptionDTO expressExceptionDTO,User user,String isConfirm) {
		
		ExpressException expressException=new ExpressException();
		BeanUtils.copyProperties(expressExceptionDTO, expressException);
		
		expressException.setCreaterUserName(user.getUserName());
		expressException.setCreaterUserId(user.getId());
		expressException.setCreaterDate(new Date());
		
		ExpressExceptionOperation expressExceptionOperation=new ExpressExceptionOperation();
		
		if(StringUtil.isEmpty(expressExceptionDTO.getCustomId())){
			return ResultUtil.error(-2,"客户ID必须填写！");
		}
		
		//保存打款单
		if(expressExceptionDTO.getId()!=null&&expressExceptionDTO.getId()>0){
			
			expressExceptionOperation.setActionName("修改快递单");
			expressExceptionOperation.setActionCode("update");
			
			//找出修改的值
			String actionDescription="";
			List<ExpressException> expressExceptionList=expressExceptionDao.getExpressException(expressException.getId());
			ExpressException oldExpressException=expressExceptionList.get(0);
			if(!(expressException.getOrderNo()+"").equals(oldExpressException.getOrderNo()+"")){
				actionDescription+="订单编号："+oldExpressException.getOrderNo()+"->"+expressException.getOrderNo()+";";
			}
			if(!(expressException.getShopName()+"").equals(oldExpressException.getShopName()+"")){
				actionDescription+="店铺："+oldExpressException.getShopName()+"->"+expressException.getShopName()+";";
			}
			if(!(expressException.getTypeText()+"").equals(oldExpressException.getTypeText()+"")){
				actionDescription+="问题类型："+oldExpressException.getTypeText()+"->"+expressException.getTypeText()+";";
			}
			if(!(expressException.getCustomId()+"").equals(oldExpressException.getCustomId()+"")){
				actionDescription+="客户ID："+oldExpressException.getCustomId()+"->"+expressException.getCustomId()+";";
			}
			if(!(expressException.getExpressCompany()+"").equals(oldExpressException.getExpressCompany()+"")){
				actionDescription+="快递公司："+oldExpressException.getExpressCompany()+"->"+expressException.getExpressCompany()+";";
			}
			if(!(expressException.getExpressCode()+"").equals(oldExpressException.getExpressCode()+"")){
				actionDescription+="快递公司："+oldExpressException.getExpressCode()+"->"+expressException.getExpressCode()+";";
			}
			if(!(expressException.getDescription()+"").equals(oldExpressException.getDescription()+"")){
				actionDescription+="问题详情："+oldExpressException.getDescription()+"->"+expressException.getDescription()+";";
			}
			if(!(expressException.getStatusName()+"").equals(oldExpressException.getStatusName()+"")){
				actionDescription+="处理情况："+oldExpressException.getStatusName()+"->"+expressException.getStatusName()+";";
			}
			if(!(expressException.getPayMoney()+"").equals(oldExpressException.getPayMoney()+"")){
				actionDescription+="补偿金额："+oldExpressException.getPayMoney()+"->"+expressException.getPayMoney()+";";
			}
			SimpleDateFormat dateForamt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String newDate=expressException.getPayDate()!=null?dateForamt.format(expressException.getPayDate()):"";
			String oldDate=oldExpressException.getPayDate()!=null?dateForamt.format(oldExpressException.getPayDate()):"";
			if(!newDate.equals(oldDate)){
				actionDescription+="补偿日期："+oldDate+"->"+newDate+";";
			}
			if(!(expressException.getPayType()+"").equals(oldExpressException.getPayType()+"")){
				actionDescription+="补偿方式："+oldExpressException.getPayType()+"->"+expressException.getPayType()+";";
			}
			
			expressExceptionOperation.setActionDescription(actionDescription);
			
			expressExceptionDao.update(expressException);
		}else{
			
			//expressException.setStatusName("跟进中");
			//expressException.setStatusCode("10");
			//判断是否有过打款单需要进行确认
			if(!"1".equals(isConfirm)&&expressExceptionDao.existExpressCode(expressException)>0){
				return ResultUtil.error(-1, "此快递单号已经登记，是否要继续登记!");
			}
			
			expressExceptionDao.insert(expressException);
			expressExceptionOperation.setActionName("新增快递单");
			expressExceptionOperation.setActionCode("insert");
		}
		
		//保存打款单快照
		expressExceptionOperation.setExpressId(expressException.getId());
		expressExceptionOperation.setUserId(user.getId());
		expressExceptionOperation.setUserName(user.getUserName());
		expressExceptionOperation.setDate(new Date());
		expressExceptionDao.insertHistory(expressExceptionOperation);
		
		return ResultUtil.success(expressException);
	}
	

	@Override
	public int getExpressExceptionTotal(ExpressExceptionDTO expressExceptionDTO,Date startDate,Date endDate) {
		ExpressException expressException=new ExpressException();
		BeanUtils.copyProperties(expressExceptionDTO, expressException);
		return expressExceptionDao.getExpressExceptionTotal(expressException, startDate, endDate);
	}

	@Override
	public List<ExpressException> getExpressExceptionPage(ExpressExceptionDTO expressExceptionDTO,int page,int size,Date startDate,Date endDate) {
		ExpressException expressException=new ExpressException();
		BeanUtils.copyProperties(expressExceptionDTO, expressException);
		return expressExceptionDao.getExpressExceptionPage(expressException, page, size, startDate, endDate);
	}

	@Override
	public List<ExpressExceptionOperation> getExpressExceptionHistory(Long expressExceptionId) {
		return expressExceptionDao.getExpressExceptionHistory(expressExceptionId);
	}

	@Override
	public HSSFWorkbook exportExpressException(ExpressExceptionDTO expressExceptionDTO, Date startDate, Date endDate) {
		
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet=wb.createSheet("快递问题单");
		/*******表头*********/
		HSSFRow row0=sheet.createRow(0);
		row0.createCell(0).setCellValue("订单编号");
		row0.createCell(1).setCellValue("店铺名称");
		row0.createCell(2).setCellValue("客户ID");
		row0.createCell(3).setCellValue("快递公司");
		row0.createCell(4).setCellValue("快递单号");
		row0.createCell(5).setCellValue("问题类型");
		row0.createCell(6).setCellValue("问题详情");
		row0.createCell(7).setCellValue("处理情况");
		row0.createCell(8).setCellValue("补偿金额");
		row0.createCell(9).setCellValue("补偿日期");
		row0.createCell(10).setCellValue("补偿方式");
		row0.createCell(11).setCellValue("创建人");
		row0.createCell(12).setCellValue("创建日期");
		
		/**********内容***********/
		
		ExpressException expressException=new ExpressException();
		BeanUtils.copyProperties(expressExceptionDTO, expressException);
		List<ExpressException> expressExceptionList=expressExceptionDao.getExpressExceptionPage(expressException, null, null, startDate, endDate);
		
		for(int j=0;j<expressExceptionList.size();j++){
			ExpressException pm=expressExceptionList.get(j);
			HSSFRow row=sheet.createRow(j+1);
			if(pm.getOrderNo()!=null)row.createCell(0).setCellValue(pm.getOrderNo());
			if(pm.getShopName()!=null)row.createCell(1).setCellValue(pm.getShopName());
			if(pm.getCustomId()!=null)row.createCell(2).setCellValue(pm.getCustomId());
			if(pm.getExpressCompany()!=null)row.createCell(3).setCellValue(pm.getExpressCompany());
			if(pm.getExpressCode()!=null)row.createCell(4).setCellValue(pm.getExpressCode());
			if(pm.getTypeText()!=null)row.createCell(5).setCellValue(pm.getTypeText());
			if(pm.getDescription()!=null)row.createCell(6).setCellValue(pm.getDescription());
			if(pm.getStatusName()!=null)row.createCell(7).setCellValue(pm.getStatusName());
			if(pm.getPayMoney()!=null)row.createCell(8).setCellValue(pm.getPayMoney());
			if(pm.getPayDate()!=null)row.createCell(9).setCellValue(pm.getPayDate());
			if(pm.getPayType()!=null)row.createCell(10).setCellValue(pm.getPayType());
			if(pm.getCreaterUserName()!=null)row.createCell(11).setCellValue(pm.getCreaterUserName());
			if(pm.getCreaterDate()!=null)row.createCell(12).setCellValue(pm.getCreaterDate()!=null?sdf.format(pm.getCreaterDate()):"");
		}
		return wb;
	}

	/**
	 * 关闭快递问题单
	 *
	 * @param id
	 * @param user
	 * @return
	 */
	@Override
	public Result closeExpressException(Long id, User user,String closeReason) {
		expressExceptionDao.closeExpressException(id);

		ExpressExceptionOperation expressExceptionOperation=new ExpressExceptionOperation();
		expressExceptionOperation.setActionName("关闭快递单");
		expressExceptionOperation.setActionCode("close");
		expressExceptionOperation.setExpressId(id);
		expressExceptionOperation.setUserId(user.getId());
		expressExceptionOperation.setUserName(user.getUserName());
		expressExceptionOperation.setDate(new Date());
		expressExceptionOperation.setActionDescription(closeReason);
		expressExceptionDao.insertHistory(expressExceptionOperation);
		return ResultUtil.success("关闭快递问题单成功！");
	}
}

package com.zee.csm.entity;

import com.zee.csm.common.BaseEntity;
/**
 * 功能菜单信息表
 * @author rygao
 */
public class Function extends BaseEntity {
	private String functionName ; 
	private String functionPath ; 
	private Long parentId ;
	private String functionDescription ; 
	private String iconCls ; //显示easyUI图标
	public String getFunctionName() {
		return functionName;
	}
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}
	public String getFunctionPath() {
		return functionPath;
	}
	public void setFunctionPath(String functionPath) {
		this.functionPath = functionPath;
	}
	public Long getParentId() {
		return parentId;
	}
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	public String getFunctionDescription() {
		return functionDescription;
	}
	public void setFunctionDescription(String functionDescription) {
		this.functionDescription = functionDescription;
	}
	public String getIconCls() {
		return iconCls;
	}
	public void setIconCls(String iconCls) {
		this.iconCls = iconCls;
	}
	@Override
	public String toString() {
		return "Function [functionName=" + functionName + ", functionPath=" + functionPath + ", parentId=" + parentId
				+ ", functionDescription=" + functionDescription + ", iconCls=" + iconCls + "]";
	}
}

package com.zee.csm.context;

import java.io.IOException;
import java.util.Base64;
import java.util.Objects;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zee.csm.common.CookieUtil;
import com.zee.csm.entity.User;

public class UserContextFilter implements Filter {

	@Override
	public void destroy() {

	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
			throws IOException, ServletException {
		HttpServletResponse response = (HttpServletResponse)servletResponse ;
		HttpServletRequest request = (HttpServletRequest)servletRequest ; 
		ResponseContext.setCurrent(response);
		if(request.getRequestURI().contains("login")){
			Cookie cookie = new Cookie("auth", null) ;
			cookie.setMaxAge(0);
			response.addCookie(cookie);
			filterChain.doFilter(servletRequest, servletResponse);
			return ;
		}
		
		if(request.getRequestURI().contains("index.jsp")){
			filterChain.doFilter(servletRequest, servletResponse);
			return ;
		}
		
		if(request.getRequestURI().endsWith(".css") || request.getRequestURI().endsWith(".jpg")||request.getRequestURI().endsWith(".png")
				||request.getRequestURI().endsWith(".gif") ||request.getRequestURI().endsWith(".js")){
			filterChain.doFilter(servletRequest, servletResponse);
			return ;
		}
		String cookieValue = CookieUtil.getCookieValue(request) ;
		byte[] bytes = Base64.getDecoder().decode(cookieValue) ;
		String auth = new String(bytes) ;
		String[] array = auth.split("\\$") ;
		if(2==array.length){
			User user = LoginUserCache.get(array[0]) ;
			if(null == user){
				LoginUserHelper helper = WebApplicationContext.getBean(LoginUserHelper.class) ;
				helper.executeLogin(array[0],array[1]) ;
				user = LoginUserCache.get(array[0]) ;
			}
			if(null != user && Objects.equals(user.getPassword(), array[1])){
				LoginUserCache.put(user);
				UserContext.setCurrentUser(user);
				filterChain.doFilter(servletRequest, servletResponse);
				return ;
			}else{
				CookieUtil.delCookie(request);
				//response.sendRedirect("/csm/index.jsp");
				//return ;
			}
		}else{
			CookieUtil.delCookie(request);
		}
		filterChain.doFilter(servletRequest, servletResponse);
	}

	

	@Override
	public void init(FilterConfig arg0) throws ServletException {

	}

}

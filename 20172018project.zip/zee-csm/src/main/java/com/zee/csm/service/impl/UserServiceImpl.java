package com.zee.csm.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zee.csm.dao.UserDao;
import com.zee.csm.dao.UserRoleDao;
import com.zee.csm.entity.User;
import com.zee.csm.entity.UserRole;
import com.zee.csm.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	@Resource
	private UserDao userDao ;
	
	@Resource
	private UserRoleDao userRoleDao ;
	
	@Override
	@Transactional
	public void addUser(User user) {
		userDao.save(user) ;
		//保存用户,角色关系
		UserRole ur = new UserRole() ; 
		ur.setUserId(user.getId());
		ur.setUserName(user.getUserName());
		ur.setRoleId(user.getRoleId());
		ur.setRoleName(user.getRoleName()); 
		userRoleDao.saveUserRole(ur);
		//保存用户,店铺关系
		/*List<UserShop> userShopList = new ArrayList<UserShop>();
		String[] shopInfos = user.getShopInfos() ; 
		if(null != shopInfos){
			for (String str : shopInfos) {
				String[] shopinfo = str.split(":") ; 
				UserShop userShop = new UserShop() ;
				userShop.setShopId(Long.valueOf(shopinfo[0]));
				userShop.setShopName(shopinfo[1]);
				userShop.setUserId(user.getId());
				userShop.setUserName(user.getUserName());
				userShopList.add(userShop) ; 
			}
		}
		userShopDao.saveUserShop(userShopList);*/
	}
	
	@Override
	@Transactional
	public void updateUser(User user) {
		userRoleDao.deleteByUserId(user.getId());
		userDao.update(user) ;
		UserRole ur = new UserRole() ; 
		ur.setUserId(user.getId());
		ur.setUserName(user.getUserName());
		ur.setRoleId(user.getRoleId());
		ur.setRoleName(user.getRoleName()); 
		userRoleDao.saveUserRole(ur);
		//修改用户关联店铺
		//userShopDao.deleteUserShopByUserId(user.getId());
		//保存用户,店铺关系
		/*List<UserShop> userShopList = new ArrayList<UserShop>();
		String[] shopInfos = user.getShopInfos() ; 
		if(null != shopInfos){
			for (String str : shopInfos) {
				String[] shopinfo = str.split(":") ; 
				UserShop userShop = new UserShop() ;
				userShop.setShopId(Long.valueOf(shopinfo[0]));
				userShop.setShopName(shopinfo[1]);
				userShop.setUserId(user.getId());
				userShop.setUserName(user.getUserName());
				userShopList.add(userShop) ; 
			}
		}
		userShopDao.saveUserShop(userShopList);*/
	}
	
	
	@Override
	@Transactional
	public void deleteUserById(Long id) {
		userDao.deleteById(id);
		userRoleDao.deleteByUserId(id);
		
	}
	@Override
	public User getUser(String name, String pwd) {
		return userDao.findUser(name, pwd);
	}
	@Override
	public User getUser(Long id) {
		return userDao.getUser(id);
	}
	@Override
	public List<User> getUsers(int page, int size,String name,Long roleId) {
		List<User> users = userDao.findUsers(page, size,name,roleId);
		/*for (User u : users) {
			List<UserShop> userShopList = userShopDao.findUserShopByUserId(u.getId()) ;
			if(null != userShopList && userShopList.size() > 0){
				String[] shopInfos = new String[userShopList.size()] ;
				String[] shopNames = new String[userShopList.size()] ;
				for (int i = 0; i < userShopList.size(); i++) {
					shopNames[i] = userShopList.get(i).getShopName() ; 
					shopInfos[i] = userShopList.get(i).getId() +":" +userShopList.get(i).getShopName() ; 
				}
				u.setShopInfos(shopInfos);
				u.setShopNames(shopNames);
			}
		}*/
		return users;
	}
	
	@Override
	public int getUserRecordTotal(String name,Long roleId) {
		return userDao.getUserRecordTotal(name,roleId) ;
	}
	
	@Override
	public List<User> getUsers(Collection<Long> ids) {
		return userDao.findUsersByIds(ids);
	}
	
	@Override
	public List<UserRole> getUserRoles(int page, int size,Long userId,Long roleId) {
		return userRoleDao.findUserRoles(page, size,userId,roleId);
	}
	
	@Override
	public List<UserRole> getUserRolesByUserId(Long userId) {
		return userRoleDao.findUserRoleByUserId(userId) ;
	}
	
	@Override
	@Transactional
	public void addUserRoles(Long userId, Long[] roleIds) {
		userRoleDao.deleteByUserId(userId);
		List<UserRole> userRoles = new ArrayList<UserRole>() ;
		Arrays.asList(roleIds).forEach((roleId) ->{
				UserRole userRole = new UserRole() ;
				userRole.setRoleId(roleId);
				userRole.setUserId(userId);
				userRoles.add(userRole) ;
		});
		userRoleDao.saveUserRoles(userRoles);
	}
	
	@Override
	@Transactional
	public void deleteUserRoleById(Long id) {
		userRoleDao.deleteUserRoleById(id);
	}
	
	@Override
	public List<User> getAllUsers() {
		return userDao.getAllUsers();
	}
	
	@Override
	public int getUserRoleRecordTotal(Long userId, Long roleId) {
		return userRoleDao.getUserRoleRecordTotal(userId, roleId);
	}
	
	@Override
	public int getUserByUserName(String userName) {
		return userDao.getUserByUserName(userName);
	}

	@Override
	@Transactional
	public void deleteUserByIds(List<Long> delIds) {
		userDao.deleteUserByIds(delIds);
		userRoleDao.deleteByUserIds(delIds);
		//userShopDao.deleteUserShopByUserIds(delIds);
	}

	@Override
	public void updateUserPassword(User user) {
		userDao.updateUserPassword(user) ; 
	}

	@Override
	@Transactional
	public int addUserSupplier(Long userId,Long supplierId,String supplierName) {
		userDao.deleteUserSupplier(userId);
		return userDao.addUserSupplier(userId, supplierId,supplierName);
	}

	@Override
	@Transactional
	public int addUserRepertory(Long userId,Long repertoryId,String repertoryName) {
		userDao.deleteUserRepertory(userId);
		return userDao.addUserRepertory(userId, repertoryId,repertoryName);
	}
}

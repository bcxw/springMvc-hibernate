package com.zee.csm.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.zee.csm.common.BaseEntity;
import com.zee.csm.context.UserContext;
import com.zee.csm.dto.Authorize;
import com.zee.csm.dto.FunctionDTO;
import com.zee.csm.dto.RoleDTO;
import com.zee.csm.entity.Role;
import com.zee.csm.entity.RoleFunction;
import com.zee.csm.entity.User;
import com.zee.csm.entity.UserRole;
import com.zee.csm.service.FunctionService;
import com.zee.csm.service.RoleService;
import com.zee.csm.service.UserService;
import com.zee.framework.model.Result;
import com.zee.framework.util.ResultUtil;
@Controller
@RequestMapping("/authorize")
public class RoleAuthorizeController {
	private static final Logger logger = LoggerFactory.getLogger(RoleAuthorizeController.class) ;
	@Resource
	private UserService userService ; 
	
	@Resource
	private RoleService roleService ; 
	
	@Resource
	private FunctionService functionService ; 
	
	
	@RequestMapping(value="/menu",method=RequestMethod.POST,produces="text/json;charset=UTF-8")
	@ResponseBody
	public String menu(HttpServletRequest request,Long parentId){
		logger.info(">>>>>>>>>>RoleAuthorizeController menu begin parentId : " + parentId);
		User currentUser = UserContext.getCurrentUser() ;
		logger.info(">>>>>>>>>>RoleAuthorizeController menu currentUser : " + currentUser);
		if(null != currentUser){
			List<UserRole> userRoleList = userService.getUserRolesByUserId(currentUser.getId()) ;
			List<Long> ids = new ArrayList<Long>() ;	
			userRoleList.forEach((ur)->{
				ids.add(ur.getRoleId()) ;
			});
			//获得用户权限
			List<RoleFunction> roleFunctionList = roleService.getRoleFunctionsByRoleIds(ids) ;
			List<Long> functionIds = new ArrayList<Long>() ;
			roleFunctionList.forEach((rf)->{
				functionIds.add(rf.getFunctionId()) ;
			});
			List<FunctionDTO> functionDTOList = functionService.getAuthsByParentId(parentId,functionIds) ;
			return JSON.toJSONString(functionDTOList) ;
		}
		logger.info(">>>>>>>>>>RoleAuthorizeController menu end :");
		return "/security/login" ;
	}
	
	@RequestMapping(value="/roleFunctions",method=RequestMethod.POST,produces="text/json;charset=UTF-8")
	@ResponseBody
	public String roleFunctions(Long parentId,Long roleId){
		logger.info(">>>>>>>>>>RoleAuthorizeController roleFunctions begin parentId:" + parentId + ">>>> roleId" + roleId);
		List<RoleFunction> roleFunctionList = roleService.getRoleFunctions(roleId) ;
		List<Long> functionIds = new ArrayList<Long>() ;
		roleFunctionList.forEach((rf)->{
			functionIds.add(rf.getFunctionId()) ;
		});
		List<FunctionDTO> functionDTOList = functionService.getCheckedByParentId(parentId,functionIds) ;
		logger.info(">>>>>>>>>>RoleAuthorizeController roleFunctions end functionDTOList:" + functionDTOList );
		return JSON.toJSONString(functionDTOList) ;
	}
	
	@RequestMapping(value="/setRoleFunctions",method = RequestMethod.POST)
	@ResponseBody
	public Result setRoleFunctions(Long roleId , @RequestParam(value = "functionIds[]")List<Long> functionIds){
		logger.info(">>>>>>>>>>RoleAuthorizeController setRoleFunctions begin roleId:" + roleId + ">>>>>> functionIds: " + functionIds);
		if(null != functionIds){
			roleService.setRoleFunctions(roleId, functionIds);
		}
		return ResultUtil.success() ;
	}
	
	/**
	 * 用户角色对应关系首页
	 * @return
	 */
	@RequestMapping("/userRole")
	public String authorizeIndex(Model model){
		logger.info(">>>>>>>>>>RoleAuthorizeController authorizeIndex begin ");
		//查询所有的用户
		List<User> users = userService.getAllUsers() ; 
		//查询所有角色
		List<Role> roles = roleService.getAllRoles() ;
		model.addAttribute("users", users) ;
		model.addAttribute("roles", roles) ;
		logger.info(">>>>>>>>>>RoleAuthorizeController authorizeIndex end ");
		return "/security/authorize/user_role_list" ;
	}
	/**
	 * 查询权限信息
	 * @param page
	 * @param size
	 * @return
	 */
	@RequestMapping(value="/getAuthorizes",method=RequestMethod.POST,produces="text/json;charset=UTF-8")
	@ResponseBody
	public String getAuthorizes(Integer page,Integer rows,Long userId,Long roleId){
		logger.info(">>>>>>>>>>RoleAuthorizeController getAuthorizes begin userId:" + userId+ ">>> roleId:" + roleId);
		Map<String, Object> resultMap = new HashMap<String, Object>() ; 
		List<UserRole> userRoles = new ArrayList<UserRole>() ;
		if(null == rows || null == page){
			userRoles = userService.getUserRoles(0, 10,userId,roleId) ;
		}else{ //easyUI分页默认是从1开始
			userRoles = userService.getUserRoles(page == 1 ? (page-1) : (page-1)*rows, rows,userId,roleId) ; 
		}
		logger.info(">>>>>>>>>>RoleAuthorizeController getAuthorizes begin userRoles:" + userRoles);
		List<Authorize> authorizes = new LinkedList<Authorize>() ;
		if(userRoles.size() > 0){
			List<Long> userIds = new ArrayList<Long>() ;
			List<Long> roleIds = new ArrayList<Long>() ;
			userRoles.forEach((ur) -> {
					userIds.add(ur.getUserId());
					roleIds.add(ur.getRoleId());
			});
			List<User> users = userService.getUsers(userIds) ;
			List<Role> roles = roleService.getRoles(roleIds) ;
			Map<Long, User> userMap = BaseEntity.idEntityMap(users) ;
			Map<Long, Role> roleMap = BaseEntity.idEntityMap(roles) ;
			
			
			userRoles.forEach((ur) -> {
				Authorize authorize = new Authorize() ;
				authorize.setUserRoleId(ur.getId());
				authorize.setUserId(ur.getUserId());
				authorize.setUserName(userMap.get(ur.getUserId()).getUserName());
				authorize.setRoleId(ur.getRoleId());
				authorize.setRoleName(roleMap.get(ur.getRoleId()).getRoleName());
				authorizes.add(authorize) ;
			});
		}
		resultMap.put("rows", authorizes) ;
		resultMap.put("total", userService.getUserRoleRecordTotal(userId,roleId)) ; 
		logger.info(">>>>>>>>>>RoleAuthorizeController getAuthorizes end ");
		return JSON.toJSONString(resultMap) ;
	}
	/**
	 * 根据用户ID查询用户角色对应关系
	 * @param userId
	 * @return
	 */
	@RequestMapping(value="/getUserRoleByUserId",method = RequestMethod.POST,produces="text/json;charset=UTF-8")
	@ResponseBody
	public String getUserRoleByUserId(Long userId){
		logger.info(">>>>>>>>>>RoleAuthorizeController getUserRoleByUserId begin userId: " + userId);
		Map<String, Object> map = new HashMap<String, Object>() ;
		//当前用户所拥有的角色
		List<Authorize> authorizes = new ArrayList<Authorize>();
		List<UserRole> userRoles = userService.getUserRolesByUserId(userId) ;
		User user = userService.getUser(userId) ; 
		for (UserRole ur : userRoles) {
			Authorize authorize = new Authorize() ;
			Role role = roleService.getRoleById(ur.getRoleId()) ;
			authorize.setRoleId(role.getId());
			authorize.setRoleName(role.getRoleName());
			authorize.setUserId(user.getId());
			authorize.setUserName(user.getUserName());
			authorize.setUserRoleId(ur.getId());
			authorizes.add(authorize) ;
		}
		map.put("user", user) ;
		map.put("authorizes", authorizes) ; 
		logger.info(">>>>>>>>>>RoleAuthorizeController getUserRoleByUserId end ");
		return JSON.toJSONString(map);
	}
	
	
	@RequestMapping(value="/getAllRoles",method = RequestMethod.POST,produces="text/json;charset=UTF-8")
	@ResponseBody
	public String getAllRoles(){
		logger.info(">>>>>>>>>>RoleAuthorizeController getAllRoles begin ");
		List<RoleDTO> roleDTOS = new ArrayList<RoleDTO>() ;
		List<Role> allRoles = roleService.getAllRoles() ;
		allRoles.forEach((role)->{
			RoleDTO roleDTO = new RoleDTO() ;
			roleDTO.setId(role.getId());
			roleDTO.setText(role.getRoleName());
			roleDTOS.add(roleDTO) ;
		});
		logger.info(">>>>>>>>>>RoleAuthorizeController getAllRoles end ");
		return JSON.toJSONString(roleDTOS);
	}
	
	@RequestMapping(value="/setAuthorize",method = RequestMethod.POST)
	@ResponseBody
	public Result setAuthorize(User user , String roleIds){
		logger.info(">>>>>>>>>>RoleAuthorizeController setAuthorize begin user: " + user+ " >>>>>> roleIds:" + roleIds);
		String[] temp = roleIds.split(",") ;
		if(1==temp.length && (null == temp[0] || "".equals(temp[0]))){
			return ResultUtil.success() ;
		}
		Long[] roleArray = new Long[temp.length] ;
		for (int i = 0; i < roleArray.length; i++) {
			roleArray[i] = Long.valueOf(temp[i]);
		}
		userService.addUserRoles(user.getId(), roleArray);
		logger.info(">>>>>>>>>>RoleAuthorizeController setAuthorize end roleArray: " + roleArray);
		return ResultUtil.success() ;
	}
	
	/**
	 * 根据用户ID删除用户信息
	 * @param id
	 * @return
	 */
	@RequestMapping(value="/deleteUserRole",method=RequestMethod.POST)
	@ResponseBody
	public Result deleteUserRole(Long id){
		logger.info(">>>>>>>>>>RoleAuthorizeController deleteUserRole begin id: " + id);
		userService.deleteUserRoleById(id);
		return ResultUtil.success() ;
	}
}


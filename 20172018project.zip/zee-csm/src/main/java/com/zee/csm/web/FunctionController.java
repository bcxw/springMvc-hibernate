package com.zee.csm.web;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.zee.csm.context.NativeCache;
import com.zee.csm.dto.FunctionDTO;
import com.zee.csm.entity.Function;
import com.zee.csm.service.FunctionService;
import com.zee.framework.model.Result;
import com.zee.framework.util.ResultUtil;

@Controller
@RequestMapping("/functionAuth")
public class FunctionController {
	private static final Logger logger = LoggerFactory.getLogger(FunctionController.class);
	@Resource
	private FunctionService functionService ;
	
	@Resource
	private NativeCache nativeCache ;
	
	@RequestMapping("/index")
	public String index(HttpServletRequest request){
		logger.info(">>>>>>>>FunctionController index begin ");
		return "/security/function/functionManage" ;
	}
	
	/**
	 * 新增,修改功能
	 * @param function
	 * @return
	 */
	@RequestMapping(value="/addEditFunction",method=RequestMethod.POST)
	@ResponseBody
	public Result addEditFunction(Function function){
		logger.info(">>>>>>>>FunctionController addEditFunction begin: " + function);
		if(null == function.getId()){
			functionService.addFunction(function);
			nativeCache.addFunction(function);
		}else{
			functionService.updateFunction(function);
			nativeCache.replaceFunction(function);
		}
		logger.info(">>>>>>>>FunctionController addEditFunction end: " + function);
		return ResultUtil.success() ;
	}
	
	/**
	 * 根据功能ID删除功能信息
	 * @param id
	 * @return
	 */
	@RequestMapping(value="/deleteFunction",method=RequestMethod.POST)
	@ResponseBody
	public Result deleteFunction(Long id,Long parentId){
		logger.info(">>>>>>>>FunctionController deleteFunction begin id:" + id + " >>>> parentId : " + parentId);
		boolean flag = functionService.hasChildrenByParentId(id) ;
		if(flag){
			//return ResultUtil.hasLeaf() ;
		}else{
			functionService.deleteFunctionById(id);
			nativeCache.removeFunction(id,parentId);
		}
		logger.info(">>>>>>>>FunctionController deleteFunction end id:" + id + " >>>> parentId : " + parentId);
		return ResultUtil.success() ;
	}
	
	/**
	 * 查询所有功能信息
	 * @param parentId
	 * @return
	 */
	@RequestMapping(value="/getAllFunctions",method = RequestMethod.POST,produces="text/json;charset=UTF-8")
	@ResponseBody
	public String getAllFunctions(Long parentId){
		logger.info(">>>>>>>>FunctionController getAllFunctions begin parentId : " + parentId);
		if(Objects.equals(null, parentId)){
			parentId = -1L ;
		}
		List<FunctionDTO> functionDTOs = new ArrayList<FunctionDTO>();
		functionDTOs = functionService.getAllFunctionsByParentId(parentId) ;
		logger.info(">>>>>>>>FunctionController getAllFunctions end parentId : " + parentId);
		return JSON.toJSONString(functionDTOs) ;
	}
}

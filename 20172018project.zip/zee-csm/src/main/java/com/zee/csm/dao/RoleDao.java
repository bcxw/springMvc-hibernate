package com.zee.csm.dao;

import java.util.Collection;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.zee.csm.entity.Role;

public interface RoleDao {
	/**
	 * delete from auth_role where id = ? 
	 * @param id
	 */
	public void deleteByIds(List<Long> delIds)  ;
	/**
	 * insert into auth_role(id,name,pwd)values(?,?,?)
	 * @return
	 */
	public int save(Role role) ; 
	/**
	 * update auth_role set name = ? ,pwd = ? where id = ?
	 * @return
	 */
	public int update(Role role) ; 
	/**
	 * select * from auth_role where id = ? 
	 * @param id
	 * @return
	 */
	public Role findById(Long id) ; 
	/**
	 * select * from auth_role where id in ()  
	 * @param ids
	 * @return
	 */
	public List<Role> findByIds(Collection<Long> ids) ; 
	/**
	 * select * from auth_role limit ?,?
	 * @param page
	 * @param size
	 * @return
	 */
	public List<Role> findRoles(@Param("page")int page, @Param("size")int size,@Param("name")String name) ;
	/**
	 * 查询角色总数
	 * @return
	 */
	public int getRoleRecordTotal(@Param("name")String name);
	/**
	 * 根据ID查询角色
	 * @param id
	 * @return
	 */
	public Role getRoleById(Long id);
	/**
	 * 查询所有角色信息
	 * @return
	 */
	public List<Role> getAllRoles();
	public String getRoleNameById(Long id); 
}

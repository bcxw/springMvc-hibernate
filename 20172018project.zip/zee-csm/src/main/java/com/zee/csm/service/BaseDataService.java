package com.zee.csm.service;

import java.util.List;
import java.util.Map;

import com.zee.csm.dto.BaseDataCategoryDTO;
import com.zee.csm.dto.BaseDataItemsDTO;
import com.zee.csm.entity.BaseDataItems;

public interface BaseDataService {
	
	/**
	 * 按父类id获取子分类
	 * @param parentId
	 * @return
	 */
	public List<Map<String,Object>> getBaseDataCategoryByParentId(Long parentId);
	
	/**
	 * 根据分类查询数据项
	 * @param parentId
	 * @return
	 */
	public List<BaseDataItemsDTO> getBaseDataItemsByParentId(Long parentId);
	
	/**
	 * 保存基础数据分类
	 * @param baseDataCategoryDTO
	 * @return
	 */
	public Map<String,Object> saveBaseDataCategory(BaseDataCategoryDTO baseDataCategoryDTO);
	
	/**
	 * 删除分类
	 * @param id
	 * @return
	 */
	public Map<String,Object> deleteBaseDataCategory(Long id);
	
	
	/**
	 * 保存基础数据数据项
	 * @param baseDataCategoryDTO
	 * @return
	 */
	public Map<String,Object> saveBaseDataItem(BaseDataItemsDTO baseDataItemsDTO);
	
	/**
	 * 删除分类数据
	 * @param id
	 * @return
	 */
	public Map<String,Object> deleteBaseDataItem(Long id);
	
	/**
	 * 根据父类编码获取数据选项
	 * @param code
	 * @return
	 */
	public List<Map<String, Object>> getBaseDataItemByParentCode(String parentCode);
	
	/**
	 * 根据父类编码获取子类
	 * @param parentCode
	 * @return
	 */
	public List<Map<String, Object>> getBaseDataCategoryAndItemByParentCode(String parentCode);
	
}

package com.zee.csm.service;

public interface MessageService {
	
	/**
	 * 打款超时消息类型
	 */
	public final static String MESSAGE_TYPE_PAYMONEY_OVERTIME ="MESSAGE_TYPE_PAYMONEY_OVERTIME";
		
	/**
	 * 按类型和dataid关闭消息
	 * @param type
	 * @param dataId
	 */
	public void closeMessageStatusByTypeAndDataId(String type,String dataId);
	
	
}

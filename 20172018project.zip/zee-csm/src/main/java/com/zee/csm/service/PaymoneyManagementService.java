package com.zee.csm.service;

import java.util.Date;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.zee.csm.dto.PayMoneyManagementDTO;
import com.zee.csm.entity.PayMoneyManagement;
import com.zee.csm.entity.PayMoneyManagementOperation;
import com.zee.csm.entity.User;
import com.zee.framework.model.Result;

public interface PaymoneyManagementService {

	/**
	 * 保存打款单
	 * @param supplierDTO
	 * @return
	 */
	public Result savePaymoneyManagement(PayMoneyManagementDTO payMoneyManagementDTO,User user,String isConfirm);
	
	/**
	 * 获取打款单总数
	 * @param payMoneyManagementDTO
	 * @return
	 */
	public int getPayMoneyManagementTotal(PayMoneyManagementDTO payMoneyManagementDTO,Date startDate,Date endDate);
	
	/**
	 * 获取打款单分页
	 * @param payMoneyManagementDTO
	 * @param page
	 * @param size
	 * @return
	 */
	public List<PayMoneyManagement> getPayMoneyManagementPage(PayMoneyManagementDTO payMoneyManagementDTO,int page,int size,Date startDate,Date endDate);
	
	
	/**
	 * 获取打款单历史记录
	 * @param id
	 * @return
	 */
	public List<PayMoneyManagementOperation> getPayMoneyManagementHistory(Long payMoneyId);
	
	/**
	 * 关闭打款单
	 * @param id
	 * @return
	 */
	public Result closePayMoneyManagement(Long id,String closeReason,User user);
	
	/**
	 * 进行打款操作
	 * @param id
	 * @param user
	 * @return
	 */
	public Result toPayMoney(Long id,User user);
	
	/**
	 * 是否拥有打款权限
	 * @param userId
	 * @return
	 */
	public boolean canPayMoney(Long userId);
	
	/**
	 * 获取超时的打款消息
	 * @param user
	 * @return
	 */
	public Result getPayMoneyOverTimeMessage(User user);
	
	/**
	 * 导出excel 
	 * @param payMoneyManagementDTO
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public HSSFWorkbook exportPayMoneyManagement(PayMoneyManagementDTO payMoneyManagementDTO, Date startDate, Date endDate);
	
}

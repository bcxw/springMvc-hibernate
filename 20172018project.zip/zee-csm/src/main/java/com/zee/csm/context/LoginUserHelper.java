package com.zee.csm.context;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.zee.csm.entity.User;
import com.zee.csm.service.RoleService;
import com.zee.csm.service.UserService;

@Component
public class LoginUserHelper {
	@Resource
	private UserService userService ;
	@Resource
	private RoleService roleService ;
	
	public void executeLogin(String userName, String pwd) {
		User user = userService.getUser(userName, pwd) ;
		//TODO 用户角色缓存信息,如果使用该缓存则在添加,修改,删除用户角色时需要维护暂时没性能影响,以后在考虑完善!
		/*List<UserRole> userRoles = userService.getUserRolesByUserId(user.getId()) ;
		if(null == userRoles || 0 == userRoles.size()){
			return ;
		}
		List<Long> roleIds = new ArrayList<Long>() ;
		for (UserRole ur : userRoles) {
			roleIds.add(ur.getRoleId()) ;
		}
		List<Role> roles = roleService.getRoles(roleIds) ;
		nativeCache.setRoles(user.getId(), roles);*/
		if(null != user){
			LoginUserCache.put(user);
		}
	}
}

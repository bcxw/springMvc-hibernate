package com.zee.csm.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zee.csm.dao.RoleDao;
import com.zee.csm.dao.RoleFunctionDao;
import com.zee.csm.dao.UserRoleDao;
import com.zee.csm.entity.Role;
import com.zee.csm.entity.RoleFunction;
import com.zee.csm.service.RoleService;

@Service
public class RoleServiceImpl implements RoleService {
	@Resource
	private RoleDao roleDao ;
	
	@Resource
	private RoleFunctionDao roleFunctionDao ;
	
	@Resource
	private UserRoleDao userRoleDao ;
	
	@Override
	@Transactional
	public void addRole(Role role) {
		roleDao.save(role);
	}
	
	@Override
	@Transactional
	public void editRole(Role role) {
		roleDao.update(role) ;
		//同时修改用户角色表信息
		userRoleDao.updateUserRoleByRole(role) ; 
	}
	
	@Override
	@Transactional
	public void deleteRole(List<Long> delIds) {
		//删除角色
		roleDao.deleteByIds(delIds);
		//删除角色用户对应关系
		userRoleDao.deleteByRoleIds(delIds);
		//删除角色功能对应关系
		roleFunctionDao.deleteByRoleIds(delIds);
	}
	
	@Override
	public List<Role> getRoles(int page, int size,String name) {
		List<Role> roles = roleDao.findRoles(page, size,name) ;
		return roles;
	}
	
	@Override
	public int getRoleRecordTotal(String name) {
		return roleDao.getRoleRecordTotal(name);
	}
	
	@Override
	public List<Role> getRoles(Collection<Long> ids) {
		return roleDao.findByIds(ids);
	}
	@Override
	public List<RoleFunction> getRoleFunctions(Long roleId) {
		return roleFunctionDao.findRoleFunctionsByRoleId(roleId);
	}
	@Override
	public Role getRoleById(Long id) {
		return roleDao.getRoleById(id);
	}
	@Override
	public List<Role> getAllRoles() {
		List<Role> roles = roleDao.getAllRoles() ;
		return roles;
	}

	@Override
	public List<RoleFunction> getRoleFunctionsByRoleIds(Collection<Long> ids) {
		return roleFunctionDao.getRoleFunctionsByRoleIds(ids);
	}

	@Override
	public void setRoleFunctions(Long roleId, List<Long> functionIds) {
		List<Long> delIds = new ArrayList<Long>() ;
		delIds.add(roleId) ;
		roleFunctionDao.deleteByRoleIds(delIds);
		List<RoleFunction> roleFunctionList = new ArrayList<RoleFunction>();
		functionIds.forEach((fi)->{
			RoleFunction rf = new RoleFunction();
			rf.setRoleId(roleId);
			rf.setFunctionId(fi);
			roleFunctionList.add(rf) ;
		});
		roleFunctionDao.saveRoleFunctions(roleFunctionList) ;
	}
}

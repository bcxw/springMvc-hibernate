package com.zee.csm.dto;

import java.util.Date;
import java.util.List;

public class FunctionDTO {
	private Long id ;
	private Long parentId ;
	private String text ; 
	private Integer state ;  
	private String functionPath ; 
	private String functionDescription ;
	private String iconCls ; //显示easyUI图标
	private boolean checked ; //是否被选中
	private Date createTime ;
	private Date updateTime ;
	
	private List<FunctionDTO> children ;  
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public Long getParentId() {
		return parentId;
	}
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public String getFunctionPath() {
		return functionPath;
	}
	public void setFunctionPath(String functionPath) {
		this.functionPath = functionPath;
	}
	
	public String getFunctionDescription() {
		return functionDescription;
	}
	public void setFunctionDescription(String functionDescription) {
		this.functionDescription = functionDescription;
	}
	public String getIconCls() {
		return iconCls;
	}
	public void setIconCls(String iconCls) {
		this.iconCls = iconCls;
	}
	public boolean isChecked() {
		return checked;
	}
	public void setChecked(boolean checked) {
		this.checked = checked;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	
	public List<FunctionDTO> getChildren() {
		return children;
	}
	public void setChildren(List<FunctionDTO> children) {
		this.children = children;
	}
	@Override
	public String toString() {
		return "FunctionDTO [id=" + id + ", text=" + text + ", state=" + state + ", functionPath=" + functionPath
				+ ", iconCls=" + iconCls + ", createTime=" + createTime + ", updateTime=" + updateTime + "]";
	}
}

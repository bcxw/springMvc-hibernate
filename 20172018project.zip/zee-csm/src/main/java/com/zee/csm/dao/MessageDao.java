package com.zee.csm.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.zee.csm.entity.Message;

public interface MessageDao {
	
	/**
	 * 判断数据对象是否已经存在消息提醒
	 * @param dataId
	 * @return
	 */
	public int existMessage(@Param("type")String type,@Param("dataId")String dataId);
	
	/**
	 * 插入消息
	 * @param message
	 * @return
	 */
	public int insert(Message message);
	
	
	/**
	 * 修改消息状态
	 * @param messageId
	 * @param statusCode
	 * @param statusText
	 * @return
	 */
	public int updateMessageStatus(@Param("messageId")Long messageId,@Param("statusCode")String statusCode,@Param("statusText")String statusText);
	
	/**
	 * 按类型和数据id获取消息
	 * @param type
	 * @param dataId
	 * @return
	 */
	public List<Message> getMessageByTypeAndDataId(@Param("type")String type,@Param("dataId")String dataId);
	
	/**
	 * 按类型获取打款单超时消息
	 * @param type
	 * @return
	 */
	public List<Message> getActiveMessageByType(@Param("type")String type,@Param("userId")Long userId);
	
}

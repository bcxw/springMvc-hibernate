package com.zee.csm.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zee.csm.context.NativeCache;
import com.zee.csm.dao.FunctionDao;
import com.zee.csm.dao.RoleFunctionDao;
import com.zee.csm.dto.FunctionDTO;
import com.zee.csm.entity.Function;
import com.zee.csm.service.FunctionService;

@Service
public class FunctionServiceImpl implements FunctionService{
	
	@Resource
	private FunctionDao functionDao ;
	@Resource
	private RoleFunctionDao roleFunctionDao ; 
	@Resource
	private NativeCache nativeCache ;
	
	
	@Override
	@Transactional
	public void addFunction(Function function) {
		functionDao.save(function) ;
	}

	@Override
	@Transactional
	public void updateUrl(Long id, String url,Integer accordion,String name) {
		functionDao.updateUrl(id, url,accordion,name) ;
	}

	@Override
	public List<Function> getFunctions(int page, int size, Long parentId) {
		return functionDao.findFunctions(page, size, parentId) ;
	}

	@Override
	@Transactional
	public void deleteFunctionById(Long id) {
		//删除功能信息
		functionDao.deleteById(id);
		//删除菜单对应角色关系
		roleFunctionDao.deleteRoleFunctionByFunctionId(id) ;
		
	}

	@Override
	public List<Function> getAllFunctions() {
		return functionDao.getAllFunctions();
	}

	@Override
	public Function findFunctionById(Long id) {
		return functionDao.findFunctionById(id);
	}

	@Override
	public List<FunctionDTO> getAuthsByParentId(Long parentId, List<Long> functionIds) {
		Map<Long, List<Function>> parentMap = nativeCache.getParentFunctions() ; 
		List<Function> functions = parentMap.get(parentId) ; 
		List<FunctionDTO> functionDTOList = new ArrayList<FunctionDTO>() ;
		if(null != functions){
			for (Function function : functions) {
				if(functionIds.contains(function.getId())){
					FunctionDTO functionDTO = new FunctionDTO() ;
					functionDTO.setId(function.getId());
					functionDTO.setText(function.getFunctionName());
					functionDTO.setChildren(getAuthsByParentId(function.getId(),functionIds))  ;
					functionDTO.setIconCls(function.getIconCls());
					functionDTO.setFunctionPath(function.getFunctionPath());
					functionDTO.setFunctionDescription(function.getFunctionDescription());
					functionDTOList.add(functionDTO) ;
				}
			}
		}
		return functionDTOList ;
	}
	
	@Override
	public List<FunctionDTO> getAllFunctionsByParentId(Long parentId) {
		Map<Long, List<Function>> parentMap = nativeCache.getParentFunctions() ; 
		List<Function> functions = parentMap.get(parentId) ; 
		List<FunctionDTO> functionDTOList = new ArrayList<FunctionDTO>() ;
		if(null != functions){
			for (Function function : functions) {
				FunctionDTO functionDTO = new FunctionDTO() ;
				functionDTO.setId(function.getId());
				functionDTO.setParentId(function.getParentId());
				functionDTO.setText(function.getFunctionName());
				functionDTO.setChildren(getAllFunctionsByParentId(function.getId()))  ;
				functionDTO.setIconCls(function.getIconCls());
				functionDTO.setFunctionPath(function.getFunctionPath());
				functionDTO.setFunctionDescription(function.getFunctionDescription());
				functionDTOList.add(functionDTO) ;
			}
		}
		return functionDTOList ;
	}
	
	@Override
	public boolean hasChildrenByParentId(Long parentId){
		int result = functionDao.hasChildrenByParentId(parentId); 
		return result>0?true:false ;
	}

	@Override
	public void updateFunction(Function function) {
		functionDao.updateFunction(function) ;
	}

	@Override
	public List<FunctionDTO> getCheckedByParentId(Long parentId, List<Long> functionIds) {
		Map<Long, List<Function>> parentMap = nativeCache.getParentFunctions() ; 
		List<Function> functions = parentMap.get(parentId) ; 
		List<FunctionDTO> functionDTOList = new ArrayList<FunctionDTO>() ;
		if(null != functions){
			for (Function function : functions) {
				FunctionDTO functionDTO = new FunctionDTO() ;
				if(functionIds.contains(function.getId())){
					functionDTO.setChecked(true);
				}
				functionDTO.setId(function.getId());
				functionDTO.setText(function.getFunctionName());
				functionDTO.setChildren(getCheckedByParentId(function.getId(),functionIds))  ;
				functionDTO.setIconCls(function.getIconCls());
				functionDTO.setFunctionPath(function.getFunctionPath());
				functionDTO.setFunctionDescription(function.getFunctionDescription());
				functionDTOList.add(functionDTO) ;
			}
		}
		return functionDTOList ;
	}
}

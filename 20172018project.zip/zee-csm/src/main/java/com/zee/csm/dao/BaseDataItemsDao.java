package com.zee.csm.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.zee.csm.dto.BaseDataItemsDTO;
import com.zee.csm.entity.BaseDataCategory;
import com.zee.csm.entity.BaseDataItems;

public interface BaseDataItemsDao {
	/**
	 * 获取数据项
	 * @param parentId
	 * @return
	 */
	public List<BaseDataItems> getBaseDataItemsByParentId(@Param("parentId")Long parentId);
	
	/**
	 * 判断是否存在下级数据
	 * @param parentId
	 * @return
	 */
	public int existItem(@Param("parentId")Long parentId);
	
	/**
	 * 添加分类
	 * @param baseDataItems
	 * @return
	 */
	public int insert(BaseDataItems baseDataItems);
	
	/**
	 * 修改分类
	 * @param baseDataItems
	 * @return
	 */
	public int update(BaseDataItems baseDataItems);
	
	/**
	 * 同一分类下判断判断重名
	 * @param baseDataItems
	 * @return
	 */
	public int existName(BaseDataItems baseDataItems);
	
	/**
	 * 同一分类下判断编码重复
	 * @param baseDataItems
	 * @return
	 */
	public int existCode(BaseDataItems baseDataItems);
	
	/**
	 * 删除分类
	 * @param id
	 * @return
	 */
	public int delete(@Param("id")Long id);
	
	/**
	 * 判断是否存在下级数据
	 * @param parentId
	 * @return
	 */
	public int existChild(@Param("parentId")Long parentId);
	
	/**
	 * 根据父类id获取选项数据
	 * @param code
	 * @return
	 */
	public List<Map<String,Object>> getBaseDataItemByParentCode(@Param("code")String code);
}

package com.zee.csm.dto;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class GetMoneyManagementDTO {

	private Long id;
	private String orderNo;
	private String shopName;
	private String shopCode;
	private String customId;
	private Double money;
	private String reasonText;
	private String reasonCode;
	private String createrUserName;
	private Long createrUserId;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date createrDate;
	private String operatorUserName;
	private Long operatorUserId;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date operatorDate;
	private String statusCode;
	private String statusName;
	private String description;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public String getShopCode() {
		return shopCode;
	}
	public void setShopCode(String shopCode) {
		this.shopCode = shopCode;
	}
	public String getCustomId() {
		return customId;
	}
	public void setCustomId(String customId) {
		this.customId = customId;
	}
	public Double getMoney() {
		return money;
	}
	public void setMoney(Double money) {
		this.money = money;
	}
	
	public String getReasonText() {
		return reasonText;
	}
	public void setReasonText(String reasonText) {
		this.reasonText = reasonText;
	}
	public String getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	public String getCreaterUserName() {
		return createrUserName;
	}
	public void setCreaterUserName(String createrUserName) {
		this.createrUserName = createrUserName;
	}
	public Long getCreaterUserId() {
		return createrUserId;
	}
	public void setCreaterUserId(Long createrUserId) {
		this.createrUserId = createrUserId;
	}
	public Date getCreaterDate() {
		return createrDate;
	}
	public void setCreaterDate(Date createrDate) {
		this.createrDate = createrDate;
	}
	public String getOperatorUserName() {
		return operatorUserName;
	}
	public void setOperatorUserName(String operatorUserName) {
		this.operatorUserName = operatorUserName;
	}
	public Long getOperatorUserId() {
		return operatorUserId;
	}
	public void setOperatorUserId(Long operatorUserId) {
		this.operatorUserId = operatorUserId;
	}
	public Date getOperatorDate() {
		return operatorDate;
	}
	public void setOperatorDate(Date operatorDate) {
		this.operatorDate = operatorDate;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusName() {
		return statusName;
	}
	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	
	
}

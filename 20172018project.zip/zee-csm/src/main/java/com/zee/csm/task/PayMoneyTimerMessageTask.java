package com.zee.csm.task;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.zee.csm.context.ConfigContext;
import com.zee.csm.dao.MessageDao;
import com.zee.csm.dao.PayMoneyManagementDao;
import com.zee.csm.entity.Message;
import com.zee.csm.entity.PayMoneyManagement;
import com.zee.csm.service.MessageService;
import com.zee.framework.aspect.autolog.annotation.ZcyAutoLog;

@Component
@ZcyAutoLog(module="打款超时提醒定时任务",tag="PayMoneyTimerMessageTask")
public class PayMoneyTimerMessageTask {
	private static final Logger logger = LoggerFactory.getLogger(PayMoneyTimerMessageTask.class);

	@Resource
	private ConfigContext configContext;
	
	@Resource
	private MessageDao messageDao;
	
	@Resource
	private PayMoneyManagementDao payMoneyManagementDao;
	
	@Scheduled(cron = "0 0/10 * * * ? ") // 十分钟执行一次
	public void createDeliveryExpireMessage() {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date nowDate=new Date();
		String nowDateStr=sdf.format(nowDate);
		String payMoneyExpireHour = configContext.getPayMoneyExpireHour();
		//默认12小时提醒
		int expireHour=StringUtils.isEmpty(payMoneyExpireHour)?12:Integer.parseInt(payMoneyExpireHour);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(nowDate);
		calendar.add(calendar.HOUR_OF_DAY, 0-expireHour);
		String expireDateStr=sdf.format(calendar.getTime());
		List<PayMoneyManagement> payMoneyManagementList= payMoneyManagementDao.getPayMoneyManagementOvertimeAndNoMessage(expireDateStr);
		for(int i=0;i<payMoneyManagementList.size();i++){
			PayMoneyManagement payMoneyManagement=payMoneyManagementList.get(i);
			if(messageDao.existMessage(MessageService.MESSAGE_TYPE_PAYMONEY_OVERTIME, payMoneyManagement.getId()+"")<=0){
				Message message=new Message();
				message.setSenderId(payMoneyManagement.getCreaterUserId()+"");
				message.setSenderName(payMoneyManagement.getCreaterUserName());
				message.setType(MessageService.MESSAGE_TYPE_PAYMONEY_OVERTIME);
				message.setTitle("打款超时提醒");
				message.setContent("订单编号："+payMoneyManagement.getOrderNo()+"。此订单超过时间未打款，特此提醒！");
				message.setModule("payMoneyManagement");
				message.setDataId(payMoneyManagement.getId()+"");
				message.setStatusCode("未处理");
				message.setStatusCode("0");
				messageDao.insert(message);
			}
		}
	}

}

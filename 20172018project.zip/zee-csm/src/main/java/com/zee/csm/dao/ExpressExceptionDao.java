package com.zee.csm.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.zee.csm.entity.ExpressException;
import com.zee.csm.entity.ExpressExceptionOperation;

public interface ExpressExceptionDao {
	
	/**
	 * 新增快递问题单
	 * @param expressException
	 * @return
	 */
	public int insert(ExpressException expressException);
	
	/**
	 * 保存快递问题单操作记录
	 * @param payMoneyManagementHistory
	 * @return
	 */
	public int insertHistory(ExpressExceptionOperation expressExceptionOperation);
	
	/**
	 * 修改快递问题单
	 * @param expressException
	 * @return
	 */
	public int update(ExpressException expressException);
	
	/**
	 * 判断快递单是否已经存在
	 * @param expressException
	 * @return
	 */
	public int existExpressCode(ExpressException expressException);
	
	/**
	 * 查询打款单分页列表
	 * @param payMoneyManagement
	 * @param page
	 * @param size
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<ExpressException> getExpressExceptionPage(@Param("expressException")ExpressException expressException,@Param("page")Integer page,@Param("size")Integer size,@Param("startDate")Date startDate,@Param("endDate")Date endDate);
	
	
	/**
	 * 获取快递问题单总数
	 * @param expressException
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public int getExpressExceptionTotal(@Param("expressException")ExpressException expressException,@Param("startDate")Date startDate,@Param("endDate")Date endDate);
	
	/**
	 * 查询打款历史记录
	 * @param payMoneyId
	 * @return
	 */
	public List<ExpressExceptionOperation> getExpressExceptionHistory(@Param("expressExceptionId")Long expressExceptionId);
	
	
	/**
	 * 获取快递问题单
	 * @param id
	 * @return
	 */
	public List<ExpressException> getExpressException(@Param("id")Long id);

	/**
	 * close
	 * @param id
	 * @return
	 */
	public int closeExpressException(@Param("id")Long id);
	
}

package com.zee.csm.service;

import java.util.Collection;
import java.util.List;

import com.zee.csm.entity.Role;
import com.zee.csm.entity.RoleFunction;

public interface RoleService {
	//保存角色的同时保存角色对应的功能
	public void addRole(Role role) ;
	//修改角色的同时保存角色对应的功能
	public void editRole(Role role) ;
	//根据ID删除角色
	public void deleteRole(List<Long> delIds) ;
	//分页查询角色信息
	public List<Role> getRoles(int page,int size,String name) ;
	//根据ID集合查询角色信息
	public List<Role> getRoles(Collection<Long> ids) ;
	//根据角色ID查询角色功能对应关系
	public List<RoleFunction> getRoleFunctions(Long roleId) ;
	
	public List<RoleFunction> getRoleFunctionsByRoleIds(Collection<Long> ids) ;
	//查询角色总数
	public int getRoleRecordTotal(String name);
	//根据ID查询角色
	public Role getRoleById(Long id);
	public List<Role> getAllRoles() ;
	public void setRoleFunctions(Long roleId, List<Long> functionIds);
}

package com.zee.csm.web;

import java.util.Base64;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zee.csm.common.CookieUtil;
import com.zee.csm.common.MD5Utils;
import com.zee.csm.common.StringUtil;
import com.zee.csm.context.LoginUserCache;
import com.zee.csm.context.LoginUserHelper;
import com.zee.csm.context.UserContext;
import com.zee.csm.context.WebApplicationContext;
import com.zee.csm.entity.User;
import com.zee.csm.entity.UserRole;
import com.zee.csm.service.RoleService;
import com.zee.csm.service.UserService;

@Controller
public class LoginController {
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class) ;
	@Resource
	private UserService userService ;
	
	@Resource
	private RoleService roleService ;

	
	@RequestMapping(value="/auth",method=RequestMethod.GET)
	public String index(HttpServletRequest request,Model model){
		logger.info(">>>>>>>>LoginController index begin ");
		String cookieValue = CookieUtil.getCookieValue(request) ;
		byte[] bytes = Base64.getDecoder().decode(cookieValue) ;
		String auth = new String(bytes) ;
		String[] array = auth.split("\\$") ;
		if(2==array.length){
			User currentUser = LoginUserCache.get(array[0]) ;
			logger.info(">>>>>>>>>>RoleAuthorizeController menu currentUser : " + currentUser);
			if(null == currentUser){
				LoginUserHelper helper = WebApplicationContext.getBean(LoginUserHelper.class) ;
				helper.executeLogin(array[0],array[1]) ;
				currentUser = LoginUserCache.get(array[0]) ;
				UserContext.setCurrentUser(currentUser);
			}
			logger.info(">>>>>>>>LoginController currentUser:" + currentUser);
			StringBuffer sb = new StringBuffer() ; 
			List<UserRole> userRoleList = userService.getUserRolesByUserId(currentUser.getId()) ;
			if(null != userRoleList){
				for (int i = 0; i < userRoleList.size(); i++) {
					if(i==0){
						sb.append(userRoleList.get(i).getRoleName()) ;
					}else{
						sb.append(","+userRoleList.get(i).getRoleName()) ;
					}
				}
			}
			logger.info(">>>>>>>>LoginController roleName " + sb.toString());
			model.addAttribute("roleName", sb.toString()) ;
			model.addAttribute("currentUser", currentUser) ;
			return "/layout/main" ;
		}
		return "/security/login" ;
	} 
 
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String login(Model model,HttpServletRequest request,String userName , String password,String imageCode){
		logger.info("login1>>>>>>>>>>>>>userName: "+ userName +" >>>>>password:" + password);
		HttpSession session=request.getSession();
		if(StringUtil.isEmpty(userName)||StringUtil.isEmpty(password)){
			model.addAttribute("error", "用户名或密码为空") ;
			return "/security/login" ;
		}
		logger.info("login2>>>>>>>>>>>>>imageCode: "+ imageCode);
		if(StringUtil.isEmpty(imageCode)){
			model.addAttribute("error", "验证码为空！") ;
			return "/security/login" ;
		}
		logger.info("login3>>>>>>>>>>>>>sRand: "+ session.getAttribute("sRand"));
		if(!imageCode.equals(session.getAttribute("sRand"))){
			model.addAttribute("error", "验证码错误！") ;
			return "/security/login" ;
		}
		try{
			logger.info(">>>>>>>>>>>>>userName: "+ userName +" >>>>>password:" + password);
			User currentUser = userService.getUser(userName, MD5Utils.MD5(password)) ;
			logger.info(">>>>>>>>>>>>>currentUser:" + currentUser);
			if(null == currentUser){
				model.addAttribute("error", "用户名或密码错误") ;
				return "/security/login" ;
			}
			StringBuffer sb = new StringBuffer() ; 
			List<UserRole> userRoleList = userService.getUserRolesByUserId(currentUser.getId()) ;
			if(null != userRoleList){
				for (int i = 0; i < userRoleList.size(); i++) {
					if(i==0){
						sb.append(userRoleList.get(i).getRoleName()) ;
					}else{
						sb.append(","+userRoleList.get(i).getRoleName()) ;
					}
				}
			}
			CookieUtil.addCookie(request, currentUser);
			session.setAttribute("CURRENT_LOGIN_USER",currentUser);
			model.addAttribute("roleName", sb.toString()) ;
			model.addAttribute("currentUser", currentUser) ;
			return "/layout/main" ;
		}catch(Exception e){
			logger.error(">>>>>>>>>>>>>error:" + e.getMessage());
			CookieUtil.delCookie(request);
			return "/security/login" ;
		}
	}
	
	@RequestMapping(value="/logout",method=RequestMethod.GET)
	public String logout(HttpServletRequest request){
		logger.info(">>>>>>>>LoginController logout begin ");
		User currentUser = UserContext.getCurrentUser() ; 
		if(null != currentUser){
			CookieUtil.delCookie(request);
			LoginUserCache.remove(currentUser.getUserName())	;
			request.removeAttribute("CURRENT_LOGIN_USER");
		}
		logger.info(">>>>>>>>LoginController logout end ");
		return "/security/login" ;
	}
}

package com.zee.csm.context;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ConfigContext {
	@Value("${payMoneyExpireHour}")
	private String payMoneyExpireHour;

	public String getPayMoneyExpireHour() {
		return payMoneyExpireHour;
	}

	public void setPayMoneyExpireHour(String payMoneyExpireHour) {
		this.payMoneyExpireHour = payMoneyExpireHour;
	}

	

}

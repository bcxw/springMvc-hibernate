package com.zee.csm.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.zee.csm.entity.Role;
import com.zee.csm.service.RoleService;
import com.zee.framework.model.Result;
import com.zee.framework.util.ResultUtil;

@Controller
@RequestMapping("/role")
public class RoleController {
	private static final Logger logger = LoggerFactory.getLogger(RoleController.class) ;
	@Resource
	private RoleService roleService ; 
	
	@RequestMapping("/index")
	public String index(){
		logger.info(">>>>>>> RoleController index begin");
		return "/security/role/roleManage" ;
	}
 
	@RequestMapping(value="/getRoles",method = RequestMethod.POST,produces="text/json;charset=UTF-8")
	@ResponseBody
	public String getRoles(Integer page,Integer rows,String roleName){
		logger.info(">>>>>>> RoleController getRoles begin roleName " + roleName);
		Map<String, Object> resultMap = new HashMap<String, Object>() ; 
		List<Role> roles = new ArrayList<Role>() ;
		if(null == rows || null == page){
			roles = roleService.getAllRoles() ;
			return JSON.toJSONString(roles) ;
		}else{ //easyUI分页默认是从1开始
			roles = roleService.getRoles(page == 1 ? (page-1) : (page-1)*rows, rows,roleName) ; 
		}
		resultMap.put("rows", roles) ;
		resultMap.put("total", roleService.getRoleRecordTotal(roleName)) ;
		logger.info(">>>>>>> RoleController getRoles end roleName " + roleName);
		return JSON.toJSONString(resultMap) ;
	}
	
	@RequestMapping(value="/addEditRole",method=RequestMethod.POST)
	@ResponseBody
	public Result addEditRole(Role role){
		logger.info(">>>>>>> RoleController addEditRole begin role: " + role);
		if(null == role.getId()){
			roleService.addRole(role);
		}else{
			roleService.editRole(role);
		}
		logger.info(">>>>>>> RoleController addEditRole end role: " + role);
		return ResultUtil.success() ;
	}
	
	@RequestMapping(value="/deleteRoles",method=RequestMethod.POST)
	@ResponseBody
	public Result deleteRole(@RequestParam(value = "delIds[]")List<Long> delIds){
		logger.info(">>>>>>> RoleController deleteRole delIds: " + delIds);
		roleService.deleteRole(delIds);
		return ResultUtil.success() ;
	}
}

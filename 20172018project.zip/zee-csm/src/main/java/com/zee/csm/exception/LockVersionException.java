package com.zee.csm.exception;

import com.zee.framework.aspect.autolog.Interface.DesignedException;

public class LockVersionException extends RuntimeException implements DesignedException {

	private static final long serialVersionUID = 6985045184414372363L;
	
	private Integer code; 
	private String msg; 
	
	/**
	 * 数据版本冲突异常
	 * @param code
	 * @param message
	 */
    public LockVersionException(Integer code,String message) {
        super(message);
        this.setCode(code);
        this.setMsg(message);
    }

	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
}

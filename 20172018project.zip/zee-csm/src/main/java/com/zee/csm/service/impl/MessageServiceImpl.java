package com.zee.csm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.zee.csm.dao.MessageDao;
import com.zee.csm.entity.Message;
import com.zee.csm.service.MessageService;
import com.zee.framework.model.Result;

@Service
public class MessageServiceImpl implements MessageService{
	
	@Resource
	private MessageDao messageDao;

	@Override
	public void closeMessageStatusByTypeAndDataId(String type, String dataId) {
		List<Message> messageList=messageDao.getMessageByTypeAndDataId(type, dataId);
		if(messageList!=null&&messageList.size()>0){
			Message message = messageList.get(0);
			messageDao.updateMessageStatus(message.getId(), "-10", "已关闭");
		}
		
		
	}


}

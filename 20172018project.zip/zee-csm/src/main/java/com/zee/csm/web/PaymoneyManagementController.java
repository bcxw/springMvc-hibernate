package com.zee.csm.web;

import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zee.csm.dto.PayMoneyManagementDTO;
import com.zee.csm.service.PaymoneyManagementService;
import com.zee.framework.aspect.autolog.annotation.ZcyAutoLog;
import com.zee.framework.model.Result;
import com.zee.framework.util.ResultUtil;
import com.zee.csm.context.UserContext;
import com.zee.csm.entity.User;

@Controller
@RequestMapping("/paymoneyManagement")
@ZcyAutoLog(module="打款管理",tag="PaymoneyManagementController")
public class PaymoneyManagementController {
	private static final Logger logger = LoggerFactory.getLogger(PaymoneyManagementController.class);

	@Resource
	private PaymoneyManagementService paymoneyManagementService;
	
	/**
	 * 打款管理页面
	 * @param request
	 * @return
	 */
	@RequestMapping("/index")
	public String index(HttpServletRequest request) {
		return "/security/paymoneyManagement/paymoneyManagement";
	}

	/**
	 * 保存打款单
	 * @param payMoneyManagementDTO
	 * @return
	 */
	@RequestMapping(value = "/savePaymoneyManagement")
	@ResponseBody
	public Result savePaymoneyManagement(HttpServletRequest request,PayMoneyManagementDTO payMoneyManagementDTO,String isConfirm) {
		try {
			User user=(User)request.getSession().getAttribute("CURRENT_LOGIN_USER");
			Result result=paymoneyManagementService.savePaymoneyManagement(payMoneyManagementDTO, user,isConfirm);
			return result;
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			return ResultUtil.error(-10,"请刷新重试或重新登录！");
		}
	}
	
	/**
	 * 获取打款单分页列表
	 * @param payMoneyManagementDTO
	 * @param page
	 * @param rows
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@RequestMapping(value = "/getPaymoneyManagementPage")
	@ResponseBody
	public Result getPaymoneyManagementPage(HttpServletRequest request,PayMoneyManagementDTO payMoneyManagementDTO,Integer page, Integer rows,@DateTimeFormat(pattern="yyyy-MM-dd") Date startDate,@DateTimeFormat(pattern="yyyy-MM-dd") Date endDate) {
		try {
			User user=(User)request.getSession().getAttribute("CURRENT_LOGIN_USER");
			int total=paymoneyManagementService.getPayMoneyManagementTotal(payMoneyManagementDTO,startDate,endDate);
			int start=page == 1 ? (page - 1) : (page - 1) * rows;
			return ResultUtil.page(paymoneyManagementService.getPayMoneyManagementPage(payMoneyManagementDTO, start, rows,startDate,endDate), total);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			return ResultUtil.error(-10,"请刷新重试或重新登录！");
		}
	}
	
	/**
	 * 获取打款单历史记录
	 * @param payMoneyId
	 * @return
	 */
	@RequestMapping(value = "/getPaymoneyManagementHistory")
	@ResponseBody
	public Result getPaymoneyManagementHistory(HttpServletRequest request,Long payMoneyId) {
		try {
			return ResultUtil.page(paymoneyManagementService.getPayMoneyManagementHistory(payMoneyId), 0);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			return ResultUtil.error(-10,"请刷新重试或重新登录！");
		}

	}
	
	/**
	 * 关闭打款单
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/closePayMoneyManagement")
	@ResponseBody
	public Result closePayMoneyManagement(HttpServletRequest request,Long id,String closeReason) {
		try {
			User user=(User)request.getSession().getAttribute("CURRENT_LOGIN_USER");
			return paymoneyManagementService.closePayMoneyManagement(id,closeReason,user);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			return ResultUtil.error(-10,"请刷新重试或重新登录！");
		}
	}
	
	/**
	 * 进行打款操作
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/toPayMoney")
	@ResponseBody
	public Result toPayMoney(HttpServletRequest request,Long id) {
		try {
			User user=(User)request.getSession().getAttribute("CURRENT_LOGIN_USER");
			return paymoneyManagementService.toPayMoney(id,user);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			return ResultUtil.error(-10,"请刷新重试或重新登录！");
		}
	}

	/**
	 * 获取当前用户是否有打款权限
	 * @return
	 */
	@RequestMapping(value = "/getPayMoneyPermission")
	@ResponseBody
	public Result getPayMoneyPermission(HttpServletRequest request) {
		try {
			User user=(User)request.getSession().getAttribute("CURRENT_LOGIN_USER");
			if(paymoneyManagementService.canPayMoney(user.getId())){
				return ResultUtil.success();
			}else{
				return ResultUtil.error(-1,"您没有打款权限，只有打款员或管理员才有打款权限！");
			}
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			return ResultUtil.error(-10,"请刷新重试或重新登录！");
		}

	}
	
	/**
	 * 获取消息提醒
	 * @return
	 */
	@RequestMapping(value = "/getPayMoneyOverTimeMessage")
	@ResponseBody
	public Result getPayMoneyOverTimeMessage(HttpServletRequest request) {
		try {
			User user=(User)request.getSession().getAttribute("CURRENT_LOGIN_USER");
			return paymoneyManagementService.getPayMoneyOverTimeMessage(user);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			return ResultUtil.error(-10,"请刷新重试或重新登录！");
		}
	}
	
	/**
	 * 导出打款单
	 * @param request
	 * @param response
	 * @param payMoneyManagementDTO
	 * @param startDate
	 * @param endDate
	 */
	@RequestMapping(value = "/exportPaymoneyManagement")
	public void exportPaymoneyManagement(HttpServletRequest request, HttpServletResponse response,PayMoneyManagementDTO payMoneyManagementDTO,@DateTimeFormat(pattern="yyyy-MM-dd") Date startDate,@DateTimeFormat(pattern="yyyy-MM-dd") Date endDate) {
		HSSFWorkbook wb=paymoneyManagementService.exportPayMoneyManagement(payMoneyManagementDTO, startDate, endDate);
		OutputStream myout=null;
		try {
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html;charset=utf-8");
			myout=response.getOutputStream();
			
			response.setContentType("applicationoctet-stream;charset=UTF-8");
			String name = "打款记录.xls";
			String userAgent = request.getHeader("User-Agent").toLowerCase();

			//byte[] bytes = userAgent.contains("safari") ?name.getBytes("UTF-8"):name.getBytes("gbk");
			//name = new String(bytes, "ISO-8859-1");
			if (userAgent.contains("msie") || userAgent.contains("like gecko") ) {
				name = URLEncoder.encode(name, "UTF-8");
			} else {
				name = new String(name.getBytes("UTF-8"), "iso-8859-1");
			}
			response.setHeader("Content-disposition", String.format("attachment;filename=\"%s\"", name));
			wb.write(myout);
			
		} catch (UnsupportedEncodingException e) {
			logger.error(e.getMessage(),e);
		} catch (IOException e) {
			logger.error(e.getMessage(),e);
		} finally{
			try {
				if(wb!=null)wb.close();
				if(myout!=null)myout.close();
			} catch (IOException e) {
				logger.error(e.getMessage(),e);
			}
		}
           
	}
	
}

package com.zee.csm.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zee.csm.dto.BaseDataCategoryDTO;
import com.zee.csm.dto.BaseDataItemsDTO;
import com.zee.csm.entity.BaseDataItems;
import com.zee.csm.service.BaseDataService;

@Controller
@RequestMapping("/baseData")
public class BaseDataController {
	private static final Logger logger = LoggerFactory.getLogger(BaseDataController.class);

	@Resource
	private BaseDataService baseDataService;

	/**
	 * 基础数据页面
	 * @param request
	 * @return
	 */
	@RequestMapping("/index")
	public String index(HttpServletRequest request) {
		return "/security/baseData/baseData";
	}

	/**
	 * 根据父类id获取子类数据
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/getBaseDataCategoryTree")
	@ResponseBody
	public List<Map<String, Object>> getBaseDataCategoryTree(Long id) {
		id = id != null && id >= 0 ? id : -1;
		return baseDataService.getBaseDataCategoryByParentId(id);
	}

	/**
	 * 根据父类id获取数据项
	 * @param parentId
	 * @return
	 */
	@RequestMapping(value = "/getBaseDataItemsByParentId")
	@ResponseBody
	public List<BaseDataItemsDTO> getBaseDataItemsByParentId(Long parentId) {
		parentId=parentId==null?-1:parentId;
		return baseDataService.getBaseDataItemsByParentId(parentId);
	}
	
	/**
	 * 保存分类
	 * @param baseDataCategoryDTO
	 * @return
	 */
	@RequestMapping(value = "/saveBaseDataCategory")
	@ResponseBody
	public Map<String, Object> saveBaseDataCategory(BaseDataCategoryDTO baseDataCategoryDTO) {
		return baseDataService.saveBaseDataCategory(baseDataCategoryDTO);
	}
	
	/**
	 * 删除分类
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/deleteBaseDataCategory")
	@ResponseBody
	public Map<String, Object> deleteBaseDataCategory(Long id){
		return baseDataService.deleteBaseDataCategory(id);
	}
	
	/**
	 * 保存数据项
	 * @param baseDataItemsDTO
	 * @return
	 */
	@RequestMapping(value = "/saveBaseDataItem")
	@ResponseBody
	public Map<String, Object> saveBaseDataItem(BaseDataItemsDTO baseDataItemsDTO) {
		return baseDataService.saveBaseDataItem(baseDataItemsDTO);
	}
	
	/**
	 * 删除数据项
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/deleteBaseDataItem")
	@ResponseBody
	public Map<String, Object> deleteBaseDataItem(Long id){
		return baseDataService.deleteBaseDataItem(id);
	}
	
	/**
	 * 根据父类编码获取数据项
	 * @param parentCode
	 * @return
	 */
	@RequestMapping(value = "/getBaseDataItemByParentCode")
	@ResponseBody
	public List<Map<String, Object>> getBaseDataItemByParentCode(String parentCode){
		return baseDataService.getBaseDataItemByParentCode(parentCode);
	}
	
	/**
	 * 根据父类编码获取子类
	 * @param parentCode
	 * @return
	 */
	@RequestMapping(value = "/getBaseDataCategoryAndItemByParentCode")
	@ResponseBody
	public List<Map<String, Object>> getBaseDataCategoryAndItemByParentCode(String parentCode){
		return baseDataService.getBaseDataCategoryAndItemByParentCode(parentCode);
	}
	
}

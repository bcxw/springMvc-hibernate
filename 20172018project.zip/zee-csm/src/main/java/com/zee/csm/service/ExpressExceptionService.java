package com.zee.csm.service;

import java.util.Date;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.zee.csm.dto.ExpressExceptionDTO;
import com.zee.csm.entity.ExpressException;
import com.zee.csm.entity.ExpressExceptionOperation;
import com.zee.csm.entity.User;
import com.zee.framework.model.Result;

public interface ExpressExceptionService {

	/**
	 * 保存快递异常单
	 * @param expressExceptionDTO
	 * @param user
	 * @return
	 */
	public Result saveExpressException(ExpressExceptionDTO expressExceptionDTO,User user,String isConfirm);

	/**
	 * 关闭快递问题单
	 * @param id
	 * @param user
	 * @return
	 */
	public Result closeExpressException(Long id,User user,String closeReason);
	
	/**
	 * 获取快递问题单总数
	 * @param expressExceptionDTO
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public int getExpressExceptionTotal(ExpressExceptionDTO expressExceptionDTO,Date startDate,Date endDate);
	
	/**
	 * 获取快递单分页数据
	 * @param expressExceptionDTO
	 * @param page
	 * @param size
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<ExpressException> getExpressExceptionPage(ExpressExceptionDTO expressExceptionDTO,int page,int size,Date startDate,Date endDate);
	
	
	/**
	 * 获取打款单历史记录
	 * @param id
	 * @return
	 */
	public List<ExpressExceptionOperation> getExpressExceptionHistory(Long expressExceptionId);
	
	
	/**
	 * 导出excel 
	 * @param payMoneyManagementDTO
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public HSSFWorkbook exportExpressException(ExpressExceptionDTO expressExceptionDTO, Date startDate, Date endDate);
	
}

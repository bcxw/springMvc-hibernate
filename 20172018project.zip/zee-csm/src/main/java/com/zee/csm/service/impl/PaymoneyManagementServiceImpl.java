package com.zee.csm.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.zee.csm.common.StringUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.zee.csm.dao.MessageDao;
import com.zee.csm.dao.PayMoneyManagementDao;
import com.zee.csm.dao.UserRoleDao;
import com.zee.csm.dto.PayMoneyManagementDTO;
import com.zee.csm.entity.Message;
import com.zee.csm.entity.PayMoneyManagement;
import com.zee.csm.entity.PayMoneyManagementOperation;
import com.zee.csm.entity.User;
import com.zee.csm.entity.UserRole;
import com.zee.csm.service.MessageService;
import com.zee.csm.service.PaymoneyManagementService;
import com.zee.framework.model.Result;
import com.zee.framework.util.ResultUtil;

@Service
public class PaymoneyManagementServiceImpl implements PaymoneyManagementService{
	
	private static final Logger logger = LoggerFactory.getLogger(PaymoneyManagementServiceImpl.class) ;
	
	private String[] canPayMoneyRoles={"superManager","customerServiceManager","customerServiceOperator"};
	
	@Resource
	private PayMoneyManagementDao payMoneyManagementDao;
	
	@Resource
	private UserRoleDao userRoleDao;
	
	@Resource
	private MessageDao messageDao;
	
	@Resource
	private MessageService messageService;

	@Override
	public Result savePaymoneyManagement(PayMoneyManagementDTO payMoneyManagementDTO,User user,String isConfirm) {
		
		PayMoneyManagement payMoneyManagement=new PayMoneyManagement();
		BeanUtils.copyProperties(payMoneyManagementDTO, payMoneyManagement);
		
		payMoneyManagement.setCreaterUserName(user.getUserName());
		payMoneyManagement.setCreaterUserId(user.getId());
		payMoneyManagement.setCreaterDate(new Date());
		
		PayMoneyManagementOperation payMoneyManagementHistory=new PayMoneyManagementOperation();

		if(StringUtil.isEmpty(payMoneyManagementDTO.getCustomId())){
			return ResultUtil.error(-2,"客户ID必须填写！");
		}
		
		//保存打款单
		if(payMoneyManagementDTO.getId()!=null&&payMoneyManagementDTO.getId()>0){
			
			payMoneyManagementHistory.setActionName("修改打款单");
			payMoneyManagementHistory.setActionCode("update");
			
			//找出修改的值
			String actionDescription="";
			List<PayMoneyManagement> payMoneyManagementList=payMoneyManagementDao.getPayMoneyManagement(payMoneyManagement.getId());
			PayMoneyManagement oldPayMoneyManagement=payMoneyManagementList.get(0);
			if(!(payMoneyManagement.getOrderNo()+"").equals(oldPayMoneyManagement.getOrderNo()+"")){//orderNo
				actionDescription+="订单编号："+oldPayMoneyManagement.getOrderNo()+"->"+payMoneyManagement.getOrderNo()+";";
			}
			if(!(payMoneyManagement.getShopName()+"").equals(oldPayMoneyManagement.getShopName()+"")){//shopName
				actionDescription+="店铺："+oldPayMoneyManagement.getShopName()+"->"+payMoneyManagement.getShopName()+";";
			}
			if(!(payMoneyManagement.getCustomId()+"").equals(oldPayMoneyManagement.getCustomId()+"")){//customId
				actionDescription+="客户ID："+oldPayMoneyManagement.getCustomId()+"->"+payMoneyManagement.getCustomId()+";";
			}
			if(!(payMoneyManagement.getMoney()+"").equals(oldPayMoneyManagement.getMoney()+"")){//money
				actionDescription+="金额："+oldPayMoneyManagement.getMoney()+"->"+payMoneyManagement.getMoney()+";";
			}
			if(!(payMoneyManagement.getReasonText()+"").equals(oldPayMoneyManagement.getReasonText()+"")){//reasonText
				actionDescription+="打款原因："+oldPayMoneyManagement.getReasonText()+"->"+payMoneyManagement.getReasonText()+";";
			}
			if(!(payMoneyManagement.getDescription()+"").equals(oldPayMoneyManagement.getDescription()+"")){//description
				actionDescription+="描述："+oldPayMoneyManagement.getDescription()+"->"+payMoneyManagement.getDescription()+";";
			}
			
			payMoneyManagementHistory.setActionDescription(actionDescription);
			
			payMoneyManagementDao.update(payMoneyManagement);
		}else{
			//判断是否有过打款单需要进行确认
			if(!"1".equals(isConfirm)&&payMoneyManagementDao.existCustomId(payMoneyManagement)>0){
				return ResultUtil.error(-1, "在此之前已经给该客户ID进行过打款，是否要继续进行打款！");
			}
			
			payMoneyManagement.setStatusName("未打款");
			payMoneyManagement.setStatusCode("0");
			
			payMoneyManagementDao.insert(payMoneyManagement);
			payMoneyManagementHistory.setActionName("新增打款单");
			payMoneyManagementHistory.setActionCode("insert");
		}
		
		//保存打款单快照
		payMoneyManagementHistory.setPaymoneyId(payMoneyManagement.getId());
		payMoneyManagementHistory.setUserId(user.getId());
		payMoneyManagementHistory.setUserName(user.getUserName());
		payMoneyManagementHistory.setDate(new Date());
		payMoneyManagementDao.insertHistory(payMoneyManagementHistory);
		
		return ResultUtil.success();
	}

	@Override
	public int getPayMoneyManagementTotal(PayMoneyManagementDTO payMoneyManagementDTO,Date startDate,Date endDate) {
		PayMoneyManagement payMoneyManagement=new PayMoneyManagement();
		BeanUtils.copyProperties(payMoneyManagementDTO, payMoneyManagement);
		return payMoneyManagementDao.getPayMoneyManagementTotal(payMoneyManagement, startDate, endDate);
	}

	@Override
	public List<PayMoneyManagement> getPayMoneyManagementPage(PayMoneyManagementDTO payMoneyManagementDTO, int page,
			int size,Date startDate,Date endDate) {
		PayMoneyManagement payMoneyManagement=new PayMoneyManagement();
		BeanUtils.copyProperties(payMoneyManagementDTO, payMoneyManagement);
		return payMoneyManagementDao.getPayMoneyManagementPage(payMoneyManagement, page, size, startDate, endDate);
	}

	@Override
	public List<PayMoneyManagementOperation> getPayMoneyManagementHistory(Long payMoneyId) {
		return payMoneyManagementDao.getPayMoneyManagementHistory(payMoneyId);
	}

	@Override
	public Result closePayMoneyManagement(Long id,String closeReason,User user) {
		PayMoneyManagement payMoneyManagement=new PayMoneyManagement();
		payMoneyManagement.setId(id);
		payMoneyManagementDao.closePayMoneyManagement(payMoneyManagement);
		
		PayMoneyManagementOperation payMoneyManagementOperation=new PayMoneyManagementOperation();
		payMoneyManagementOperation.setActionName("关闭打款单");
		payMoneyManagementOperation.setActionCode("close");
		payMoneyManagementOperation.setActionDescription(closeReason);
		payMoneyManagementOperation.setPaymoneyId(payMoneyManagement.getId());
		payMoneyManagementOperation.setUserId(user.getId());
		payMoneyManagementOperation.setUserName(user.getUserName());
		payMoneyManagementOperation.setDate(new Date());
		payMoneyManagementDao.insertHistory(payMoneyManagementOperation);
		
		messageService.closeMessageStatusByTypeAndDataId(MessageService.MESSAGE_TYPE_PAYMONEY_OVERTIME, payMoneyManagement.getId()+"");
		
		return ResultUtil.success();
	}

	@Override
	public Result toPayMoney(Long id, User user) {
		if(this.canPayMoney(user.getId())){
			PayMoneyManagement payMoneyManagement=new PayMoneyManagement();
			payMoneyManagement.setId(id);
			payMoneyManagement.setStatusName("已完结");
			payMoneyManagement.setStatusCode("10");
			
			payMoneyManagement.setOperatorDate(new Date());
			payMoneyManagement.setOperatorUserId(user.getId());
			payMoneyManagement.setOperatorUserName(user.getUserName());
			
			payMoneyManagementDao.updatePayMoneyManagementStatus(payMoneyManagement);
			
			PayMoneyManagementOperation payMoneyManagementOperation=new PayMoneyManagementOperation();
			payMoneyManagementOperation.setActionName("完成打款单");
			payMoneyManagementOperation.setActionCode("complete");
			payMoneyManagementOperation.setPaymoneyId(payMoneyManagement.getId());
			payMoneyManagementOperation.setUserId(user.getId());
			payMoneyManagementOperation.setUserName(user.getUserName());
			payMoneyManagementOperation.setDate(new Date());
			payMoneyManagementDao.insertHistory(payMoneyManagementOperation);
			
			messageService.closeMessageStatusByTypeAndDataId(MessageService.MESSAGE_TYPE_PAYMONEY_OVERTIME, payMoneyManagement.getId()+"");
			
			return ResultUtil.success();
		}else{
			return ResultUtil.error(-2, "您没有打款权限！只有打款员或者管理员才有打款权限！");
		}
		
	}

	@Override
	public boolean canPayMoney(Long userId) {
		boolean returnBoolean=false;
		List<UserRole> userRoleList = userRoleDao.findUserRoleByUserId(userId);
		for(int i=0;userRoleList!=null&&i<userRoleList.size();i++){
			UserRole userRole = userRoleList.get(i);
			if(Arrays.asList(canPayMoneyRoles).contains(userRole.getRoleCode())){
				returnBoolean=true;
				break;
			}
			
		}
		return returnBoolean;
	}

	@Override
	public Result getPayMoneyOverTimeMessage(User user) {
		List<Message> messageList=null;
		//打款管理员拥有所有消息
		if(this.canPayMoney(user.getId())){
			messageList=messageDao.getActiveMessageByType(MessageService.MESSAGE_TYPE_PAYMONEY_OVERTIME, null);
		}else{
			messageList=messageDao.getActiveMessageByType(MessageService.MESSAGE_TYPE_PAYMONEY_OVERTIME, user.getId());
		}
		return ResultUtil.success(messageList);
	}

	
	@Override
	public HSSFWorkbook exportPayMoneyManagement(PayMoneyManagementDTO payMoneyManagementDTO, Date startDate, Date endDate) {
		
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet=wb.createSheet("打款记录");
		/*******表头*********/
		HSSFRow row0=sheet.createRow(0);
		row0.createCell(0).setCellValue("订单编号");
		row0.createCell(1).setCellValue("店铺名称");
		row0.createCell(2).setCellValue("客户ID");
		row0.createCell(3).setCellValue("金额");
		row0.createCell(4).setCellValue("创建日期");
		row0.createCell(5).setCellValue("创建人");
		row0.createCell(6).setCellValue("状态");
		row0.createCell(7).setCellValue("打款人");
		row0.createCell(8).setCellValue("打款日期");
		row0.createCell(9).setCellValue("打款原因");
		row0.createCell(10).setCellValue("备注");
		row0.createCell(11).setCellValue("其他");
		
		/**********内容***********/
		List<Map<String,Object>> repetCustomIdList=payMoneyManagementDao.findRepetByCustomId();
		List<String> repetCustomIds=new ArrayList<String>();
		for(int i=0;i<repetCustomIdList.size();i++){
			repetCustomIds.add(repetCustomIdList.get(i).get("customId")+"");
		}
		
		PayMoneyManagement payMoneyManagement=new PayMoneyManagement();
		BeanUtils.copyProperties(payMoneyManagementDTO, payMoneyManagement);
		List<PayMoneyManagement> payMoneyManagementList= payMoneyManagementDao.getPayMoneyManagementPage(payMoneyManagement, null, null, startDate, endDate);
		
		for(int j=0;j<payMoneyManagementList.size();j++){
			PayMoneyManagement pm=payMoneyManagementList.get(j);
			HSSFRow row=sheet.createRow(j+1);
			row.createCell(0).setCellValue(pm.getOrderNo());
			row.createCell(1).setCellValue(pm.getShopName());
			row.createCell(2).setCellValue(pm.getCustomId());
			row.createCell(3).setCellValue(pm.getMoney());
			row.createCell(4).setCellValue(pm.getCreaterDate()!=null?sdf.format(pm.getCreaterDate()):"");
			row.createCell(5).setCellValue(pm.getCreaterUserName());
			row.createCell(6).setCellValue(pm.getStatusName());
			row.createCell(7).setCellValue(pm.getOperatorUserName());
			row.createCell(8).setCellValue(pm.getOperatorDate()!=null?sdf.format(pm.getOperatorDate()):"");
			row.createCell(9).setCellValue(pm.getReasonText());
			row.createCell(10).setCellValue(pm.getDescription());
			if(repetCustomIds.contains(pm.getCustomId())){
				row.createCell(11).setCellValue("此客户有过多次打款");
			}
		}
		return wb;
	}

}

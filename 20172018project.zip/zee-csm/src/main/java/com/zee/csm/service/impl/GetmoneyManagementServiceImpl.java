package com.zee.csm.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.zee.csm.common.StringUtil;
import com.zee.csm.entity.*;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.zee.csm.dao.GetMoneyManagementDao;
import com.zee.csm.dao.MessageDao;
import com.zee.csm.dao.PayMoneyManagementDao;
import com.zee.csm.dao.UserRoleDao;
import com.zee.csm.dto.GetMoneyManagementDTO;
import com.zee.csm.dto.PayMoneyManagementDTO;
import com.zee.csm.service.GetmoneyManagementService;
import com.zee.csm.service.MessageService;
import com.zee.csm.service.PaymoneyManagementService;
import com.zee.framework.model.Result;
import com.zee.framework.util.ResultUtil;

@Service
public class GetmoneyManagementServiceImpl implements GetmoneyManagementService{
	
	private static final Logger logger = LoggerFactory.getLogger(GetmoneyManagementServiceImpl.class) ;
	
	private String[] canPayMoneyRoles={"superManager","customerServiceManager","customerServiceOperator"};
	
	@Resource
	private GetMoneyManagementDao getMoneyManagementDao;
	
	@Resource
	private UserRoleDao userRoleDao;
	
	@Resource
	private MessageDao messageDao;
	
	@Resource
	private MessageService messageService;

	@Override
	public Result saveGetmoneyManagement(GetMoneyManagementDTO getMoneyManagementDTO,User user) {
		
		GetMoneyManagement getMoneyManagement=new GetMoneyManagement();
		BeanUtils.copyProperties(getMoneyManagementDTO, getMoneyManagement);
		
		getMoneyManagement.setCreaterUserName(user.getUserName());
		getMoneyManagement.setCreaterUserId(user.getId());
		getMoneyManagement.setCreaterDate(new Date());

		GetMoneyManagementOperation getMoneyManagementOperation=new GetMoneyManagementOperation();

		if(StringUtil.isEmpty(getMoneyManagementDTO.getCustomId())){
			return ResultUtil.error(-2,"客户ID必须填写！");
		}

		//保存收款单
		if(getMoneyManagementDTO.getId()!=null&&getMoneyManagementDTO.getId()>0){
			getMoneyManagementOperation.setActionName("修改收款单");
			getMoneyManagementOperation.setActionCode("update");

			//找出修改的值
			String actionDescription="";
			List<GetMoneyManagement> getMoneyManagementList=getMoneyManagementDao.getGetMoneyManagement(getMoneyManagement.getId());
			GetMoneyManagement oldGetMoneyManagement=getMoneyManagementList.get(0);
			if(!(oldGetMoneyManagement.getOrderNo()+"").equals(getMoneyManagement.getOrderNo()+"")){//orderNo
				actionDescription+="订单编号："+oldGetMoneyManagement.getOrderNo()+"->"+getMoneyManagement.getOrderNo()+";";
			}
			if(!(oldGetMoneyManagement.getShopName()+"").equals(getMoneyManagement.getShopName()+"")){//shopName
				actionDescription+="店铺："+oldGetMoneyManagement.getShopName()+"->"+getMoneyManagement.getShopName()+";";
			}
			if(!(oldGetMoneyManagement.getCustomId()+"").equals(getMoneyManagement.getCustomId()+"")){//customId
				actionDescription+="客户ID："+oldGetMoneyManagement.getCustomId()+"->"+getMoneyManagement.getCustomId()+";";
			}
			if(!(oldGetMoneyManagement.getMoney()+"").equals(getMoneyManagement.getMoney()+"")){//money
				actionDescription+="金额："+oldGetMoneyManagement.getMoney()+"->"+getMoneyManagement.getMoney()+";";
			}
			if(!(oldGetMoneyManagement.getOperatorUserName()+"").equals(getMoneyManagement.getOperatorUserName()+"")){//reasonText
				actionDescription+="收款人："+oldGetMoneyManagement.getOperatorUserName()+"->"+getMoneyManagement.getOperatorUserName()+";";
			}
			SimpleDateFormat dateForamt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String newDate=getMoneyManagement.getOperatorDate()!=null?dateForamt.format(getMoneyManagement.getOperatorDate()):"";
			String oldDate=oldGetMoneyManagement.getOperatorDate()!=null?dateForamt.format(oldGetMoneyManagement.getOperatorDate()):"";
			if(!newDate.equals(oldDate)){
				actionDescription+="收款日期："+oldDate+"->"+newDate+";";
			}
			if(!(oldGetMoneyManagement.getDescription()+"").equals(getMoneyManagement.getDescription()+"")){//description
				actionDescription+="描述："+oldGetMoneyManagement.getDescription()+"->"+getMoneyManagement.getDescription()+";";
			}

			getMoneyManagementOperation.setActionDescription(actionDescription);

			getMoneyManagementDao.update(getMoneyManagement);
		}else{
			getMoneyManagement.setStatusName("无状态");
			getMoneyManagement.setStatusCode("0");
			
			getMoneyManagementDao.insert(getMoneyManagement);

			getMoneyManagementOperation.setActionName("新增收款单");
			getMoneyManagementOperation.setActionCode("insert");
		}

		getMoneyManagementOperation.setGetmoneyId(getMoneyManagement.getId());
		getMoneyManagementOperation.setUserId(user.getId());
		getMoneyManagementOperation.setUserName(user.getUserName());
		getMoneyManagementOperation.setDate(new Date());
		getMoneyManagementDao.insertHistory(getMoneyManagementOperation);

		return ResultUtil.success();
	}

	@Override
	public int getGetMoneyManagementTotal(GetMoneyManagementDTO getMoneyManagementDTO,Date startDate,Date endDate) {
		GetMoneyManagement getMoneyManagement=new GetMoneyManagement();
		BeanUtils.copyProperties(getMoneyManagementDTO, getMoneyManagement);
		return getMoneyManagementDao.getGetMoneyManagementTotal(getMoneyManagement, startDate, endDate);
	}

	@Override
	public List<GetMoneyManagement> getGetMoneyManagementPage(GetMoneyManagementDTO getMoneyManagementDTO, int page,
			int size,Date startDate,Date endDate) {
		GetMoneyManagement getMoneyManagement=new GetMoneyManagement();
		BeanUtils.copyProperties(getMoneyManagementDTO, getMoneyManagement);
		return getMoneyManagementDao.getGetMoneyManagementPage(getMoneyManagement, page, size, startDate, endDate);
	}

	
	@Override
	public HSSFWorkbook exportGetMoneyManagement(GetMoneyManagementDTO getMoneyManagementDTO, Date startDate, Date endDate) {
		
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet=wb.createSheet("打款记录");
		/*******表头*********/
		HSSFRow row0=sheet.createRow(0);
		row0.createCell(0).setCellValue("订单编号");
		row0.createCell(1).setCellValue("店铺名称");
		row0.createCell(2).setCellValue("客户ID");
		row0.createCell(3).setCellValue("金额");
		row0.createCell(4).setCellValue("创建日期");
		row0.createCell(5).setCellValue("创建人");
		row0.createCell(6).setCellValue("收款人");
		row0.createCell(7).setCellValue("备注");
		
		/**********内容***********/
		GetMoneyManagement getMoneyManagement=new GetMoneyManagement();
		BeanUtils.copyProperties(getMoneyManagementDTO, getMoneyManagement);
		List<GetMoneyManagement> getMoneyManagementList= getMoneyManagementDao.getGetMoneyManagementPage(getMoneyManagement, null, null, startDate, endDate);
		
		for(int j=0;j<getMoneyManagementList.size();j++){
			GetMoneyManagement pm=getMoneyManagementList.get(j);
			HSSFRow row=sheet.createRow(j+1);
			row.createCell(0).setCellValue(pm.getOrderNo());
			row.createCell(1).setCellValue(pm.getShopName());
			row.createCell(2).setCellValue(pm.getCustomId());
			row.createCell(3).setCellValue(pm.getMoney());
			row.createCell(4).setCellValue(pm.getCreaterDate()!=null?sdf.format(pm.getCreaterDate()):"");
			row.createCell(5).setCellValue(pm.getCreaterUserName());
			row.createCell(6).setCellValue(pm.getOperatorUserName());
			row.createCell(7).setCellValue(pm.getDescription());
		}
		return wb;
	}

	@Override
	public List<GetMoneyManagementOperation> getPayMoneyManagementHistory(Long getMoneyId) {
		return getMoneyManagementDao.getGetMoneyManagementHistory(getMoneyId);
	}

}

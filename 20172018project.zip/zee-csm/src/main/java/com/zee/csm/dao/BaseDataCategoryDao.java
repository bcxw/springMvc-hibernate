package com.zee.csm.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.zee.csm.entity.BaseDataCategory;

public interface BaseDataCategoryDao {
	/**
	 * 根据父类找子类
	 * @param parentId
	 * @return
	 */
	public List<Map<String,Object>> getBaseDataCategoryByParentId(@Param("parentId")Long parentId);
	
	/**
	 * 添加分类
	 * @param baseDataCategory
	 * @return
	 */
	public int insert(BaseDataCategory baseDataCategory);
	
	/**
	 * 修改分类
	 * @param baseDataCategory
	 * @return
	 */
	public int update(BaseDataCategory baseDataCategory);
	
	/**
	 * 同一分类下判断判断重名
	 * @param baseDataCategory
	 * @return
	 */
	public int existName(BaseDataCategory baseDataCategory);
	
	/**
	 * 同一分类下判断编码重复
	 * @param baseDataCategory
	 * @return
	 */
	public int existCode(BaseDataCategory baseDataCategory);
	
	/**
	 * 删除分类
	 * @param id
	 * @return
	 */
	public int delete(@Param("id")Long id);
	
	/**
	 * 判断是否存在下级数据
	 * @param parentId
	 * @return
	 */
	public int existChild(@Param("parentId")Long parentId);
	
	/**
	 * 根据父类编码获取子类
	 * @param parentCode
	 * @return
	 */
	public List<Map<String, Object>> getBaseDataCategoryByParentCode(@Param("parentCode")String parentCode);
	
	
}

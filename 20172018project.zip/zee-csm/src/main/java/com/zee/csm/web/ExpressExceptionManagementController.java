package com.zee.csm.web;

import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zee.csm.context.UserContext;
import com.zee.csm.dto.ExpressExceptionDTO;
import com.zee.csm.entity.User;
import com.zee.csm.service.ExpressExceptionService;
import com.zee.framework.aspect.autolog.annotation.ZcyAutoLog;
import com.zee.framework.model.Result;
import com.zee.framework.util.ResultUtil;

@Controller
@RequestMapping("/expressExceptionManagement")
@ZcyAutoLog(module="打款管理商管理",tag="ExpressExceptionManagementController")
public class ExpressExceptionManagementController {
	private static final Logger logger = LoggerFactory.getLogger(ExpressExceptionManagementController.class);

	@Resource
	private ExpressExceptionService expressExceptionService;
	
	
	/**
	 * 快递管理页面
	 * @param request
	 * @return
	 */
	@RequestMapping("/index")
	public String index(HttpServletRequest request) {
		return "/security/expressExceptionManagement/expressExceptionManagement";
	}

	
	
	/**
	 * 保存快递问题单
	 * @param expressExceptionDTO
	 * @param isConfirm
	 * @return
	 */
	@RequestMapping(value = "/saveExpressException")
	@ResponseBody
	public Result saveExpressException(HttpServletRequest request,ExpressExceptionDTO expressExceptionDTO,String isConfirm) {

		try {
			User user=(User)request.getSession().getAttribute("CURRENT_LOGIN_USER");
			return expressExceptionService.saveExpressException(expressExceptionDTO, user, isConfirm);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			return ResultUtil.error(-10,"请刷新重试或重新登录！");
		}
	}

	@RequestMapping(value = "/closeExpressException")
	@ResponseBody
	public Result closeExpressException(HttpServletRequest request,Long id,String closeReason) {
		try {
			User user=(User)request.getSession().getAttribute("CURRENT_LOGIN_USER");
			return expressExceptionService.closeExpressException(id,user,closeReason);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			return ResultUtil.error(-10,"请刷新重试或重新登录！");
		}
	}
	
	/**
	 * 获取快递问题单分页数据
	 * @param expressExceptionDTO
	 * @param page
	 * @param rows
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@RequestMapping(value = "/getExpressExceptionPage")
	@ResponseBody
	public Result getExpressExceptionPage(HttpServletRequest request,ExpressExceptionDTO expressExceptionDTO,Integer page, Integer rows,@DateTimeFormat(pattern="yyyy-MM-dd") Date startDate,@DateTimeFormat(pattern="yyyy-MM-dd") Date endDate) {
		try {
			User user=(User)request.getSession().getAttribute("CURRENT_LOGIN_USER");
			int total=expressExceptionService.getExpressExceptionTotal(expressExceptionDTO, startDate, endDate);
			int start=page == 1 ? (page - 1) : (page - 1) * rows;
			return ResultUtil.page(expressExceptionService.getExpressExceptionPage(expressExceptionDTO, start, rows, startDate, endDate), total);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			return ResultUtil.error(-10,"请刷新重试或重新登录！");
		}
	}
	
	/**
	 * 获取历史记录
	 * @param expressExceptionId
	 * @return
	 */
	@RequestMapping(value = "/getExpressExceptionHistory")
	@ResponseBody
	public Result getExpressExceptionHistory(HttpServletRequest request,Long expressExceptionId) {
		try {
			return ResultUtil.page(expressExceptionService.getExpressExceptionHistory(expressExceptionId), 0);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			return ResultUtil.error(-10,"请刷新重试或重新登录！");
		}
	}
	
	
	
	/**
	 * 导出excel
	 * @param request
	 * @param response
	 * @param expressExceptionDTO
	 * @param startDate
	 * @param endDate
	 */
	@RequestMapping(value = "/exportExpressException")
	public void exportExpressException(HttpServletRequest request, HttpServletResponse response,ExpressExceptionDTO expressExceptionDTO,@DateTimeFormat(pattern="yyyy-MM-dd") Date startDate,@DateTimeFormat(pattern="yyyy-MM-dd") Date endDate) {

		HSSFWorkbook wb=expressExceptionService.exportExpressException(expressExceptionDTO, startDate, endDate);
		OutputStream myout=null;
		try {
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html;charset=utf-8");
			myout=response.getOutputStream();
			
			response.setContentType("applicationoctet-stream;charset=UTF-8");
			String name = "快递问题单.xls";
			String userAgent = request.getHeader("User-Agent").toLowerCase();  
			//byte[] bytes = userAgent.contains("safari") ?name.getBytes("UTF-8"):name.getBytes("gbk");
			//name = new String(bytes, "ISO-8859-1");
			if (userAgent.contains("msie") || userAgent.contains("like gecko") ) {
				name = URLEncoder.encode(name, "UTF-8");
			} else {
				name = new String(name.getBytes("UTF-8"), "iso-8859-1");
			}
			response.setHeader("Content-disposition", String.format("attachment;filename=\"%s\"", name));
			wb.write(myout);
			
		} catch (UnsupportedEncodingException e) {
			logger.error(e.getMessage(),e);
		} catch (IOException e) {
			logger.error(e.getMessage(),e);
		} finally{
			try {
				if(wb!=null)wb.close();
				if(myout!=null)myout.close();
			} catch (IOException e) {
				logger.error(e.getMessage(),e);
			}
		}
           
	}
	
}

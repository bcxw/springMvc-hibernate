package com.zee.csm.service;

import java.util.Collection;
import java.util.List;

import com.zee.csm.entity.User;
import com.zee.csm.entity.UserRole;

public interface UserService {
	//添加用户信息
	public void addUser(User user) ; 
	//修改用户信息
	public void updateUser(User user) ; 
	//删除用户信息
	public void deleteUserById(Long id) ; 
	//根据用户名密�?,获得用户信息
	public User getUser(String name,String pwd) ; 
	//根据用户ID,获得用户信息
	public User getUser(Long id) ; 
	//分页获得用户信息
	public List<User> getUsers(int page,int size,String name,Long roleId) ; 
	//获得用户总记录信�?
	public int getUserRecordTotal(String name,Long roleId) ; 
	//分页获得用户信息
	public List<User> getUsers(Collection<Long> ids) ; 
	//分页查询用户角色的对应关�?
	public List<UserRole> getUserRoles(int page ,int size,Long userId,Long roleId) ;
	//根据用户ID查询用户角色对应关系
	public List<UserRole> getUserRolesByUserId(Long userId) ;
	//保存用户角色对应关系
	public void addUserRoles(Long userId,Long[] roleIds) ;
	//删除用户角色对应关系
	public void deleteUserRoleById(Long id);
	//查询�?有用户列�?
	public List<User> getAllUsers() ;
	//根据条件查询用户角色总数
	public int getUserRoleRecordTotal(Long userId, Long roleId);
	//根据用户名查询用户是否已存在
	public int getUserByUserName(String userName);
	public void deleteUserByIds(List<Long> delIds);
	public void updateUserPassword(User user); 
	
	//添加用户供应商关联
	public int addUserSupplier(Long userId,Long supplierId,String supplierName);
	//添加用户仓库关联
	public int addUserRepertory(Long userId,Long repertoryId,String repertoryName);
	
}

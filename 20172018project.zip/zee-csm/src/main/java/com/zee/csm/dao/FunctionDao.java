package com.zee.csm.dao;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.zee.csm.entity.Function;

public interface FunctionDao {
		/**
		 * delete from auth_function where id = ? 
		 * @param id
		 */
		public void deleteById(Long id)  ;
		/**
		 * insert into auth_function(id,name,pwd)values(?,?,?)
		 * @return
		 */
		public int save(Function function) ; 
		/**
		 * update auth_function set name = ? ,pwd = ? where id = ?
		 * @return
		 */
		public int update(Function function) ; 
		
		/**
		 * update auth_function set url = ? where id = ?
		 * 根据ID更新功能的URL
		 * @param id
		 * @param url
		 * @return
		 */
		public int updateUrl(@Param("id")Long id, @Param("url")String url,
				@Param("accordion")Integer accordion,@Param("name")String name) ; 
		/**
		 * select * from auth_function where id = ? 
		 * @param id
		 * @return
		 */
		public Function findById(Long id) ; 
		/**
		 * select * from auth_function where id in ()  
		 * @param ids
		 * @return
		 */
		public List<Function> findByIds(Collection<Long> ids) ; 
		/**
		 * select * from auth_function where parent_id = ? limit ?,?
		 * 根据父节点ID返回功能集合
		 * @param page
		 * @param size
		 * @return
		 */
		public List<Function> findFunctions(@Param("page")int page, @Param("size")int size,@Param("parentId")Long parentId) ; 
		/**
		 * select * from auth_function  
		 * 查询全部功能
		 * @param ids
		 * @return
		 */
		public List<Function> getAllFunctions() ;
		/**
		 * 根据ID查询功能信息
		 * @param id
		 * @return
		 */
		public Function findFunctionById(Long id);
		public List<Function> getAuthsByParentId(Map<String, Object> map);
		public int countChildren(Map<String, Object> map);
		public List<Function> getAllFunctionsByParentId(Long parentId);
		public int hasChildrenByParentId(Long parentId);
		public void updateFunction(Function function);
}

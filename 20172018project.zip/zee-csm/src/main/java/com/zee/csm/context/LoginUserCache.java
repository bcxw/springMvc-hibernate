package com.zee.csm.context;

import java.util.HashMap;
import java.util.Map;

import com.zee.csm.entity.User;

public class LoginUserCache {
	private static Map<String,User> cache = new HashMap<String,User>() ;
	public static void put(User user) {
		cache.put(user.getUserName(), user) ;
		UserContext.setCurrentUser(user);
	}
	
	public static User get(String userName) {
		return cache.get(userName) ;
	}
	
	public static void remove(String userName){
		cache.remove(userName) ;
		UserContext.setCurrentUser(null);
	}
}

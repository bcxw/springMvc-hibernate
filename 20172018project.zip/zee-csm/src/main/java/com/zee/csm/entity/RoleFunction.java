package com.zee.csm.entity;

import com.zee.csm.common.BaseEntity;
/**
 * 角色功能关联
 * @author rygao
 */
public class RoleFunction extends BaseEntity {
	private Long roleId ; 
	private Long functionId ; 
	public Long getRoleId() {
		return roleId;
	}
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}
	public Long getFunctionId() {
		return functionId;
	}
	public void setFunctionId(Long functionId) {
		this.functionId = functionId;
	}
	@Override
	public String toString() {
		return "RoleFunction [roleId=" + roleId + ", functionId=" + functionId + "]";
	}
}

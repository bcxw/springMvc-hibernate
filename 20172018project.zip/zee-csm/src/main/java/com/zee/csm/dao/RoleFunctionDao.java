package com.zee.csm.dao;

import java.util.Collection;
import java.util.List;

import com.zee.csm.entity.RoleFunction;

public interface RoleFunctionDao {
	/**
	 * select * from auth_role_function where id = ? 
	 * @param id
	 * @return
	 */
	public RoleFunction findRoleFunctionById(Long id) ; 
	/**
	 * insert into auth_role_function(role_id,function_id,status) values (?,?,?) 
	 * 批量保存,一个角色也可以对应多个功能菜单,分配时是多选
	 * @param id
	 * @return
	 */
	public int saveRoleFunctions(Collection<RoleFunction> roleFunctions) ; 
	
	/**
	 * select * from auth_role_function where role_id = ? 
	 * @param id
	 * @return
	 */
	public List<RoleFunction> findRoleFunctionsByRoleId(Long roleId) ; 
	
	/**
	 * delete from auth_role_function where role_id = ? 
	 * @param id
	 * @return
	 */
	public void deleteByRoleIds(List<Long> delIds) ;
	/**
	 * 根据功能ID删除角色功能对应关系
	 * @param functionId
	 */
	public void deleteRoleFunctionByFunctionId(Long functionId);
	
	public List<RoleFunction> getRoleFunctionsByRoleIds(Collection<Long> ids); 
	
}

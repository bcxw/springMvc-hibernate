package com.zee.csm.exception;

import com.zee.framework.aspect.autolog.Interface.DesignedException;

public class ValidateException extends RuntimeException implements DesignedException {
	private static final long serialVersionUID = 2669040717172917220L;

    public ValidateException(String message) {
        super(message);
    }
}

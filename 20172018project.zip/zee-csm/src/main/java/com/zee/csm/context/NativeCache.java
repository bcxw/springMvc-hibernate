package com.zee.csm.context;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.zee.csm.entity.Function;
import com.zee.csm.entity.Role;
import com.zee.csm.service.FunctionService;

/**
 * 本地缓存信息
 * @author rygao
 */
@Service
public class NativeCache {
	
	private static final Map<Long,Function> functionMap = new HashMap<Long,Function>() ;
	
	private static final Map<Long,List<Function>> parentFunctionMap = new HashMap<Long,List<Function>>() ;
	
	//TODO 用户角色缓存信息,如果使用该缓存则在添加,修改,删除用户角色时需要维护暂时没性能影响,以后在考虑完善!
	private Map<Long,List<Role>> userRoleMap = new HashMap<Long,List<Role>>() ;
	
	@Resource
	private FunctionService functionService ;
	
	@PostConstruct                                                                                          
	public void init(){
		List<Function> functionList = functionService.getAllFunctions() ;
		for (Function function : functionList) {
			List<Function> listFunction = parentFunctionMap.get(function.getParentId());
			if(null == listFunction){
				listFunction = new ArrayList<Function>() ;
			}
			listFunction.add(function) ;
			parentFunctionMap.put(function.getParentId(), listFunction) ; 
		}
	}
	
	public Map<Long,List<Function>> getParentFunctions(){
		if(parentFunctionMap.isEmpty()){
			init() ;
		}
		return parentFunctionMap;
	}
 
	
	public void addFunction(Function function){
		List<Function> listFunction = parentFunctionMap.get(function.getParentId());
		if(null == listFunction){
			listFunction = new ArrayList<Function>() ;
		}
		listFunction.add(function) ;
		parentFunctionMap.put(function.getParentId(), listFunction) ; 
	}
	
	public void replaceFunction(Function function){
		List<Function> listFunction = parentFunctionMap.get(function.getParentId());
		if(null == listFunction){
			listFunction = new ArrayList<Function>() ;
		}
		for (int i = 0; i < listFunction.size(); i++) {
			if(function.getId().equals(listFunction.get(i).getId())){
				listFunction.remove(i) ; 
			}
		}
		listFunction.add(function) ; 
	}
	
	public void removeFunction(Long functionId,Long parentId){
		List<Function> listFunction = parentFunctionMap.get(parentId);
		if(null != listFunction){
			for (int i = 0; i < listFunction.size(); i++) {
				if(functionId.equals(listFunction.get(i).getId())){
					listFunction.remove(i) ; 
				}
			}
		}
	}
	
	/**
	 * 缓存用户及对应的角色
	 * @param userId
	 * @param roles
	 */
	public void setRoles(Long userId,List<Role> roles){
		userRoleMap.put(userId, roles) ;
	}
	
	
	public List<Role> getRoles(Long userId){
		return userRoleMap.get(userId) ;
	}
	
	public Function getFunction(Long id){
		return functionMap.get(id) ;
	}
}

package com.zee.csm.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.alibaba.druid.util.StringUtils;
import com.fasterxml.jackson.databind.util.BeanUtil;
import com.zee.csm.dao.BaseDataCategoryDao;
import com.zee.csm.dao.BaseDataItemsDao;
import com.zee.csm.dto.BaseDataCategoryDTO;
import com.zee.csm.dto.BaseDataItemsDTO;
import com.zee.csm.entity.BaseDataCategory;
import com.zee.csm.entity.BaseDataItems;
import com.zee.csm.service.BaseDataService;

@Service
public class BaseDataServiceImpl implements BaseDataService{
	
	@Resource
	private BaseDataCategoryDao baseDataCategoryDao;
	
	@Resource
	private BaseDataItemsDao baseDataItemsDao;

	@Override
	public List<Map<String, Object>> getBaseDataCategoryByParentId(Long parentId) {
		return baseDataCategoryDao.getBaseDataCategoryByParentId(parentId);
	}

	@Override
	public List<BaseDataItemsDTO> getBaseDataItemsByParentId(Long parentId) {
		List<BaseDataItems> list=baseDataItemsDao.getBaseDataItemsByParentId(parentId);
		List<BaseDataItemsDTO> dtoList=new ArrayList<BaseDataItemsDTO>();
		
		for(int i=0;i<list.size();i++){
			BaseDataItems oneItem=list.get(i);
			BaseDataItemsDTO oneDto=new BaseDataItemsDTO();
			BeanUtils.copyProperties(oneItem, oneDto);
			dtoList.add(oneDto);
		}
		
		return dtoList;
	}

	@Override
	public Map<String, Object> saveBaseDataCategory(BaseDataCategoryDTO baseDataCategoryDTO) {
		Map<String, Object> returnMap=new HashMap<String, Object>();
		
		BaseDataCategory bdc=new BaseDataCategory();
		BeanUtils.copyProperties(baseDataCategoryDTO, bdc);
		
		if(baseDataCategoryDao.existName(bdc)>0){
			returnMap.put("success", false);
			returnMap.put("message", "同一父分类下已存在相同名称的分类！");
			return returnMap;
		}
		
		if(!StringUtils.isEmpty(bdc.getCode())&&baseDataCategoryDao.existCode(bdc)>0){
			returnMap.put("success", false);
			returnMap.put("message", "同一父分类下已存在相同编码的分类！");
			return returnMap;
		}
		
		if(bdc.getId()!=null&&bdc.getId()>0){
			baseDataCategoryDao.update(bdc);
		}else{
			baseDataCategoryDao.insert(bdc);
		}
		returnMap.put("success", true);
		returnMap.put("data", bdc);
		return returnMap;
	}

	@Override
	public Map<String,Object> deleteBaseDataCategory(Long id) {
		Map<String, Object> returnMap=new HashMap<String, Object>();
		
		if(baseDataCategoryDao.existChild(id)>0){
			returnMap.put("success", false);
			returnMap.put("message", "此节点包含下级子类，不能删除！");
			return returnMap;
		}
		if(baseDataItemsDao.existItem(id)>0){
			returnMap.put("success", false);
			returnMap.put("message", "此节点包含子数据项，不能删除！");
			return returnMap;
		}
		
		baseDataCategoryDao.delete(id);
		returnMap.put("success", true);
		return returnMap;
	}

	@Override
	public Map<String, Object> saveBaseDataItem(BaseDataItemsDTO baseDataItemsDTO) {
		Map<String, Object> returnMap=new HashMap<String, Object>();
		
		BaseDataItems bdi=new BaseDataItems();
		BeanUtils.copyProperties(baseDataItemsDTO, bdi);
		
		if(baseDataItemsDao.existName(bdi)>0){
			returnMap.put("success", false);
			returnMap.put("message", "同一父分类下已存在相同名称的数据！");
			return returnMap;
		}
		
		if(baseDataItemsDao.existCode(bdi)>0){
			returnMap.put("success", false);
			returnMap.put("message", "同一父分类下已存在相同编码的数据！");
			return returnMap;
		}
		
		if(bdi.getId()!=null&&bdi.getId()>0){
			baseDataItemsDao.update(bdi);
		}else{
			baseDataItemsDao.insert(bdi);
		}
		returnMap.put("success", true);
		returnMap.put("data", bdi);
		return returnMap;
	}

	@Override
	public Map<String, Object> deleteBaseDataItem(Long id) {
		Map<String, Object> returnMap=new HashMap<String, Object>();
		baseDataItemsDao.delete(id);
		returnMap.put("success", true);
		return returnMap;
	}

	@Override
	public List<Map<String, Object>> getBaseDataItemByParentCode(String parentCode) {
		return baseDataItemsDao.getBaseDataItemByParentCode(parentCode);
	}

	@Override
	public List<Map<String, Object>> getBaseDataCategoryAndItemByParentCode(String parentCode) {
		List<Map<String, Object>> categoryList=baseDataCategoryDao.getBaseDataCategoryByParentCode(parentCode);
		
		for(int i=0;i<categoryList.size();i++){
			categoryList.get(i).put("baseDataItems", this.getBaseDataItemsByParentId(Long.parseLong(categoryList.get(i).get("id").toString())));
		}
		return categoryList;
	}
	
}
